"""
test_research_integration.py — Complete Verification for ZERNEXA Research Engine Import
=======================================================================================
Verifies:
1. Auxiliary service keys loading (Tavily, Semantic Scholar, Serper, Exa)
2. OpenAlex inverted index abstract decoding & metadata extraction
3. ArXiv native Atom XML parser & preprints extraction
4. Semantic Scholar (AI2) Graph API integration
5. Tavily 8-key round-robin rotation & usage tracking
6. Relevance scoring & citation boost algorithm
7. ClaimVerifier contradiction detection & audit
8. End-to-end multi-source discovery & grounded synthesis
"""

import os
import sys
import unittest

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.config import get_service_keys
from backend.research_engine import (
    _reconstruct_inverted_index,
    _filter_and_rank_papers,
    search_openalex_papers,
    search_arxiv_papers,
    search_semantic_scholar_papers,
    tavily_key_mgr,
    execute_multi_source_discovery,
    build_academic_synthesis_prompt,
)
from backend.claim_verifier import ClaimVerifier
from backend.main import _run_chat_pipeline, ChatRequest


class TestZernexaResearchEngine(unittest.TestCase):

    def test_01_service_keys_configured(self):
        """Verify auxiliary service keys are loaded from assets/service_keys.json."""
        tav_keys = get_service_keys("tavily")
        s2_keys = get_service_keys("semantic_scholar")
        serp_keys = get_service_keys("serper")
        exa_keys = get_service_keys("exa")

        self.assertGreaterEqual(len(tav_keys), 1, "Tavily keys should be present")
        self.assertGreaterEqual(len(s2_keys), 1, "Semantic Scholar key should be present")
        self.assertGreaterEqual(len(serp_keys), 1, "Serper key should be present")
        self.assertGreaterEqual(len(exa_keys), 1, "Exa keys should be present")
        print(f"✅ Service keys verified: Tavily={len(tav_keys)}, S2={len(s2_keys)}, Serper={len(serp_keys)}, Exa={len(exa_keys)}")

    def test_02_inverted_index_reconstruction(self):
        """Verify OpenAlex abstract inverted index decoding."""
        mock_inv = {
            "Quantum": [0],
            "error": [1],
            "correction": [2],
            "protects": [3],
            "qubits": [4]
        }
        decoded = _reconstruct_inverted_index(mock_inv)
        self.assertEqual(decoded, "Quantum error correction protects qubits")
        print(f"✅ Inverted index decoding verified: '{decoded}'")

    def test_03_relevance_ranking_algorithm(self):
        """Verify keyword matching 4x title, 1x abstract, and citation boosts."""
        papers = [
            {
                "title": "Quantum Error Correction Surface Codes",
                "abstract": "We demonstrate fault-tolerant logical qubits with distance 5.",
                "citations": "1500",
                "year": "2024",
                "source": "OpenAlex"
            },
            {
                "title": "Random Unrelated Paper on Ancient Astronomy",
                "abstract": "Studies of stars in the medieval era.",
                "citations": "2",
                "year": "2010",
                "source": "ArXiv"
            }
        ]
        ranked = _filter_and_rank_papers(papers, "quantum error correction")
        self.assertEqual(len(ranked), 1, "Unrelated paper should be filtered out")
        self.assertIn("Quantum", ranked[0]["title"])
        print(f"✅ Relevance ranking verified: accurately boosted top paper and dropped noise")

    def test_04_tavily_key_rotation(self):
        """Verify Tavily 8-key rotation and usage persistence."""
        k1 = tavily_key_mgr.get_key()
        self.assertIsNotNone(k1)
        tavily_key_mgr.record_usage(k1)
        k2 = tavily_key_mgr.get_key()
        self.assertIsNotNone(k2)
        print("✅ Tavily key manager rotation verified")

    def test_05_claim_verifier_contradiction_detection(self):
        """Verify ClaimVerifier catches conflicting premises and direct contradictions."""
        verifier = ClaimVerifier()
        test_evidence = (
            "Source A: The physical qubit error threshold is strictly 1.0% in surface codes.\n"
            "Source B: The physical qubit error threshold is strictly 0.1% in surface codes, not 1.0%.\n"
            "[CONTRADICTION_FLAG] Conflict between threshold estimates."
        )
        all_claims, contradictions = verifier.audit_evidence_claims(
            test_evidence, "What is the physical error threshold in surface codes?"
        )
        self.assertGreaterEqual(len(all_claims), 1)
        self.assertGreaterEqual(len(contradictions), 1)
        print(f"✅ ClaimVerifier verified: caught {len(contradictions)} contradiction(s)")

    def test_06_live_academic_discovery(self):
        """Verify parallel multi-source discovery across live academic engines."""
        discovery = execute_multi_source_discovery("quantum computing fault tolerance")
        sources = discovery.get("sources", [])
        self.assertGreaterEqual(len(sources), 2, "Should discover at least 2 verified sources")
        self.assertIn("evidence_context", discovery)
        badges = {s.get("badge") for s in sources}
        print(f"✅ Multi-source discovery returned {len(sources)} sources with badges: {badges}")

    def test_07_academic_mode_pipeline_end_to_end(self):
        """Verify /research slash command triggers academic review with 5-column table and bibliography."""
        req = ChatRequest(
            query="/research What is quantum error correction in surface codes?",
            mode="deep",
            research_mode=True
        )
        emitted_events = []
        def mock_emit(event):
            emitted_events.append(event.get("event"))

        result = _run_chat_pipeline(req, emit=mock_emit)
        self.assertEqual(result.get("type"), "research")
        self.assertIn("content", result)
        content = result["content"]
        self.assertIn("|", content, "Should contain Markdown comparison/matrix tables")
        self.assertTrue(result.get("has_pdf"), "Should generate valid PDF export")
        self.assertTrue(os.path.exists(os.path.join(PROJECT_ROOT, "pdf_exports", result["pdf_filename"])))
        print(f"✅ End-to-end Academic Pipeline verified: PDF={result['pdf_filename']}, Sources={len(result.get('sources', []))}")


if __name__ == "__main__":
    unittest.main()
