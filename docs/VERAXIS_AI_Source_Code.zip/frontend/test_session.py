from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(viewport={"width": 1366, "height": 768})
    page.goto('http://localhost:5173/')
    page.evaluate('''() => {
        const s = [{id: 's1', title: 'Test Solid Battery', createdAt: new Date().toISOString(), messages: [{role:'user', content:'hello world'}, {role:'bot', content:'world answer'}]}];
        localStorage.setItem('veraxis_sessions', JSON.stringify(s));
    }''')
    page.reload()
    page.wait_for_timeout(400)
    page.locator("button[aria-label='Toggle Archive Sidebar']").click()
    page.wait_for_timeout(400)
    # Click session row
    page.locator("aside div.cursor-pointer").first.click()
    page.wait_for_timeout(500)
    print("Messages visible:", page.locator("text=hello world").is_visible())
    print("Bot answer visible:", page.locator("text=world answer").is_visible())
    browser.close()
