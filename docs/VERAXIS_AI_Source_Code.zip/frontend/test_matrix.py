import os
import json
from playwright.sync_api import sync_playwright

BASE_URL = "http://localhost:5173/"

TEST_VIEWPORTS = [
    # (width, height, zoom_factor, name)
    (360, 640, 1.0, "360x640_100zoom"),
    (390, 844, 1.0, "390x844_100zoom"),
    (768, 1024, 1.0, "768x1024_100zoom"),
    (1024, 768, 1.0, "1024x768_100zoom"),
    (1366, 768, 1.0, "1366x768_100zoom"),
    (1440, 900, 1.0, "1440x900_100zoom"),
    (1920, 940, 1.0, "1920x940_100zoom"),
    # Short heights
    (1366, 568, 1.0, "1366x568_short"),
    (1366, 667, 1.0, "1366x667_short"),
    # Browser Zooms (simulated viewport)
    (1366, 768, 1.25, "1366x768_125zoom"),
    (1366, 768, 1.50, "1366x768_150zoom"),
    (1920, 940, 1.25, "1920x940_125zoom"),
    (1920, 940, 1.50, "1920x940_150zoom"),
]

def run_matrix():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        all_passed = True

        for w, h, zoom, name in TEST_VIEWPORTS:
            ctx = browser.new_context(
                viewport={"width": int(w / zoom), "height": int(h / zoom)},
                device_scale_factor=zoom
            )
            page = ctx.new_page()
            page.goto(BASE_URL)
            page.wait_for_timeout(300)

            # Check horizontal scroll
            has_h_scroll = page.evaluate("() => document.documentElement.scrollWidth > document.documentElement.clientWidth")
            
            # Check ASK button visibility
            ask_btn = page.locator("button[aria-label='Ask']").first
            ask_box = ask_btn.bounding_box()
            vh = int(h / zoom)

            ask_visible = ask_box is not None and (ask_box["y"] + ask_box["height"] <= vh + 1)
            
            status = "PASS" if (not has_h_scroll and ask_visible) else "FAIL"
            if status == "FAIL":
                all_passed = False

            print(f"[{status}] {name} (vp {int(w/zoom)}x{vh}): ASK bottom={ask_box['y']+ask_box['height']:.1f}, vh={vh}, H-Scroll={has_h_scroll}")
            ctx.close()

        browser.close()
        if all_passed:
            print("\nAll matrix tests PASSED successfully!")
        else:
            print("\nSome matrix tests failed!")

if __name__ == "__main__":
    run_matrix()
