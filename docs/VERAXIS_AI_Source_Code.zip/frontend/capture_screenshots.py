import os
import sys
import json
from playwright.sync_api import sync_playwright

BASE_URL = "http://localhost:5173/"
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

MOCK_SESSIONS = [
  {
    "id": "sess-1",
    "title": "Solid-State Ceramic Electrolyte Benchmarks 2028",
    "createdAt": "2026-10-01T08:30:00.000Z",
    "messages": []
  },
  {
    "id": "sess-2",
    "title": "NIST Post-Quantum Cryptography Implementation Audits",
    "createdAt": "2026-09-30T14:00:00.000Z",
    "messages": []
  }
]

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="chrome", headless=True)

        # 1. 1440 Desktop Dark
        ctx_desktop_dark = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1.5
        )
        page = ctx_desktop_dark.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'dark'); localStorage.setItem('veraxis-theme', 'dark');")
        page.wait_for_timeout(1400)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_dark.png"))
        print("Captured: screenshot_1440_dark.png")
        ctx_desktop_dark.close()

        # 2. 1440 Desktop Light (Acid)
        ctx_desktop_light = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1.5
        )
        page = ctx_desktop_light.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        page.wait_for_timeout(1400)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_light.png"))
        print("Captured: screenshot_1440_light.png")
        ctx_desktop_light.close()

        # 3. 390 Mobile Dark
        ctx_mobile_dark = browser.new_context(
            viewport={"width": 390, "height": 844},
            device_scale_factor=2
        )
        page = ctx_mobile_dark.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'dark'); localStorage.setItem('veraxis-theme', 'dark');")
        page.wait_for_timeout(1400)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_390_dark.png"))
        print("Captured: screenshot_390_dark.png")

        # 4. 390 Mobile Drawer Open
        page.locator("button[aria-label='Toggle Archive Sidebar']").click()
        page.wait_for_timeout(1400)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_390_drawer_open.png"))
        print("Captured: screenshot_390_drawer_open.png")
        ctx_mobile_dark.close()

        # 5. 390 Mobile Light (Acid)
        ctx_mobile_light = browser.new_context(
            viewport={"width": 390, "height": 844},
            device_scale_factor=2
        )
        page = ctx_mobile_light.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        page.wait_for_timeout(1400)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_390_light.png"))
        print("Captured: screenshot_390_light.png")
        ctx_mobile_light.close()

        # 6. 1440 Desktop with Sidebar open and at least two sessions
        ctx_desktop_sidebar = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1.5
        )
        page = ctx_desktop_sidebar.new_page()
        page.goto(BASE_URL)
        sessions_json = json.dumps(MOCK_SESSIONS)
        page.evaluate(f"localStorage.setItem('veraxis_sessions', '{sessions_json}'); document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        page.reload()
        page.wait_for_timeout(500)
        page.locator("button[aria-label='Toggle Archive Sidebar']").click()
        page.wait_for_timeout(1400)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_desktop_sidebar.png"))
        print("Captured: screenshot_1440_desktop_sidebar.png")
        # 7. 1440 Desktop Full Page
        ctx_full = browser.new_context(
            viewport={"width": 1440, "height": 1400},
            device_scale_factor=1.5
        )
        page = ctx_full.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        page.wait_for_timeout(1400)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_fullpage.png"))
        print("Captured: screenshot_1440_fullpage.png")
        ctx_full.close()

        browser.close()
        print("All screenshots successfully captured!")

if __name__ == "__main__":
    main()
