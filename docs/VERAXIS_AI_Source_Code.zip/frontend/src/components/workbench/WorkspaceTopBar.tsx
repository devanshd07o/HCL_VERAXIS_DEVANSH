import { useEffect, useState } from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusIsland, type IslandTask } from "@/components/registry/status-island";
import {
  Bookmark,
  KeyRound,
  Menu,
  MessageSquare,
  Moon,
  PanelLeftClose,
  PanelLeftOpen,
  Plus,
  Sun,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { path: "/", label: "Ask", icon: MessageSquare },
  { path: "/dossiers", label: "Saved", icon: Bookmark },
  { path: "/vault", label: "Keys", icon: KeyRound },
];

interface WorkspaceTopBarProps {
  theme: "light" | "dark";
  onThemeChange: (theme: "light" | "dark") => void;
  onNewInquiry: () => void;
  onToggleRail: () => void;
  railOpen: boolean;
  islandTasks: IslandTask[];
  onDismissTask: (id: string) => void;
}

export default function WorkspaceTopBar({
  theme,
  onThemeChange,
  onNewInquiry,
  onToggleRail,
  railOpen,
  islandTasks,
  onDismissTask,
}: WorkspaceTopBarProps) {
  const [activeRoute, setActiveRoute] = useState(() => {
    if (typeof window === "undefined") return "/";
    const h = window.location.hash.replace(/^#/, "");
    return h.startsWith("/") ? h : "/";
  });

  useEffect(() => {
    const onHashChange = () => {
      const h = window.location.hash.replace(/^#/, "");
      setActiveRoute(h.startsWith("/") ? h : "/");
    };
    const onNavEvent = (e: Event) => {
      const ce = e as CustomEvent<string>;
      if (ce.detail) setActiveRoute(ce.detail);
    };
    window.addEventListener("hashchange", onHashChange);
    window.addEventListener("veraxis:nav", onNavEvent);
    return () => {
      window.removeEventListener("hashchange", onHashChange);
      window.removeEventListener("veraxis:nav", onNavEvent);
    };
  }, []);

  const handleNavClick = (path: string) => {
    setActiveRoute(path);
    window.history.replaceState(null, "", `#${path}`);
    window.dispatchEvent(new CustomEvent("veraxis:nav", { detail: path }));
  };

  const renderNavSegment = (isMobile = false) => (
    <Tabs
      value={activeRoute}
      onValueChange={handleNavClick}
      className={cn("inline-flex", isMobile && "w-full max-w-xs justify-center")}
    >
      <TabsList className="h-8 rounded-xl border border-border/80 bg-secondary/50 p-0.5">
        {NAV_ITEMS.map(({ path, label, icon: Icon }) => (
          <TabsTrigger
            key={path}
            value={path}
            className="h-7 gap-1.5 rounded-lg px-3 text-xs font-medium data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-xs"
          >
            <Icon className="size-3.5 shrink-0" />
            <span>{label}</span>
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur-md">
      <div className="mx-auto flex h-14 w-full max-w-[1600px] items-center justify-between gap-2 px-3 sm:px-5 md:grid md:grid-cols-[auto_1fr_auto] md:gap-4">
        <div className="flex shrink-0 items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={onToggleRail}
            aria-label={railOpen ? "Close workspace rail" : "Open workspace rail"}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-card text-foreground transition-colors hover:border-primary hover:text-primary"
          >
            <Menu className="size-4 lg:hidden" />
            {railOpen ? (
              <PanelLeftClose className="hidden size-4 lg:block" />
            ) : (
              <PanelLeftOpen className="hidden size-4 lg:block" />
            )}
          </button>

          <a
            href="#/"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick("/");
            }}
            className="flex shrink-0 items-center gap-2 rounded-lg px-1 py-1 text-foreground no-underline transition-opacity hover:opacity-85"
          >
            <img
              src="/assets/veraxis_logo.png"
              alt="VERAXIS"
              className="size-6 shrink-0 rounded-md border border-border bg-card object-contain p-0.5"
            />
            <span className="font-display whitespace-nowrap text-sm font-extrabold tracking-tight text-foreground">
              VERAXIS
            </span>
          </a>
        </div>

        <div className="hidden min-w-0 items-center justify-center md:flex">
          {renderNavSegment(false)}
        </div>

        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <div className="hidden xl:block">
            <StatusIsland
              tasks={islandTasks}
              onDismiss={onDismissTask}
              dismissAfter={3600}
            />
          </div>

          <button
            type="button"
            onClick={onNewInquiry}
            aria-label="New inquiry"
            className="group flex h-8 items-center gap-1.5 rounded-lg border border-border bg-card/80 px-2.5 text-xs font-semibold text-foreground shadow-2xs transition-all duration-150 hover:border-primary hover:bg-card hover:text-primary active:scale-95"
            title="New inquiry (Ctrl+K)"
          >
            <Plus className="size-3.5 transition-transform duration-200 group-hover:rotate-90 text-primary" />
            <span className="hidden sm:inline">New</span>
          </button>

          <button
            type="button"
            onClick={() => onThemeChange(theme === "dark" ? "light" : "dark")}
            aria-label="Toggle appearance"
            className="group flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-card/80 text-foreground shadow-2xs transition-all duration-150 hover:border-primary hover:bg-card hover:text-primary active:scale-95"
            title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          >
            {theme === "dark" ? (
              <Sun className="size-4 text-amber-400 transition-transform duration-300 group-hover:rotate-45" />
            ) : (
              <Moon className="size-4 text-sky-500 transition-transform duration-300 group-hover:-rotate-12" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
