import { useMemo, useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import SmoothTab, { type SwipeTabItem } from "@/components/registry/smooth-tab";
import AILoadingState, { type AgentStep } from "@/components/registry/ai-loading";
import AIAgentLanes, { type AgentLane } from "@/components/registry/ai-agent-lanes";
import { type ContextSegment } from "@/components/registry/ai-context-meter";
import { ArrowUpRight, Bot, Database, ListTree, PanelRightClose } from "lucide-react";

export interface SourceItem {
  title: string;
  url: string;
  badge?: string;
}

export interface ThinkingStepItem {
  agent?: string;
  step?: string;
}

interface ReportInspectorProps {
  topic?: string | null;
  sources: SourceItem[];
  thinkingSteps?: ThinkingStepItem[] | null;
  duration?: string;
  isRunning?: boolean;
  livePhase?: string;
  contextSegments?: ContextSegment[];
  onToggleCollapse?: () => void;
}

function hostnameLabel(rawUrl: string): string {
  try {
    return new URL(rawUrl).hostname.replace(/^www\./, "");
  } catch {
    return "source";
  }
}

export default function ReportInspector({
  topic,
  sources,
  thinkingSteps,
  duration,
  isRunning = false,
  livePhase = "",
  onToggleCollapse,
}: ReportInspectorProps) {
  const [activeTab, setActiveTab] = useState("sources");

  const mappedSteps: AgentStep[] = useMemo(() => {
    const raw =
      Array.isArray(thinkingSteps) && thinkingSteps.length > 0
        ? thinkingSteps
        : [
            { agent: "Planner", step: "Understand topic & pick best search words" },
            { agent: "Searcher", step: "Search Wikipedia, arXiv & web articles" },
            { agent: "Fact-Checker", step: "Check real numbers, pros, and limits" },
            { agent: "Simple Writer", step: "Write easy-to-read report with examples" },
            { agent: "PDF Maker", step: "Save clean downloadable PDF report" },
          ];

    return raw.map((item, idx) => {
      const activeIdx =
        livePhase === "classify" || livePhase === "rephrase"
          ? 0
          : livePhase === "discovery"
          ? 1
          : livePhase === "auditor"
          ? 2
          : livePhase === "director"
          ? 3
          : raw.length - 1;

      const status: AgentStep["status"] = !isRunning
        ? "done"
        : idx < activeIdx
        ? "done"
        : idx === activeIdx
        ? "running"
        : "pending";

      return {
        id: `step-${idx}`,
        label: item.step || "Processing stage",
        status,
        detail: item.agent ? [`Agent: ${item.agent}`] : undefined,
      };
    });
  }, [thinkingSteps, isRunning, livePhase]);

  const agentLanes: AgentLane[] = useMemo(() => {
    const totalSec = Math.max(4, Number.parseFloat(duration || "8") || 8);
    const s1 = Number((totalSec * 0.25).toFixed(1));
    const s2 = Number((totalSec * 0.62).toFixed(1));
    const s3 = Number(totalSec.toFixed(1));

    return [
      {
        id: "writer",
        name: "Writer",
        steps: [
          {
            tool: "think",
            label: "Pick search words",
            start: 0,
            end: s1,
            result: topic || "Simple question plan",
          },
          {
            tool: "write",
            label: "Write clear report & PDF",
            start: s2,
            end: s3,
            result: `${sources.length} sources cited`,
          },
        ],
        summary: isRunning
          ? "Writing clear report..."
          : `Finished in ${duration || `${s3}s`}`,
      },
      {
        id: "searcher",
        name: "Searcher",
        steps: [
          {
            tool: "search",
            label: "Search Wikipedia, arXiv & web",
            start: Math.max(0.2, s1 * 0.4),
            end: s2,
            result: `${sources.length} links found`,
          },
        ],
        summary: `${sources.length} sources checked`,
      },
      {
        id: "checker",
        name: "Checker",
        steps: [
          {
            tool: "read",
            label: "Verify real numbers & limits",
            start: s1,
            end: Number((s2 + 0.6).toFixed(1)),
            result: "Facts double-checked",
          },
        ],
        summary: "Facts verified",
      },
    ];
  }, [duration, sources.length, topic, isRunning]);

  const tabItems: SwipeTabItem[] = useMemo(
    () => [
      {
        id: "sources",
        title: `Sources (${sources.length})`,
        icon: Database,
        content: (
          <ScrollArea className="h-[380px] pr-2 lg:h-[calc(100vh-16rem)]">
            {sources.length === 0 ? (
              <p className="py-8 text-center text-xs text-muted-foreground">
                {isRunning
                  ? "Querying arXiv, OpenAlex & Wikipedia repositories..."
                  : "No external references attached to this inquiry."}
              </p>
            ) : (
              <div className="flex flex-col gap-1.5 pt-1">
                {sources.map((source, idx) => {
                  const domain = hostnameLabel(source.url);
                  return (
                    <a
                      key={`${source.url}-${idx}`}
                      href={source.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex flex-col gap-1 rounded-lg border border-border/60 bg-card/50 p-2.5 text-card-foreground no-underline transition-all duration-150 hover:border-primary/50 hover:bg-card active:scale-[0.99]"
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <span className="font-mono-tech text-[11px] text-muted-foreground group-hover:text-primary transition-colors">
                          {domain}
                        </span>
                        <ArrowUpRight className="size-3 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-primary" />
                      </div>
                      <span className="line-clamp-2 text-xs font-normal text-foreground leading-snug">
                        {source.title.replace(/^\[.*?\]\s*/, "")}
                      </span>
                    </a>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        ),
      },
      {
        id: "steps",
        title: "Steps",
        icon: ListTree,
        content: (
          <ScrollArea className="h-[380px] pr-2 lg:h-[calc(100vh-16rem)]">
            <AILoadingState steps={mappedSteps} collapseWhenDone={false} />
          </ScrollArea>
        ),
      },
      {
        id: "agents",
        title: "Workflow",
        icon: Bot,
        content: (
          <ScrollArea className="h-[380px] pr-2 lg:h-[calc(100vh-16rem)]">
            <AIAgentLanes
              task={topic || "VERAXIS Research Workflow"}
              lanes={agentLanes}
              answer={`Checked ${sources.length} sources and compiled verified report.`}
            />
          </ScrollArea>
        ),
      },
    ],
    [sources, isRunning, mappedSteps, topic, agentLanes]
  );

  return (
    <div className="flex flex-col gap-2.5 rounded-2xl border border-border/80 bg-card/95 p-3 text-card-foreground lg:h-full">
      <div className="flex items-center justify-between gap-2 border-b border-border/80 pb-2">
        <div className="min-w-0">
          <p className="font-mono-tech text-[10px] font-bold tracking-wider text-primary uppercase">
            Sources &amp; Progress
          </p>
          <p className="truncate text-xs font-bold text-foreground">
            {topic || "Live Research Notes"}
          </p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {duration && (
            <span className="font-mono-tech text-[11px] text-muted-foreground tabular-nums">
              {duration}
            </span>
          )}
          {onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              className="flex size-7 items-center justify-center rounded-lg border border-border/80 bg-secondary/50 text-muted-foreground transition-all duration-150 hover:border-primary/50 hover:text-foreground active:scale-95"
              title="Hide research panel (maximize report)"
              aria-label="Hide research panel"
            >
              <PanelRightClose className="size-3.5" />
            </button>
          )}
        </div>
      </div>

      <div className="min-h-0 flex-1">
        <SmoothTab
          items={tabItems}
          value={activeTab}
          onChange={setActiveTab}
          activeColor="bg-primary/15 border border-primary/40 rounded-lg"
          activeTextColor="text-primary font-semibold"
          label="Evidence Inspector Tabs"
          className="max-w-none"
        />
      </div>
    </div>
  );
}
