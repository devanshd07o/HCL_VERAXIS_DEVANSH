import { useMemo, useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import ParticleButton from "@/components/registry/particle-button";
import { KeyRound, Plus, Trash2, X } from "lucide-react";

export interface SessionRecord {
  id: string;
  title?: string;
  createdAt?: string;
  messages?: unknown[];
}

interface SessionRailProps {
  open: boolean;
  onCloseMobile: () => void;
  sessions: SessionRecord[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  onNewInquiry: () => void;
  onOpenVault: () => void;
  telemetry: { activeKeys: number; totalKeys: number };
}

export default function SessionRail({
  open,
  onCloseMobile,
  sessions,
  activeSessionId,
  onSelectSession,
  onDeleteSession,
  onNewInquiry,
  onOpenVault,
  telemetry,
}: SessionRailProps) {
  const [filterText, setFilterText] = useState("");

  const filteredSessions = useMemo(() => {
    const q = filterText.trim().toLowerCase();
    if (!q) return sessions;
    return sessions.filter((s) =>
      (s.title || "Untitled inquiry").toLowerCase().includes(q)
    );
  }, [sessions, filterText]);

  const railContent = (
    <aside className="flex h-full w-full flex-col bg-card/80 text-card-foreground">
      <div className="flex items-center justify-between gap-2 px-3.5 pt-3.5 pb-2.5">
        <span className="font-mono-tech text-xs font-semibold tracking-wider text-muted-foreground uppercase">
          Past Chats ({sessions.length})
        </span>
        <div className="flex items-center gap-1.5">
          <ParticleButton
            size="sm"
            variant="outline"
            onClick={onNewInquiry}
            className="min-h-[36px] text-xs"
            successLabel="Ready"
          >
            <Plus className="size-3.5" />
            New
          </ParticleButton>
          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close workspace rail"
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg border border-border bg-background text-foreground lg:hidden"
          >
            <X className="size-4" />
          </button>
        </div>
      </div>

      {/* Uiverse 0xnihilism tactile search field */}
      <div className="px-3.5 pb-3">
        <input
          type="search"
          value={filterText}
          onChange={(e) => setFilterText(e.target.value)}
          placeholder="Search past chats..."
          aria-label="Filter saved inquiries"
          className="uv-neo-input text-base sm:text-sm"
        />
      </div>

      <Separator />

      <ScrollArea className="min-h-0 flex-1 px-2.5 py-2.5">
        {filteredSessions.length === 0 ? (
          <div className="px-2 py-8 text-center text-xs text-muted-foreground">
            {sessions.length === 0
              ? "No saved chats yet. Ask a question to get started."
              : "No past chats match your search."}
          </div>
        ) : (
          <ul className="flex flex-col gap-1.5">
            {filteredSessions.map((session) => {
              const isActive = session.id === activeSessionId;
              const msgCount = Array.isArray(session.messages)
                ? session.messages.length
                : 0;
              return (
                <li
                  key={session.id}
                  className={`group flex items-center gap-1 rounded-xl border p-1.5 transition-all duration-150 active:scale-[0.99] ${
                    isActive
                      ? "border-primary bg-primary/10 shadow-2xs"
                      : "border-transparent hover:border-border hover:bg-muted/60"
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => onSelectSession(session.id)}
                    className="flex min-h-[40px] min-w-0 flex-1 flex-col items-start justify-center rounded-lg px-2 py-1 text-left"
                  >
                    <span className="w-full truncate text-xs font-semibold text-foreground transition-transform duration-150 group-hover:translate-x-0.5">
                      {session.title || "Untitled inquiry"}
                    </span>
                    <span className="font-mono-tech text-[11px] text-muted-foreground">
                      {msgCount} {msgCount === 1 ? "turn" : "turns"}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onDeleteSession(session.id)}
                    aria-label={`Delete ${session.title || "inquiry"}`}
                    className="flex min-h-[38px] min-w-[38px] shrink-0 items-center justify-center rounded-lg text-muted-foreground opacity-80 transition-colors hover:bg-destructive/15 hover:text-destructive sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </ScrollArea>

      <Separator />

      <div className="p-3">
        <button
          type="button"
          onClick={onOpenVault}
          className="flex min-h-[44px] w-full items-center justify-between gap-2 rounded-xl border border-border bg-background px-3 py-2 text-left transition-colors hover:border-primary"
        >
          <span className="flex items-center gap-2 text-xs font-semibold text-foreground">
            <KeyRound className="size-3.5 text-primary" />
            API Keys
          </span>
          <Badge variant="secondary" className="font-mono-tech tabular-nums">
            {telemetry.activeKeys}/{telemetry.totalKeys} ready
          </Badge>
        </button>
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop persistent left rail when open */}
      {open && (
        <div className="hidden h-full w-[272px] shrink-0 border-r border-border lg:block">
          {railContent}
        </div>
      )}

      {/* Mobile / tablet drawer overlay */}
      {open && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-black/55 backdrop-blur-xs"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-10 h-full w-[min(86vw,300px)] border-r border-border bg-card shadow-2xl">
            {railContent}
          </div>
        </div>
      )}
    </>
  );
}
