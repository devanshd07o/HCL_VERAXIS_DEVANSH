import { useCallback, useMemo, useRef, useState } from "react";
import {
  MessageScroller,
  MessageScrollerButton,
  MessageScrollerContent,
  MessageScrollerItem,
  MessageScrollerProvider,
  MessageScrollerViewport,
} from "@/components/ui/message-scroller";
import {
  Message,
  MessageContent,
  MessageFooter,
  MessageHeader,
} from "@/components/ui/message";
import { Bubble, BubbleContent } from "@/components/ui/bubble";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import AI_Prompt, {
  type PromptCommand,
} from "@/components/registry/ai-prompt";
import AILoadingState, { type AgentStep } from "@/components/registry/ai-loading";
import AITextLoading from "@/components/registry/ai-text-loading";
import ParticleButton from "@/components/registry/particle-button";
import { BlurFade } from "@/components/registry/blur-fade";
import { TextEffect } from "@/components/registry/text-effect";
import TopoBackground from "@/components/registry/topo-background";
import type { ContextSegment } from "@/components/registry/ai-context-meter";
import VoiceBridge from "./VoiceBridge";
import ReportInspector, {
  type SourceItem,
  type ThinkingStepItem,
} from "./ReportInspector";
import {
  injectTypewriterFrontier,
  renderMarkdownWithKaTeX,
} from "@/lib/markdown";
import { AnimatePresence, motion } from "motion/react";
import {
  ArrowRight,
  BookOpen,
  Copy,
  Download,
  Mic,
  Microscope,
  PanelRightClose,
  PanelRightOpen,
  Square,
  Wand2,
  Zap,
} from "lucide-react";

export interface AttachedDoc {
  name: string;
  content: string;
}

export interface ChatMessageRecord {
  id: string;
  role: "user" | "bot";
  content: string;
  type?: "chat" | "research" | "error";
  sources?: SourceItem[];
  pdf_filename?: string | null;
  topic?: string | null;
  thinkingSteps?: ThinkingStepItem[] | null;
  duration?: string;
  isStreaming?: boolean;
}

interface ChatWorkspaceProps {
  messages: ChatMessageRecord[];
  recentSession?: { id: string; title: string } | null;
  onOpenRecentSession?: (id: string) => void;
  isLoading: boolean;
  researchPriority: boolean;
  onToggleResearchPriority: (next: boolean) => void;
  activeThinkingSteps: ThinkingStepItem[] | null;
  livePhase: string;
  livePhaseLabel: string;
  contextSegments: ContextSegment[];
  onSendQuery: (
    text: string,
    options?: {
      forceResearch?: boolean;
      modeOverride?: "auto" | "fast" | "deep";
      attachments?: AttachedDoc[];
    }
  ) => Promise<void>;
  onStopQuery: () => void;
  onDownloadPdf: (filename: string) => Promise<void>;
}


const VERAXIS_COMMANDS: PromptCommand[] = [
  {
    id: "research",
    label: "research",
    description: "Deep Academic Paper Review (Semantic Scholar + OpenAlex + ArXiv)",
    icon: <Microscope className="size-3.5" />,
  },
  {
    id: "paper",
    label: "paper",
    description: "Scientific Literature Synthesis with 5-column Methodology Matrix",
    icon: <BookOpen className="size-3.5" />,
  },
  {
    id: "enhance",
    label: "enhance",
    description: "Rewrite question clearly before sending",
    icon: <Wand2 className="size-3.5" />,
  },
];

const WORKFLOW_STAGES = [
  { key: "rephrase", label: "1. Topic" },
  { key: "discovery", label: "2. Sources" },
  { key: "auditor", label: "3. Fact-Check" },
  { key: "director", label: "4. Writing" },
  { key: "pdf", label: "5. PDF" },
];

const TEXT_EXTENSIONS = new Set([
  "txt",
  "md",
  "markdown",
  "csv",
  "json",
  "py",
  "ts",
  "tsx",
  "js",
  "jsx",
  "log",
  "yaml",
  "yml",
  "xml",
  "tex",
]);

async function readTextAttachments(
  files: File[]
): Promise<{ docs: AttachedDoc[]; skippedNames: string[] }> {
  const docs: AttachedDoc[] = [];
  const skippedNames: string[] = [];

  for (const file of files.slice(0, 5)) {
    const ext = file.name.split(".").pop()?.toLowerCase() || "";
    const isTextLike =
      file.type.startsWith("text/") ||
      file.type === "application/json" ||
      TEXT_EXTENSIONS.has(ext);

    if (!isTextLike || file.size > 512_000) {
      skippedNames.push(file.name);
      continue;
    }

    try {
      const content = await file.text();
      if (content.trim()) {
        docs.push({ name: file.name, content: content.slice(0, 6000) });
      }
    } catch {
      skippedNames.push(file.name);
    }
  }

  return { docs, skippedNames };
}

async function copyToClipboard(text: string): Promise<void> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
  } catch {
    // Fall back to execCommand when Clipboard API permission is restricted
  }
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.setAttribute("readonly", "");
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  const ok = document.execCommand("copy");
  ta.remove();
  if (!ok) {
    throw new Error("Copy failed");
  }
}

export default function ChatWorkspace({
  messages,
  recentSession,
  onOpenRecentSession,
  isLoading,
  researchPriority,
  onToggleResearchPriority,
  activeThinkingSteps,
  livePhase,
  livePhaseLabel,
  contextSegments,
  onSendQuery,
  onStopQuery,
  onDownloadPdf,
}: ChatWorkspaceProps) {
  const [draftQuery, setDraftQuery] = useState("");
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [inspectedMessageId, setInspectedMessageId] = useState<string | null>(null);
  const [mobileInspectorOpen, setMobileInspectorOpen] = useState(false);
  const [composerNotice, setComposerNotice] = useState("");
  const articleRefs = useRef<Record<string, HTMLElement | null>>({});

  const handleMarkdownClick = useCallback(async (e: React.MouseEvent<HTMLDivElement>) => {
    const target = (e.target as HTMLElement).closest(".uv-code-copy-btn");
    if (!target) return;
    const code = target.getAttribute("data-code");
    if (!code) return;

    try {
      const rawCode = decodeURIComponent(code);
      await copyToClipboard(rawCode);

      const span = target.querySelector("span");
      if (span) {
        const orig = span.textContent;
        span.textContent = "Copied!";
        target.classList.add("text-emerald-400", "border-emerald-500/80");
        setTimeout(() => {
          span.textContent = orig;
          target.classList.remove("text-emerald-400", "border-emerald-500/80");
        }, 1800);
      }
    } catch (err) {
      console.error("Failed to copy code block", err);
    }
  }, []);

  const researchMessages = useMemo(
    () => messages.filter((m) => m.type === "research"),
    [messages]
  );

  const activeResearchMessage = useMemo(() => {
    if (inspectedMessageId) {
      const hit = researchMessages.find((m) => m.id === inspectedMessageId);
      if (hit) return hit;
    }
    return researchMessages[researchMessages.length - 1] || null;
  }, [researchMessages, inspectedMessageId]);

  const [inspectorCollapsed, setInspectorCollapsed] = useState(false);

  const hasInspectorContent =
    Boolean(activeResearchMessage) || (isLoading && Boolean(activeThinkingSteps));
  const showInspectorColumn = hasInspectorContent && !inspectorCollapsed;

  const liveAgentSteps: AgentStep[] = useMemo(() => {
    if (activeThinkingSteps && activeThinkingSteps.length > 0) {
      const activeIdx =
        livePhase === "classify"
          ? 0
          : livePhase === "rephrase"
          ? 1
          : livePhase === "discovery"
          ? 2
          : livePhase === "analyst"
          ? 3
          : livePhase === "auditor"
          ? 4
          : livePhase === "director" || livePhase === "pdf"
          ? 5
          : 0;

      return activeThinkingSteps.map((st, idx) => ({
        id: `live-${idx}`,
        label: st.step || "Working",
        status: idx < activeIdx ? "done" : idx === activeIdx ? "running" : "pending",
        detail: st.agent ? [st.agent] : undefined,
      }));
    }
    return [
      {
        id: "phase-router",
        label: livePhaseLabel || "Classifying inquiry intent...",
        status: "running",
      },
    ];
  }, [activeThinkingSteps, livePhase, livePhaseLabel]);

  const handleEnhancePrompt = useCallback(
    async (inputOverride?: string) => {
      const sourceText = (inputOverride ?? draftQuery).trim();
      if (!sourceText) {
        throw new Error("Enter a topic before enhancing.");
      }
      setComposerNotice("");
      const res = await fetch("/api/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: sourceText }),
      });
      if (!res.ok) {
        throw new Error(`Enhance failed (${res.status})`);
      }
      const data = await res.json();
      if (data.enhanced_query) {
        setDraftQuery(data.enhanced_query);
      }
    },
    [draftQuery]
  );

  const handlePromptSubmit = async (
    value: string,
    model: string,
    options: {
      effort: string | null;
      files: File[];
      command: PromptCommand | null;
    }
  ) => {
    setComposerNotice("");

    if (options.command?.id === "enhance") {
      try {
        await handleEnhancePrompt(value);
      } catch (err) {
        setComposerNotice(
          err instanceof Error ? err.message : "Unable to enhance query."
        );
      }
      return;
    }

    const { docs, skippedNames } = await readTextAttachments(options.files || []);
    if (skippedNames.length > 0) {
      setComposerNotice(
        `Skipped unsupported/oversized file(s): ${skippedNames.join(", ")}. Supported: .txt, .md, .csv, .json, code (<500KB).`
      );
    }

    let modeOverride: "auto" | "fast" | "deep" = "auto";
    if (
      options.command?.id === "research" ||
      options.command?.id === "paper" ||
      model === "Deep Research" ||
      options.effort === "Deep"
    ) {
      modeOverride = "deep";
    } else if (model === "Fast Chat" || options.effort === "Fast") {
      modeOverride = "fast";
    }

    const forceResearch =
      modeOverride === "deep"
        ? true
        : modeOverride === "fast"
        ? false
        : researchPriority;

    setDraftQuery("");
    await onSendQuery(value, {
      forceResearch,
      modeOverride,
      attachments: docs,
    });
  };

  const renderComposer = (heroMode: boolean) => (
    <div className={heroMode ? "relative w-full max-w-2xl" : "mx-auto w-full max-w-4xl"}>
      <VoiceBridge
        open={voiceOpen}
        onClose={() => setVoiceOpen(false)}
        onTranscriptCommit={(spoken) =>
          setDraftQuery((prev) => (prev ? `${prev.trim()} ${spoken}` : spoken))
        }
      />

      {composerNotice && (
        <p
          className="mb-2 rounded-lg border border-primary/40 bg-primary/10 px-3 py-1.5 text-xs text-foreground"
          role="status"
        >
          {composerNotice}
        </p>
      )}

      <div className="relative rounded-2xl border border-border/80 bg-card/90 shadow-sm backdrop-blur-sm">
        <AI_Prompt
          headerText=""
          models={[]}
          commands={VERAXIS_COMMANDS}
          value={draftQuery}
          onValueChange={setDraftQuery}
          onSubmit={handlePromptSubmit}
          onStop={onStopQuery}
          placeholder="Ask anything in simple words, attach a .txt/.md file, or type /research..."
          className="max-w-none py-0"
          toolbarExtra={
            <div className="flex items-center gap-1 sm:gap-1.5">
              {/* Mode Toggle: Quick vs Deep Research */}
              <button
                type="button"
                onClick={() => onToggleResearchPriority(!researchPriority)}
                className={`inline-flex h-7 sm:h-8 items-center gap-1 sm:gap-1.5 rounded-lg px-2 text-xs font-semibold transition-all duration-150 ${
                  researchPriority
                    ? "border border-primary bg-primary/15 text-primary"
                    : "border border-border/80 bg-secondary/50 text-muted-foreground hover:border-primary/50 hover:text-foreground"
                }`}
                title={researchPriority ? "Deep Research active (multi-database paper review)" : "Quick Answer mode active"}
              >
                {researchPriority ? (
                  <Microscope className="size-3.5 text-primary shrink-0" />
                ) : (
                  <Zap className="size-3.5 text-muted-foreground shrink-0" />
                )}
                <span className="text-[11px] sm:text-xs">
                  {researchPriority ? "Deep" : "Quick"}
                </span>
              </button>

              <button
                type="button"
                aria-label="Open voice query dictation"
                onClick={() => setVoiceOpen((v) => !v)}
                className={`flex size-7 sm:size-8 items-center justify-center rounded-lg border transition-all duration-150 ${
                  voiceOpen
                    ? "border-primary bg-primary text-primary-foreground animate-pulse"
                    : "border-border/80 bg-secondary/50 text-muted-foreground hover:border-primary/50 hover:text-foreground"
                }`}
                title="Voice dictation"
              >
                <Mic className="size-3.5" />
              </button>
            </div>
          }
          renderSendButton={({ canSend, responding, onSend, onStop }) =>
            responding || isLoading ? (
              <button
                type="button"
                onClick={onStop}
                aria-label="Stop generation"
                className="flex h-7 sm:h-8 items-center justify-center gap-1.5 rounded-lg border border-primary bg-primary px-2.5 sm:px-3 text-xs font-bold text-primary-foreground transition-all duration-150"
              >
                <Square className="size-3 fill-current" />
                <span className="hidden sm:inline">Stop</span>
              </button>
            ) : (
              <button
                type="button"
                disabled={!canSend}
                onClick={onSend}
                aria-label="Submit inquiry"
                className="flex h-7 sm:h-8 items-center justify-center gap-1.5 rounded-lg border border-primary/50 bg-primary px-2.5 sm:px-4 text-xs font-bold tracking-wide uppercase text-primary-foreground shadow-xs transition-all duration-150 hover:bg-primary/90 disabled:opacity-40"
              >
                <span className="hidden sm:inline">Ask</span>
                <ArrowRight className="size-3.5" />
              </button>
            )
          }
        />
      </div>
    </div>
  );

  if (messages.length === 0 && !isLoading) {
    return (
      <div className="relative flex min-h-0 flex-1 flex-col items-center justify-center overflow-hidden px-4 py-8">
        {/* Interactive KokonutUI Survey Contour Terrain Backdrop */}
        <div className="pointer-events-auto absolute inset-0 text-muted-foreground/45 opacity-40">
          <TopoBackground
            className="h-full w-full bg-transparent"
            interval={14}
            speed={0.45}
            interactive
            labels={false}
          >
            {null}
          </TopoBackground>
        </div>

        <div className="relative z-10 flex w-full max-w-2xl flex-col items-center text-center">
          <TextEffect
            per="word"
            preset="fade-in-blur"
            speedReveal={1.4}
            as="h1"
            className="font-display text-2xl font-extrabold text-foreground sm:text-4xl lg:text-5xl tracking-tight"
          >
            Ask anything. Understand clearly.
          </TextEffect>

          <BlurFade delay={0.14}>
            <p className="mt-2.5 mb-6 max-w-prose text-xs text-muted-foreground sm:text-base">
              Quick answers for everyday doubts — or switch on Deep Research for checked facts, real links, and a neat PDF.
            </p>
          </BlurFade>

          {renderComposer(true)}

          {recentSession && onOpenRecentSession && (
            <BlurFade delay={0.22}>
              <div className="mt-4 flex items-center justify-center">
                <button
                  type="button"
                  onClick={() => onOpenRecentSession(recentSession.id)}
                  className="inline-flex min-h-[36px] max-w-[280px] items-center gap-1.5 rounded-full border border-border/80 bg-secondary/50 px-3.5 text-xs font-medium text-foreground transition-all duration-150 hover:border-primary/50"
                >
                  <span className="truncate">Resume: {recentSession.title}</span>
                  <ArrowRight className="size-3.5 shrink-0 text-primary" />
                </button>
              </div>
            </BlurFade>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      className={`grid min-h-0 flex-1 ${
        showInspectorColumn
          ? "lg:grid-cols-[minmax(0,1fr)_390px] xl:grid-cols-[minmax(0,1fr)_440px]"
          : "grid-cols-1"
      }`}
    >
      {/* Center Message & Single-Axis Dossier Canvas */}
      <div className="flex min-h-0 min-w-0 flex-col">
        <MessageScrollerProvider>
          <MessageScroller className="min-h-0 flex-1">
            <MessageScrollerViewport className="px-3 py-5 sm:px-6">
              <MessageScrollerContent className="mx-auto max-w-4xl gap-6">
                {messages.map((msg) => {
                  if (msg.role === "user") {
                    return (
                      <MessageScrollerItem key={msg.id}>
                        <BlurFade duration={0.22} offset={4}>
                          <Message align="end">
                            <MessageContent>
                              <Bubble align="end" variant="secondary">
                                <BubbleContent className="rounded-2xl border border-border/80 bg-secondary/80 px-4 py-2 text-sm font-medium text-foreground sm:text-[15px] shadow-xs">
                                  {msg.content}
                                </BubbleContent>
                              </Bubble>
                            </MessageContent>
                          </Message>
                        </BlurFade>
                      </MessageScrollerItem>
                    );
                  }

                  if (msg.type === "research") {
                    const sourceCount = msg.sources?.length ?? 0;
                    const compiledHtmlRaw = renderMarkdownWithKaTeX(
                      msg.content,
                      Boolean(msg.isStreaming)
                    );
                    const compiledHtml = msg.isStreaming
                      ? injectTypewriterFrontier(compiledHtmlRaw)
                      : compiledHtmlRaw;
                    const activeStageIdx = WORKFLOW_STAGES.findIndex(
                      (s) => s.key === livePhase
                    );

                    return (
                      <MessageScrollerItem key={msg.id} scrollAnchor>
                        <BlurFade duration={0.25} offset={4}>
                          <article
                            ref={(el) => {
                              articleRefs.current[msg.id] = el;
                            }}
                            className="rounded-2xl border border-border bg-card/95 p-4 text-card-foreground shadow-xs sm:p-6"
                          >
                            <header className="mb-4 flex items-center justify-between gap-3 border-b border-border/60 pb-3">
                              <div className="flex min-w-0 flex-wrap items-center gap-2">
                                {msg.topic ? (
                                  <h2 className="truncate text-base font-semibold text-foreground">
                                    {msg.topic}
                                  </h2>
                                ) : (
                                  <span className="text-sm font-medium text-foreground">
                                    Research Dossier
                                  </span>
                                )}
                                {sourceCount > 0 && (
                                  <span className="font-mono-tech text-xs text-muted-foreground tabular-nums">
                                    · {sourceCount} sources
                                  </span>
                                )}
                                {msg.duration && (
                                  <span className="font-mono-tech text-xs text-muted-foreground tabular-nums">
                                    · {msg.duration}
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-1.5 shrink-0">
                                {!msg.isStreaming && (
                                  <button
                                    type="button"
                                    onClick={() => copyToClipboard(msg.content)}
                                    className="flex h-7 items-center gap-1 rounded-md border border-border/80 bg-secondary/30 px-2 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/60 hover:text-foreground active:scale-95"
                                    title="Copy report markdown"
                                  >
                                    <Copy className="size-3" />
                                    <span>Copy</span>
                                  </button>
                                )}

                                {msg.pdf_filename && (
                                  <button
                                    type="button"
                                    onClick={() => onDownloadPdf(msg.pdf_filename!)}
                                    className="flex h-7 items-center gap-1 rounded-md border border-primary/40 bg-primary/10 px-2.5 text-xs font-medium text-primary transition-colors hover:bg-primary/20 active:scale-95"
                                    title="Download PDF"
                                  >
                                    <Download className="size-3" />
                                    <span>PDF</span>
                                  </button>
                                )}

                                <button
                                  type="button"
                                  onClick={() => {
                                    setInspectedMessageId(msg.id);
                                    if (typeof window !== "undefined" && window.innerWidth < 1024) {
                                      setMobileInspectorOpen(true);
                                    } else {
                                      setInspectorCollapsed((prev) => !prev);
                                    }
                                  }}
                                  className="flex size-7 items-center justify-center rounded-md border border-border/80 bg-secondary/30 text-muted-foreground transition-colors hover:border-primary/60 hover:text-foreground active:scale-95"
                                  title={inspectorCollapsed ? "Show Sources & Steps" : "Hide Panel"}
                                >
                                  {inspectorCollapsed ? (
                                    <PanelRightOpen className="size-3.5" />
                                  ) : (
                                    <PanelRightClose className="size-3.5" />
                                  )}
                                </button>
                              </div>
                            </header>

                            {msg.isStreaming && (
                              <div className="mb-4 flex flex-col gap-2 rounded-xl border border-primary/30 bg-background/70 px-3 py-2.5">
                                <div className="flex flex-wrap items-center gap-1.5">
                                  {WORKFLOW_STAGES.map((st, sIdx) => {
                                    const done = activeStageIdx > sIdx;
                                    const running = activeStageIdx === sIdx;
                                    return (
                                      <span
                                        key={st.key}
                                        className={`font-mono-tech rounded-md border px-2 py-0.5 text-[11px] font-semibold ${
                                          running
                                            ? "border-primary bg-primary text-primary-foreground"
                                            : done
                                            ? "border-primary/40 bg-primary/15 text-primary"
                                            : "border-border bg-card text-muted-foreground"
                                        }`}
                                      >
                                        {st.label}
                                      </span>
                                    );
                                  })}
                                </div>
                                <AITextLoading
                                  texts={[
                                    livePhaseLabel || "Writing clear answer...",
                                    "Checking numbers & examples...",
                                    "Formatting clean sections...",
                                  ]}
                                  interval={1600}
                                  showElapsed
                                />
                              </div>
                            )}

                            <div
                              className="prose-dossier"
                              onClick={handleMarkdownClick}
                              dangerouslySetInnerHTML={{ __html: compiledHtml }}
                            />
                          </article>
                        </BlurFade>
                      </MessageScrollerItem>
                    );
                  }

                  if (msg.type === "error") {
                    return (
                      <MessageScrollerItem key={msg.id}>
                        <Message align="start">
                          <MessageContent>
                            <Bubble align="start" variant="destructive">
                              <BubbleContent>{msg.content}</BubbleContent>
                            </Bubble>
                          </MessageContent>
                        </Message>
                      </MessageScrollerItem>
                    );
                  }

                  /* Lightweight inline chat bubble for casual/fast responses */
                  const casualHtmlRaw = renderMarkdownWithKaTeX(
                    msg.content,
                    Boolean(msg.isStreaming)
                  );
                  const casualHtml = msg.isStreaming
                    ? injectTypewriterFrontier(casualHtmlRaw)
                    : casualHtmlRaw;
                  return (
                    <MessageScrollerItem key={msg.id}>
                      <BlurFade duration={0.2} offset={4}>
                        <Message align="start">
                          <MessageContent>
                            <MessageHeader>VERAXIS</MessageHeader>
                            <Bubble align="start" variant="secondary">
                              <BubbleContent>
                                <div
                                  className="prose-dossier text-sm sm:text-[15px]"
                                  onClick={handleMarkdownClick}
                                  dangerouslySetInnerHTML={{ __html: casualHtml }}
                                />
                              </BubbleContent>
                            </Bubble>
                            <MessageFooter className="gap-2">
                              {msg.duration && (
                                <span className="font-mono-tech tabular-nums">
                                  {msg.duration}
                                </span>
                              )}
                              <ParticleButton
                                size="xs"
                                variant="ghost"
                                onClick={() => copyToClipboard(msg.content)}
                                successLabel="Copied"
                                className="h-7 text-[11px]"
                              >
                                <Copy className="size-3" />
                                Copy
                              </ParticleButton>
                            </MessageFooter>
                          </MessageContent>
                        </Message>
                      </BlurFade>
                    </MessageScrollerItem>
                  );
                })}

                {isLoading &&
                  !messages.some((m) => m.isStreaming && m.type === "research") && (
                    <MessageScrollerItem>
                      <div className="max-w-xl">
                        <AILoadingState
                          steps={liveAgentSteps}
                          collapseWhenDone={false}
                        />
                      </div>
                    </MessageScrollerItem>
                  )}
              </MessageScrollerContent>
            </MessageScrollerViewport>

            <MessageScrollerButton className="inset-s-auto right-5 translate-x-0 border border-primary/40 bg-card text-primary shadow-xl data-[direction=end]:bottom-3" />
          </MessageScroller>
        </MessageScrollerProvider>

        {/* Bottom Docked Composer */}
        <div className="border-t border-border bg-background/95 px-3 py-3 sm:px-5">
          {renderComposer(false)}
        </div>
      </div>

      {/* Desktop Right Inspector Column */}
      {showInspectorColumn && (
        <aside className="hidden min-h-0 border-l border-border bg-background/70 p-3.5 lg:block transition-all duration-300">
          <ReportInspector
            topic={activeResearchMessage?.topic}
            sources={activeResearchMessage?.sources || []}
            thinkingSteps={
              isLoading && activeThinkingSteps
                ? activeThinkingSteps
                : activeResearchMessage?.thinkingSteps
            }
            duration={activeResearchMessage?.duration}
            isRunning={isLoading}
            livePhase={livePhase}
            contextSegments={contextSegments}
            onToggleCollapse={() => setInspectorCollapsed(true)}
          />
        </aside>
      )}

      {/* Floating Dock Toggle to Restore Research Inspector */}
      <AnimatePresence>
        {hasInspectorContent && inspectorCollapsed && (
          <motion.div
            initial={{ opacity: 0, x: 24, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 24, scale: 0.95 }}
            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
            className="fixed right-5 top-18 z-40 hidden lg:block"
          >
            <button
              type="button"
              onClick={() => setInspectorCollapsed(false)}
              className="group flex h-9 items-center gap-2 rounded-xl border border-primary/40 bg-card/95 px-3.5 text-xs font-semibold text-foreground shadow-lg backdrop-blur-md transition-all duration-200 hover:border-primary hover:bg-card hover:shadow-primary/10 active:scale-95"
              title="Expand Sources & Research Steps panel"
            >
              <PanelRightOpen className="size-4 text-primary transition-transform duration-200 group-hover:scale-110" />
              <span className="font-medium">Sources &amp; Steps</span>
              {(activeResearchMessage?.sources?.length ?? 0) > 0 && (
                <span className="rounded-full bg-primary/15 px-1.5 py-0.5 font-mono-tech text-[10px] font-bold text-primary">
                  {activeResearchMessage?.sources?.length}
                </span>
              )}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile / Tablet Evidence Inspector Dialog */}
      <Dialog open={mobileInspectorOpen} onOpenChange={setMobileInspectorOpen}>
        <DialogContent className="max-h-[85vh] max-w-lg overflow-hidden p-4">
          <DialogHeader>
            <DialogTitle>Sources &amp; Progress</DialogTitle>
          </DialogHeader>
          <div className="max-h-[70vh] overflow-y-auto">
            <ReportInspector
              topic={activeResearchMessage?.topic}
              sources={activeResearchMessage?.sources || []}
              thinkingSteps={activeResearchMessage?.thinkingSteps}
              duration={activeResearchMessage?.duration}
              isRunning={isLoading}
              livePhase={livePhase}
              contextSegments={contextSegments}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
