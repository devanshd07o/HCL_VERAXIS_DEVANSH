import { useMemo, useState } from "react";
import { MagicCard } from "@/components/registry/magic-card";
import { BlurFade } from "@/components/registry/blur-fade";
import { NumberTicker } from "@/components/registry/number-ticker";
import ParticleButton from "@/components/registry/particle-button";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, FileText, Trash2 } from "lucide-react";

interface ArchivedMessage {
  id: string;
  role: string;
  content: string;
  type?: string;
  topic?: string | null;
  sources?: Array<{ title: string; url: string; badge?: string }>;
  pdf_filename?: string | null;
  duration?: string;
}

export interface ArchivedSession {
  id: string;
  title?: string;
  createdAt?: string;
  messages?: ArchivedMessage[];
}

interface DossiersArchiveProps {
  sessions: ArchivedSession[];
  onOpenSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  onDownloadPdf: (filename: string) => Promise<void>;
}

export default function DossiersArchive({
  sessions,
  onOpenSession,
  onDeleteSession,
  onDownloadPdf,
}: DossiersArchiveProps) {
  const [query, setQuery] = useState("");

  const items = useMemo(() => {
    const q = query.trim().toLowerCase();
    return sessions
      .map((s) => {
        const msgs = Array.isArray(s.messages) ? s.messages : [];
        const researchMsgs = msgs.filter((m) => m.type === "research");
        const latestResearch = researchMsgs[researchMsgs.length - 1] || null;
        return {
          session: s,
          researchCount: researchMsgs.length,
          turnCount: msgs.length,
          latestResearch,
        };
      })
      .filter(({ session, latestResearch }) => {
        if (!q) return true;
        const hay = `${session.title || ""} ${latestResearch?.topic || ""}`.toLowerCase();
        return hay.includes(q);
      });
  }, [sessions, query]);

  const totalDossiers = useMemo(
    () => items.reduce((sum, item) => sum + item.researchCount, 0),
    [items]
  );

  return (
    <section className="mx-auto flex w-full max-w-6xl flex-col gap-6 px-4 py-8 sm:px-6">
      <div className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-mono-tech text-xs font-semibold tracking-wider text-primary uppercase">
              Your Library
            </span>
            <Badge variant="secondary" className="font-mono-tech tabular-nums">
              <NumberTicker value={totalDossiers} className="text-foreground" /> reports
            </Badge>
          </div>
          <h1 className="font-display mt-1 text-2xl font-extrabold text-foreground sm:text-3xl">
            Saved Chats & Reports
          </h1>
          <p className="mt-1 max-w-prose text-sm text-muted-foreground">
            Open any past conversation, read your checked sources, or download saved PDFs.
          </p>
        </div>

        <div className="w-full sm:w-72">
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search saved reports..."
            aria-label="Search dossiers"
            className="uv-neo-input"
          />
        </div>
      </div>

      {items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-card/60 px-6 py-12 text-center">
          <p className="text-sm font-medium text-foreground">
            {sessions.length === 0
              ? "No archived inquiries yet."
              : "No sessions match that filter."}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Run an inquiry inside Workbench and it will appear here automatically.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {items.map(({ session, researchCount, turnCount, latestResearch }, idx) => (
            <BlurFade key={session.id} duration={0.2} delay={Math.min(idx * 0.025, 0.12)} blur="0px">
              <MagicCard
                gradientColor="var(--gold)"
                gradientFrom="var(--gold)"
                gradientTo="var(--gold-bright)"
                gradientOpacity={0.14}
                className="flex h-full flex-col justify-between gap-4 rounded-2xl p-4"
              >
                <div className="flex flex-col gap-2">
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="font-display line-clamp-2 text-base font-bold text-foreground">
                      {session.title || "Untitled inquiry"}
                    </h2>
                    <Badge variant="secondary" className="font-mono-tech shrink-0">
                      {researchCount > 0
                        ? `${researchCount} ${researchCount === 1 ? "report" : "reports"}`
                        : `${turnCount} ${turnCount === 1 ? "turn" : "turns"}`}
                    </Badge>
                  </div>

                  {latestResearch?.topic && (
                    <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <FileText className="size-3.5 shrink-0 text-primary" />
                      <span className="truncate">{latestResearch.topic}</span>
                    </p>
                  )}

                  {session.createdAt && (
                    <p className="font-mono-tech text-[11px] text-muted-foreground">
                      {new Date(session.createdAt).toLocaleString()}
                    </p>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-2">
                  <ParticleButton
                    size="sm"
                    onClick={() => onOpenSession(session.id)}
                    className="min-h-[40px] flex-1"
                    successLabel="Opened"
                  >
                    Open
                    <ArrowUpRight className="size-3.5" />
                  </ParticleButton>

                  {latestResearch?.pdf_filename && (
                    <button
                      type="button"
                      onClick={() => onDownloadPdf(latestResearch.pdf_filename!)}
                      className="uv-download-btn min-h-[40px] px-4 py-2 text-xs"
                    >
                      PDF
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => onDeleteSession(session.id)}
                    aria-label={`Delete ${session.title || "session"}`}
                    className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl border border-border bg-background text-muted-foreground transition-colors hover:border-destructive hover:text-destructive"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              </MagicCard>
            </BlurFade>
          ))}
        </div>
      )}
    </section>
  );
}
