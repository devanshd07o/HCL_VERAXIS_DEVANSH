import { useCallback, useEffect, useRef, useState } from "react";
import { MagicCard } from "@/components/registry/magic-card";
import { ShimmerButton } from "@/components/registry/shimmer-button";
import { NumberTicker } from "@/components/registry/number-ticker";
import ParticleButton from "@/components/registry/particle-button";
import HoldButton from "@/components/registry/hold-button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, KeyRound, RefreshCw } from "lucide-react";

interface KeyRecord {
  id: number;
  masked: string;
  key_prefix: string;
  status: "active" | "cooldown";
  cooldown_remaining: number;
}

interface TelemetrySnapshot {
  total_keys?: number;
  active_keys?: number;
  cooling_down?: number;
  primary_model?: string;
  fast_model?: string;
  gemini_available?: boolean;
}

interface VaultSettingsProps {
  fontFamily: string;
  onFontFamilyChange: (font: string) => void;
  fontSize: string;
  onFontSizeChange: (size: string) => void;
  onTelemetrySync: (next: { activeKeys: number; totalKeys: number }) => void;
}

const FONT_OPTIONS = ["Manrope", "Bricolage Grotesque", "Inter"];
const SIZE_OPTIONS = ["15px", "16px", "18px"];

export default function VaultSettings({
  fontFamily,
  onFontFamilyChange,
  fontSize,
  onFontSizeChange,
  onTelemetrySync,
}: VaultSettingsProps) {
  const [keys, setKeys] = useState<KeyRecord[]>([]);
  const [telemetry, setTelemetry] = useState<TelemetrySnapshot>({});
  const [newKey, setNewKey] = useState("");
  const [statusMsg, setStatusMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(true);
  const [fontMenuOpen, setFontMenuOpen] = useState(false);
  const [sizeMenuOpen, setSizeMenuOpen] = useState(false);

  const syncTelemetryRef = useRef(onTelemetrySync);
  useEffect(() => {
    syncTelemetryRef.current = onTelemetrySync;
  });

  const loadVault = useCallback(async () => {
    setErrorMsg("");
    setLoading(true);
    try {
      const [keysRes, statusRes] = await Promise.all([
        fetch("/api/keys"),
        fetch("/api/status"),
      ]);
      if (keysRes.ok) {
        const kd = await keysRes.json();
        setKeys(Array.isArray(kd.keys) ? kd.keys : []);
        syncTelemetryRef.current({
          activeKeys: kd.active_keys ?? 0,
          totalKeys: kd.total_keys ?? 0,
        });
      }
      if (statusRes.ok) {
        const sd = await statusRes.json();
        if (sd?.telemetry) setTelemetry(sd.telemetry);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Failed to load key vault.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const [keysRes, statusRes] = await Promise.all([
          fetch("/api/keys"),
          fetch("/api/status"),
        ]);
        if (!active) return;
        if (keysRes.ok) {
          const kd = await keysRes.json();
          if (!active) return;
          setKeys(Array.isArray(kd.keys) ? kd.keys : []);
          syncTelemetryRef.current({
            activeKeys: kd.active_keys ?? 0,
            totalKeys: kd.total_keys ?? 0,
          });
        }
        if (statusRes.ok) {
          const sd = await statusRes.json();
          if (active && sd?.telemetry) setTelemetry(sd.telemetry);
        }
      } catch (err) {
        if (active) {
          setErrorMsg(err instanceof Error ? err.message : "Failed to load key vault.");
        }
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const handleAddKey = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newKey.trim();
    if (!trimmed) {
      setErrorMsg("Enter a valid API key before submitting.");
      return;
    }
    setErrorMsg("");
    setStatusMsg("");
    try {
      const res = await fetch("/api/keys/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: trimmed }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data.detail || `Failed (${res.status})`);
      }
      setNewKey("");
      setStatusMsg(data.message || "Key added to pool.");
      await loadVault();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Unable to add key.");
    }
  };

  const handleRemoveKey = async (maskedKey: string) => {
    setErrorMsg("");
    setStatusMsg("");
    try {
      const res = await fetch("/api/keys/remove", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: maskedKey }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data.detail || `Failed (${res.status})`);
      }
      setStatusMsg(data.message || "Key removed.");
      await loadVault();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Unable to remove key.");
      throw err;
    }
  };

  return (
    <section className="mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-border pb-6">
        <div>
          <p className="font-mono-tech text-xs font-semibold tracking-wider text-primary uppercase">
            Settings & Keys
          </p>
          <h1 className="font-display mt-1 text-2xl font-extrabold text-foreground sm:text-3xl">
            API Keys & Reading Style
          </h1>
          <p className="mt-1 max-w-prose text-sm text-muted-foreground">
            Add or manage your Groq API keys, check active AI models, and choose a comfortable font.
          </p>
        </div>

        <ParticleButton
          variant="outline"
          onClick={loadVault}
          className="min-h-[44px]"
          successLabel="Synced"
        >
          <RefreshCw className="size-4" />
          Refresh Telemetry
        </ParticleButton>
      </div>

      {/* Live backend model telemetry */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <MagicCard
          gradientColor="var(--gold)"
          gradientFrom="var(--gold)"
          gradientTo="var(--gold-bright)"
          gradientOpacity={0.14}
          className="rounded-2xl p-4"
        >
          <span className="font-mono-tech text-[11px] text-muted-foreground uppercase">
            Primary Synthesis Model
          </span>
          <p className="font-mono-tech mt-1 truncate text-sm font-bold text-foreground">
            {telemetry.primary_model || "Connecting..."}
          </p>
        </MagicCard>

        <MagicCard
          gradientColor="var(--gold)"
          gradientFrom="var(--gold)"
          gradientTo="var(--gold-bright)"
          gradientOpacity={0.14}
          className="rounded-2xl p-4"
        >
          <span className="font-mono-tech text-[11px] text-muted-foreground uppercase">
            Fast Classifier Model
          </span>
          <p className="font-mono-tech mt-1 truncate text-sm font-bold text-foreground">
            {telemetry.fast_model || "Connecting..."}
          </p>
        </MagicCard>

        <MagicCard
          gradientColor="var(--gold)"
          gradientFrom="var(--gold)"
          gradientTo="var(--gold-bright)"
          gradientOpacity={0.14}
          className="rounded-2xl p-4"
        >
          <span className="font-mono-tech text-[11px] text-muted-foreground uppercase">
            Active Key Pool
          </span>
          <p className="font-mono-tech mt-1 text-sm font-bold text-foreground tabular-nums">
            <NumberTicker
              value={telemetry.active_keys ?? keys.length}
              className="text-primary"
            />{" "}
            active /{" "}
            <NumberTicker
              value={telemetry.total_keys ?? keys.length}
              className="text-foreground"
            />{" "}
            total
          </p>
        </MagicCard>
      </div>

      {/* Key Pool Management */}
      <div className="rounded-2xl border border-border bg-card/85 p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <KeyRound className="size-4 text-primary" />
            <h2 className="font-display text-lg font-bold text-foreground">
              Groq Key Rotation Pool (Max 5)
            </h2>
          </div>
          <span className="font-mono-tech text-[11px] text-muted-foreground">
            Hold Remove button to revoke a key safely
          </span>
        </div>

        <form onSubmit={handleAddKey} className="mb-4 flex flex-col gap-3 sm:flex-row">
          <input
            type="password"
            value={newKey}
            onChange={(e) => setNewKey(e.target.value)}
            placeholder="Paste gsk_... key"
            aria-label="New Groq API key"
            className="uv-neo-input flex-1"
          />
          <ShimmerButton
            type="submit"
            background="var(--primary)"
            shimmerColor="var(--gold-bright)"
            borderRadius="12px"
            className="min-h-[44px] font-bold text-primary-foreground"
          >
            Add Key
          </ShimmerButton>
        </form>

        {statusMsg && (
          <p className="mb-3 rounded-lg border border-primary/40 bg-primary/10 px-3 py-2 text-xs font-medium text-foreground">
            {statusMsg}
          </p>
        )}
        {errorMsg && (
          <p
            className="mb-3 rounded-lg border border-destructive/40 bg-destructive/15 px-3 py-2 text-xs font-medium text-foreground"
            role="alert"
          >
            {errorMsg}
          </p>
        )}

        {loading ? (
          <p className="py-4 text-xs text-muted-foreground">Loading active key vault...</p>
        ) : (
          <div className="flex flex-col gap-2.5">
            {keys.map((k) => (
              <MagicCard
                key={k.id}
                gradientColor="var(--gold)"
                gradientFrom="var(--gold)"
                gradientTo="var(--gold-bright)"
                gradientOpacity={0.12}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl p-3.5"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <p className="font-mono-tech truncate text-xs font-bold text-foreground sm:text-sm">
                    {k.masked}
                  </p>
                  <Badge variant={k.status === "active" ? "default" : "secondary"}>
                    {k.status === "cooldown"
                      ? `Cooldown (${k.cooldown_remaining}s)`
                      : "Active"}
                  </Badge>
                </div>

                {/* KokonutUI HoldButton for safe destructive revocation */}
                <HoldButton
                  variant="orange"
                  icon="trash"
                  holdDuration={800}
                  disabled={keys.length <= 1}
                  holdingLabel="Keep holding..."
                  completeLabel="Removed"
                  onComplete={() => {
                    handleRemoveKey(k.masked).catch(() => {});
                  }}
                  className="h-9 min-w-[144px] shrink-0 text-xs"
                >
                  Hold to Remove
                </HoldButton>
              </MagicCard>
            ))}
          </div>
        )}
      </div>

      {/* Typography controls using Uiverse 3bdel3ziz-T radio dropdown pattern */}
      <div className="rounded-2xl border border-border bg-card/85 p-5">
        <h2 className="font-display mb-4 text-lg font-bold text-foreground">
          Reader Typography
        </h2>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <span className="mb-1.5 block text-xs font-semibold text-muted-foreground">
              Typeface
            </span>
            <div className="uv-radio-select">
              <button
                type="button"
                aria-expanded={fontMenuOpen}
                onClick={() => setFontMenuOpen((v) => !v)}
                className="uv-radio-selected w-full"
              >
                <span>{fontFamily}</span>
                <ChevronDown
                  className={`size-4 transition-transform ${fontMenuOpen ? "rotate-180" : ""}`}
                />
              </button>
              {fontMenuOpen && (
                <div className="uv-radio-options">
                  {FONT_OPTIONS.map((opt) => (
                    <button
                      type="button"
                      key={opt}
                      data-checked={fontFamily === opt}
                      onClick={() => {
                        onFontFamilyChange(opt);
                        setFontMenuOpen(false);
                      }}
                      className="uv-radio-option"
                    >
                      <span>{opt}</span>
                      {fontFamily === opt && <Badge variant="secondary">Active</Badge>}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-semibold text-muted-foreground">
              Body Scale
            </span>
            <div className="uv-radio-select">
              <button
                type="button"
                aria-expanded={sizeMenuOpen}
                onClick={() => setSizeMenuOpen((v) => !v)}
                className="uv-radio-selected w-full"
              >
                <span>{fontSize}</span>
                <ChevronDown
                  className={`size-4 transition-transform ${sizeMenuOpen ? "rotate-180" : ""}`}
                />
              </button>
              {sizeMenuOpen && (
                <div className="uv-radio-options">
                  {SIZE_OPTIONS.map((opt) => (
                    <button
                      type="button"
                      key={opt}
                      data-checked={fontSize === opt}
                      onClick={() => {
                        onFontSizeChange(opt);
                        setSizeMenuOpen(false);
                      }}
                      className="uv-radio-option"
                    >
                      <span>{opt}</span>
                      {fontSize === opt && <Badge variant="secondary">Active</Badge>}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
