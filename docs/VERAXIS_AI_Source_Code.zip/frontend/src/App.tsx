import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import WorkspaceTopBar from "@/components/workbench/WorkspaceTopBar";
import SessionRail from "@/components/workbench/SessionRail";
import ChatWorkspace, {
  type AttachedDoc,
  type ChatMessageRecord,
} from "@/components/workbench/ChatWorkspace";
import DossiersArchive, {
  type ArchivedSession,
} from "@/components/workbench/DossiersArchive";
import VaultSettings from "@/components/workbench/VaultSettings";
import type { IslandTask } from "@/components/registry/status-island";
import type { ContextSegment } from "@/components/registry/ai-context-meter";

const SESSIONS_KEY = "veraxis_sessions";

const FONT_MAP: Record<string, string> = {
  Manrope: "'Manrope', -apple-system, sans-serif",
  "Bricolage Grotesque": "'Bricolage Grotesque', sans-serif",
  Inter: "system-ui, -apple-system, 'Segoe UI', sans-serif",
};

interface SessionState extends ArchivedSession {
  messages: ChatMessageRecord[];
}

export default function App() {
  const pathname = usePathname();
  const [theme, setTheme] = useState<"light" | "dark">(() =>
    localStorage.getItem("veraxis-theme") === "light" ? "light" : "dark"
  );
  const [fontFamily, setFontFamily] = useState(
    () => localStorage.getItem("veraxis-font-family") || "Manrope"
  );
  const [fontSize, setFontSize] = useState(
    () => localStorage.getItem("veraxis-font-size") || "16px"
  );

  const [railOpen, setRailOpen] = useState(
    () => typeof window !== "undefined" && window.innerWidth >= 1024
  );

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(min-width: 1024px)");
    const onMediaChange = (e: MediaQueryListEvent) => {
      setRailOpen(e.matches);
    };
    mq.addEventListener("change", onMediaChange);
    return () => mq.removeEventListener("change", onMediaChange);
  }, []);

  const [sessions, setSessions] = useState<SessionState[]>(() => {
    try {
      const raw = localStorage.getItem(SESSIONS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(() => {
    try {
      return localStorage.getItem("veraxis-active-session") || null;
    } catch {
      return null;
    }
  });
  const [messages, setMessages] = useState<ChatMessageRecord[]>(() => {
    try {
      const activeId = localStorage.getItem("veraxis-active-session");
      if (!activeId) return [];
      const raw = localStorage.getItem(SESSIONS_KEY);
      if (!raw) return [];
      const parsed: SessionState[] = JSON.parse(raw);
      const hit = parsed.find((s) => s.id === activeId);
      return (hit?.messages || []).map((m) => ({ ...m, isStreaming: false }));
    } catch {
      return [];
    }
  });
  const [chatTitle, setChatTitle] = useState("New Inquiry");
  const [researchPriority, setResearchPriority] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [livePhase, setLivePhase] = useState("");
  const [livePhaseLabel, setLivePhaseLabel] = useState("");
  const [activeThinkingSteps, setActiveThinkingSteps] = useState<
    Array<{ agent?: string; step?: string }> | null
  >(null);
  const [telemetry, setTelemetry] = useState({ activeKeys: 0, totalKeys: 0 });
  const [islandTasks, setIslandTasks] = useState<IslandTask[]>([]);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("veraxis-theme", theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.style.setProperty(
      "--font-family",
      FONT_MAP[fontFamily] || FONT_MAP.Manrope
    );
    document.documentElement.style.setProperty("--base-font-size", fontSize);
    localStorage.setItem("veraxis-font-family", fontFamily);
    localStorage.setItem("veraxis-font-size", fontSize);
  }, [fontFamily, fontSize]);

  useEffect(() => {
    try {
      if (currentSessionId) {
        localStorage.setItem("veraxis-active-session", currentSessionId);
      } else {
        localStorage.removeItem("veraxis-active-session");
      }
    } catch {
      // Ignore restricted storage mode
    }
  }, [currentSessionId]);

  const navigate = useCallback((route: string) => {
    const normalized = `#${route}`;
    if (window.location.hash !== normalized) {
      window.history.replaceState(null, "", normalized);
    }
    window.dispatchEvent(new CustomEvent("veraxis:nav", { detail: route }));
  }, []);

  const pushIslandTask = useCallback((task: IslandTask) => {
    setIslandTasks((prev) => [...prev.filter((t) => t.id !== task.id), task]);
  }, []);

  const dismissIslandTask = useCallback((id: string) => {
    setIslandTasks((prev) => prev.filter((t) => t.id !== id));
  }, []);

  useEffect(() => {
    let active = true;
    const ctrl = new AbortController();

    fetch("/api/status", { signal: ctrl.signal })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (!active || !d?.telemetry) return;
        const activeKeys = d.telemetry.active_keys ?? 0;
        const totalKeys = d.telemetry.total_keys ?? 0;
        setTelemetry({ activeKeys, totalKeys });
        pushIslandTask({
          id: "system-online",
          label: "VERAXIS Ready",
          detail: `${activeKeys}/${totalKeys} keys`,
          status: "done",
        });
      })
      .catch(() => {
        if (active) {
          pushIslandTask({
            id: "system-offline",
            label: "Telemetry offline",
            status: "error",
          });
        }
      });

    fetch("/sessions", { signal: ctrl.signal })
      .then((r) => (r.ok ? r.json() : null))
      .then((serverSessions) => {
        if (!active || !Array.isArray(serverSessions) || serverSessions.length === 0) {
          return;
        }
        setSessions((prev) => {
          if (prev.length > 0) return prev;
          return serverSessions;
        });
      })
      .catch(() => {});

    return () => {
      active = false;
      ctrl.abort();
    };
  }, [pushIslandTask]);

  const persistSessions = useCallback((next: SessionState[]) => {
    setSessions(next);
    try {
      const cleaned = next.map((s) => ({
        ...s,
        messages: (s.messages || []).map((m) => ({ ...m, isStreaming: false })),
      }));
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(cleaned));
      fetch("/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cleaned),
      }).catch(() => {});
    } catch {
      // Ignore storage quota warning
    }
  }, []);

  const handleNewInquiry = useCallback(() => {
    abortControllerRef.current?.abort();
    setIsLoading(false);
    setLivePhase("");
    setLivePhaseLabel("");
    setCurrentSessionId(null);
    setMessages([]);
    setChatTitle("New Inquiry");
    setActiveThinkingSteps(null);
    navigate("/");
    if (window.innerWidth < 1024) setRailOpen(false);
  }, [navigate]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "b") {
        e.preventDefault();
        setRailOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const handleSelectSession = useCallback(
    (id: string) => {
      const found = sessions.find((s) => s.id === id);
      if (!found) return;
      setCurrentSessionId(id);
      setChatTitle(found.title || "Research Dossier");
      setMessages((found.messages || []).map((m) => ({ ...m, isStreaming: false })));
      navigate("/");
      if (window.innerWidth < 1024) setRailOpen(false);
    },
    [sessions, navigate]
  );

  const handleDeleteSession = useCallback(
    (id: string) => {
      const next = sessions.filter((s) => s.id !== id);
      persistSessions(next);
      if (currentSessionId === id) {
        setCurrentSessionId(null);
        setMessages([]);
        setChatTitle("New Inquiry");
      }
    },
    [sessions, persistSessions, currentSessionId]
  );

  const handleStopQuery = useCallback(() => {
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setIsLoading(false);
    setLivePhase("");
    setLivePhaseLabel("");
    setMessages((prev) => prev.map((m) => ({ ...m, isStreaming: false })));
  }, []);

  const contextSegments: ContextSegment[] = useMemo(() => {
    let dialogueChars = 0;
    let sourcesChars = 0;
    for (const m of messages) {
      dialogueChars += (m.content || "").length;
      for (const s of m.sources || []) {
        sourcesChars += (s.title || "").length + (s.url || "").length;
      }
    }
    const baseTokens = 650;
    const msgTokens = Math.ceil(dialogueChars / 4);
    const srcTokens = Math.ceil(sourcesChars / 4);
    return [
      { id: "sys", label: "System Prompts", tokens: baseTokens, color: "bg-zinc-500" },
      { id: "src", label: "Retrieved Citations", tokens: srcTokens, color: "bg-primary/70" },
      { id: "msg", label: "Active Dialogue", tokens: msgTokens, color: "bg-primary" },
    ];
  }, [messages]);

  const handleSendQuery = async (
    rawText: string,
    options?: {
      forceResearch?: boolean;
      modeOverride?: "auto" | "fast" | "deep";
      attachments?: AttachedDoc[];
    }
  ) => {
    const text = rawText.trim();
    if (!text || isLoading) return;

    const controller = new AbortController();
    abortControllerRef.current = controller;

    setIsLoading(true);
    setActiveThinkingSteps(null);
    setLivePhase("classify");
    setLivePhaseLabel("Classifying inquiry intent...");
    const startMs = Date.now();
    const taskId = `run-${startMs}`;

    pushIslandTask({
      id: taskId,
      label: "Analyzing inquiry",
      detail: text.slice(0, 28),
      status: "running",
      progress: 0.1,
    });

    const userMsg: ChatMessageRecord = {
      id: `u-${startMs}`,
      role: "user",
      content: text,
      type: "chat",
    };

    const priorHistory = messages.slice(-8).map((m) => ({
      role: m.role === "user" ? "user" : "assistant",
      content: m.content.slice(0, 1800),
    }));

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);

    const words = text.split(/\s+/).filter(Boolean);
    let sessionTitle = chatTitle;
    if (messages.length === 0) {
      sessionTitle =
        words.length >= 3
          ? words
              .slice(0, 4)
              .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
              .join(" ")
          : text;
      setChatTitle(sessionTitle);
    }

    let activeId = currentSessionId;
    let workingSessions = [...sessions];
    if (!activeId) {
      activeId = `sess-${startMs}`;
      setCurrentSessionId(activeId);
      workingSessions.unshift({
        id: activeId,
        title: sessionTitle,
        createdAt: new Date().toISOString(),
        messages: nextMessages,
      });
    } else {
      workingSessions = workingSessions.map((s) =>
        s.id === activeId
          ? { ...s, title: sessionTitle, messages: nextMessages }
          : s
      );
    }
    persistSessions(workingSessions);

    try {
      const priority = options?.forceResearch ?? researchPriority;
      const isAcademic =
        options?.modeOverride === "deep" ||
        Boolean(priority && words.length > 2) ||
        /^\/(research|paper)\b/i.test(text.trim());
      const resolvedMode =
        options?.modeOverride === "deep"
          ? "deep"
          : options?.modeOverride === "fast"
          ? "fast"
          : priority
          ? "auto"
          : "auto";

      // Fetch dynamic tailored thinking steps in parallel so Inspector renders real steps early
      let capturedSteps: Array<{ agent?: string; step?: string }> | null = null;
      if (resolvedMode === "deep" || (priority && words.length > 2) || isAcademic) {
        fetch("/api/thinking-steps", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({ query: text }),
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (Array.isArray(d?.steps)) {
              capturedSteps = d.steps;
              setActiveThinkingSteps(d.steps);
            }
          })
          .catch(() => {});
      }

      const streamRes = await fetch("/api/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          query: text,
          mode: resolvedMode,
          force_research:
            options?.modeOverride === "fast"
              ? false
              : options?.modeOverride === "deep"
              ? true
              : priority && words.length > 2,
          research_mode: isAcademic,
          history: priorHistory,
          attachments: options?.attachments || [],
        }),
      });

      if (!streamRes.ok || !streamRes.body) {
        const errPayload = await streamRes.json().catch(() => ({}));
        throw new Error(errPayload.detail || `Server responded ${streamRes.status}`);
      }

      const reader = streamRes.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      const liveBotId = `b-${Date.now()}`;
      let liveCreated = false;
      let streamRoleType: "chat" | "research" = "research";
      let streamTopic = text;
      let streamSources: Array<{ title: string; url: string; badge?: string }> = [];
      let streamContent = "";
      let finalResult: ChatMessageRecord | null = null;

      const upsertStreamingBot = (patch: Partial<ChatMessageRecord>) => {
        setMessages((prev) => {
          const exists = prev.some((m) => m.id === liveBotId);
          if (!exists) {
            liveCreated = true;
            return [
              ...prev,
              {
                id: liveBotId,
                role: "bot",
                type: streamRoleType,
                topic: streamTopic,
                sources: streamSources,
                content: streamContent,
                thinkingSteps: capturedSteps,
                isStreaming: true,
                ...patch,
              },
            ];
          }
          return prev.map((m) => (m.id === liveBotId ? { ...m, ...patch } : m));
        });
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n");
        buffer = events.pop() || "";

        for (const rawEvent of events) {
          const dataLine = rawEvent
            .split("\n")
            .find((l) => l.startsWith("data: "));
          if (!dataLine) continue;

          let parsed: Record<string, unknown>;
          try {
            parsed = JSON.parse(dataLine.slice(6));
          } catch {
            continue;
          }

          if (parsed.event === "status") {
            const ph = String(parsed.phase || "");
            const lbl = String(parsed.label || "");
            const prog = typeof parsed.progress === "number" ? parsed.progress : 0.4;
            setLivePhase(ph);
            setLivePhaseLabel(lbl);
            pushIslandTask({
              id: taskId,
              label: lbl.slice(0, 34),
              status: "running",
              progress: prog,
            });
          } else if (parsed.event === "sources") {
            streamRoleType = "research";
            streamTopic = String(parsed.topic || text);
            streamSources = Array.isArray(parsed.sources) ? parsed.sources : [];
            upsertStreamingBot({
              type: "research",
              topic: streamTopic,
              sources: streamSources,
              content: streamContent,
            });
          } else if (parsed.event === "delta") {
            streamRoleType = parsed.role === "research" ? "research" : "chat";
            streamContent += String(parsed.delta || "");
            upsertStreamingBot({
              type: streamRoleType,
              topic: streamRoleType === "research" ? streamTopic : undefined,
              sources: streamRoleType === "research" ? streamSources : [],
              content: streamContent,
            });
          } else if (parsed.event === "chunk") {
            streamContent = String(parsed.content || "");
            upsertStreamingBot({
              type: streamRoleType,
              topic: streamTopic,
              sources: streamSources,
              content: streamContent,
            });
          } else if (parsed.event === "error") {
            throw new Error(String(parsed.message || "Streaming error"));
          } else if (parsed.event === "done" && parsed.result) {
            const resObj = parsed.result as Record<string, unknown>;
            const elapsedSec = `${((Date.now() - startMs) / 1000).toFixed(1)}s`;
            finalResult = {
              id: liveBotId,
              role: "bot",
              content: String(resObj.content || streamContent || ""),
              type: (resObj.type as "chat" | "research" | "error") || streamRoleType,
              sources: (resObj.sources as ChatMessageRecord["sources"]) || [],
              pdf_filename: (resObj.pdf_filename as string) || null,
              topic: (resObj.topic as string) || null,
              thinkingSteps: capturedSteps,
              duration: elapsedSec,
              isStreaming: false,
            };
          }
        }
      }

      if (!finalResult) {
        if (liveCreated && streamContent) {
          const elapsedSec = `${((Date.now() - startMs) / 1000).toFixed(1)}s`;
          finalResult = {
            id: liveBotId,
            role: "bot",
            content: streamContent,
            type: streamRoleType,
            sources: streamSources,
            topic: streamRoleType === "research" ? streamTopic : null,
            thinkingSteps: capturedSteps,
            duration: elapsedSec,
            isStreaming: false,
          };
        } else {
          throw new Error("Stream ended before response completed.");
        }
      }

      const completedMessages = [...nextMessages, finalResult];
      setMessages(completedMessages);
      setIsLoading(false);
      setLivePhase("");
      setLivePhaseLabel("");

      workingSessions = workingSessions.map((s) =>
        s.id === activeId
          ? { ...s, title: sessionTitle, messages: completedMessages }
          : s
      );
      persistSessions(workingSessions);

      pushIslandTask({
        id: taskId,
        label: finalResult.type === "research" ? "Report ready" : "Reply ready",
        detail: finalResult.duration,
        status: "done",
      });

      if (completedMessages.length >= 2 && completedMessages.length <= 4) {
        fetch("/api/title", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({ messages: completedMessages }),
        })
          .then((r) => (r.ok ? r.json() : null))
          .then((titleData) => {
            if (titleData?.title && titleData.title !== "Research Inquiry") {
              setChatTitle(titleData.title);
              const renamed = workingSessions.map((s) =>
                s.id === activeId
                  ? { ...s, title: titleData.title, messages: completedMessages }
                  : s
              );
              persistSessions(renamed);
            }
          })
          .catch(() => {});
      }
    } catch (err) {
      if (controller.signal.aborted) {
        pushIslandTask({
          id: taskId,
          label: "Inquiry cancelled",
          status: "error",
        });
        return;
      }

      const msg = err instanceof Error ? err.message : "Request failed";
      const errBotMsg: ChatMessageRecord = {
        id: `e-${Date.now()}`,
        role: "bot",
        content: `Execution error: ${msg}`,
        type: "error",
      };
      const withErr = [...nextMessages, errBotMsg];
      setMessages(withErr);
      workingSessions = workingSessions.map((s) =>
        s.id === activeId ? { ...s, messages: withErr } : s
      );
      persistSessions(workingSessions);

      pushIslandTask({
        id: taskId,
        label: "Request failed",
        detail: msg.slice(0, 28),
        status: "error",
      });
    } finally {
      if (abortControllerRef.current === controller) {
        abortControllerRef.current = null;
        setIsLoading(false);
        setLivePhase("");
        setLivePhaseLabel("");
      }
    }
  };

  const handleDownloadPdf = useCallback(
    async (filename: string) => {
      const taskId = `pdf-${Date.now()}`;
      pushIslandTask({
        id: taskId,
        label: "Creating PDF report",
        status: "running",
        progress: 0.5,
      });

      const res = await fetch(`/api/download-pdf/${encodeURIComponent(filename)}`);
      if (!res.ok) {
        pushIslandTask({
          id: taskId,
          label: "PDF download failed",
          detail: `HTTP ${res.status}`,
          status: "error",
        });
        throw new Error(`PDF download failed (${res.status})`);
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);

      pushIslandTask({
        id: taskId,
        label: "PDF exported",
        detail: "Ready",
        status: "done",
      });
    },
    [pushIslandTask]
  );

  const recentSession = useMemo(() => {
    const first = sessions[0];
    if (!first) return null;
    return { id: first.id, title: first.title || "Untitled inquiry" };
  }, [sessions]);

  return (
    <div className="flex h-dvh w-full flex-col overflow-hidden bg-background text-foreground">
      <WorkspaceTopBar
        theme={theme}
        onThemeChange={setTheme}
        onNewInquiry={handleNewInquiry}
        onToggleRail={() => setRailOpen((v) => !v)}
        railOpen={railOpen}
        islandTasks={islandTasks}
        onDismissTask={dismissIslandTask}
      />

      <div className="flex min-h-0 flex-1 overflow-hidden">
        <SessionRail
          open={railOpen}
          onCloseMobile={() => setRailOpen(false)}
          sessions={sessions}
          activeSessionId={currentSessionId}
          onSelectSession={handleSelectSession}
          onDeleteSession={handleDeleteSession}
          onNewInquiry={handleNewInquiry}
          onOpenVault={() => {
            navigate("/vault");
            if (window.innerWidth < 1024) setRailOpen(false);
          }}
          telemetry={telemetry}
        />

        <main className="flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto">
          {pathname === "/dossiers" ? (
            <DossiersArchive
              sessions={sessions}
              onOpenSession={handleSelectSession}
              onDeleteSession={handleDeleteSession}
              onDownloadPdf={handleDownloadPdf}
            />
          ) : pathname === "/vault" ? (
            <VaultSettings
              fontFamily={fontFamily}
              onFontFamilyChange={setFontFamily}
              fontSize={fontSize}
              onFontSizeChange={setFontSize}
              onTelemetrySync={setTelemetry}
            />
          ) : (
            <ChatWorkspace
              messages={messages}
              recentSession={recentSession}
              onOpenRecentSession={handleSelectSession}
              isLoading={isLoading}
              researchPriority={researchPriority}
              onToggleResearchPriority={setResearchPriority}
              activeThinkingSteps={activeThinkingSteps}
              livePhase={livePhase}
              livePhaseLabel={livePhaseLabel}
              contextSegments={contextSegments}
              onSendQuery={handleSendQuery}
              onStopQuery={handleStopQuery}
              onDownloadPdf={handleDownloadPdf}
            />
          )}
        </main>
      </div>
    </div>
  );
}
