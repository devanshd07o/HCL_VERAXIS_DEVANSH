import os
import json
import time
from playwright.sync_api import sync_playwright

BASE_URL = "http://localhost:5173/"
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

LONG_ANSWER_CONTENT = """# Empirical Audit: Solid-State Battery Commercial Viability by 2028

## Executive Summary & Mechanistic Synthesis
Commercial deployment of solid-state lithium-metal batteries (SSB) by 2028 is gated by three coupled degradation vectors: critical current density ($J_{CCD}$) limits, mechanical stress during strip-plating cycles, and chemical cross-decomposition at the garnet-sulfide interfaces.

### 1. Ceramic Electrolyte Ionic Transport Benchmarks
The primary benchmark for room-temperature operational viability is ionic conductivity $\\sigma_{ion} \\ge 1.0 \\times 10^{-2} \\text{ S cm}^{-1}$. Current generation LLZO ($Li_7La_3Zr_2O_{12}$) exhibits:

$$\\sigma_{ion} = \\frac{\\sigma_0}{T} \\exp\\left(-\\frac{E_a}{k_B T}\\right)$$

Where measured activation energy $E_a \\approx 0.32 \\text{ eV}$.

| Electrolyte Class | Phase Morphology | $\\sigma_{ion}$ at 298K (mS/cm) | $J_{CCD}$ at 60°C (mA/cm²) | Failure Mechanism |
| :--- | :--- | :--- | :--- | :--- |
| **LLZO (Garnet)** | Cubic Poly-crystalline | 1.4 - 2.1 | 4.8 | Intergranular Dendrite Infiltration |
| **$Li_{10}GeP_2S_{12}$ (LGPS)** | Tetragonal Thio-LISICON | 12.0 | 2.2 | High Reduction Potential (< 1.7V) |
| **$Li_3InCl_6$ (Halide)** | Monoclinic Layered | 1.8 - 3.2 | 8.5 | High Moisture Sensitivity |
| **Composite Polymer** | PEO / Nanoparticle slurry | 0.25 | 1.1 | Thermal Runaway under Puncture |

### 2. High-Pressure Compressive Containment
Unlike liquid electrolytes that accommodate electrode expansion via pore diffusion, solid electrolyte interfaces require an active external pressure stack of $5 \\text{ to } 8 \\text{ MPa}$ to suppress void nucleation during lithium stripping at rates exceeding $3 \\text{ mA cm}^{-2}$.

$$P_{stack} \\ge \\frac{2 \\gamma_{eff}}{r_{void}} \\cdot \\left(1 - \\nu^2\\right)$$

### 3. Forensic Conclusion & 2028 Commercial Assessment
Automotive packs utilizing garnet-composite hybrid separators will reach pilot volumes ($< 50 \\text{ GWh}$ globally) by Q3 2028. Total pack energy density will plateau at $420 \\text{ Wh/kg}$ at cell level, while volumetric density will achieve $1020 \\text{ Wh/L}$. Active thermal regulation stacks will be required to maintain $45^\\circ\\text{C}$ operating temperature to ensure cycle life exceeding 1,200 cycles before 80% capacity retention and to guarantee long-term device longevity.
"""

MOCK_CHAT_SESSION = [
  {
    "id": "sess-ssb-long",
    "title": "Solid-State Battery Benchmarks 2028",
    "createdAt": "2026-10-01T09:00:00.000Z",
    "messages": [
      {
        "role": "user",
        "content": "Provide a comprehensive empirical audit of solid-state EV batteries with ceramic electrolyte benchmarks for commercial viability by 2028."
      },
      {
        "role": "bot",
        "content": LONG_ANSWER_CONTENT,
        "type": "research",
        "topic": "MATERIALS SCIENCE // ENERGY",
        "pdf_filename": "VERAXIS_DOSSIER_SSB_2028.pdf",
        "sources": [
          { "title": "Critical current density limitations in cubic LLZO garnets", "url": "https://arxiv.org/abs/2401.00001" },
          { "title": "Interface chemo-mechanics in all-solid-state lithium batteries", "url": "https://arxiv.org/abs/2401.00002" },
          { "title": "Halide vs sulfide solid electrolytes: A 2028 scale-up review", "url": "https://arxiv.org/abs/2401.00003" }
        ]
      }
    ]
  }
]

def run_tests():
    with sync_playwright() as p:
        browser = p.chromium.launch(channel="chrome", headless=True)

        # -------------------------------------------------------------
        # 1. Home 1366x768 100% Zoom
        # -------------------------------------------------------------
        ctx_1366 = browser.new_context(
            viewport={"width": 1366, "height": 768},
            device_scale_factor=1.0
        )
        page = ctx_1366.new_page()
        page.goto(BASE_URL)
        page.wait_for_timeout(800)

        ask_btn = page.locator("button[aria-label='Ask']").first
        ask_box = ask_btn.bounding_box()
        print(f"[TEST 1366x768 Home] ASK Button bounding box: {ask_box}")
        assert ask_box is not None, "ASK button not found!"
        assert ask_box["y"] + ask_box["height"] <= 768, f"ASK button out of viewport! bottom={ask_box['y'] + ask_box['height']}"
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1366_home_100zoom.png"))
        print("Captured: screenshot_1366_home_100zoom.png")
        ctx_1366.close()

        # -------------------------------------------------------------
        # 2. Home 1440x900 Dark
        # -------------------------------------------------------------
        ctx_1440_dark = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1.0
        )
        page = ctx_1440_dark.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'dark'); localStorage.setItem('veraxis-theme', 'dark');")
        page.wait_for_timeout(800)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_home_dark.png"))
        print("Captured: screenshot_1440_home_dark.png")
        ctx_1440_dark.close()

        # -------------------------------------------------------------
        # 3. Home 1440x900 Light (Acid)
        # -------------------------------------------------------------
        ctx_1440_light = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1.0
        )
        page = ctx_1440_light.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        page.wait_for_timeout(800)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_home_light.png"))
        print("Captured: screenshot_1440_home_light.png")
        ctx_1440_light.close()

        # -------------------------------------------------------------
        # 4. Mobile 390x844 Light (Acid)
        # -------------------------------------------------------------
        ctx_390_light = browser.new_context(
            viewport={"width": 390, "height": 844},
            device_scale_factor=2.0
        )
        page = ctx_390_light.new_page()
        page.goto(BASE_URL)
        page.evaluate("document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        page.wait_for_timeout(800)
        ask_box_390 = page.locator("button[aria-label='Ask']").first.bounding_box()
        print(f"[TEST 390x844 Mobile Home] ASK Button bounding box: {ask_box_390}")
        assert ask_box_390["y"] + ask_box_390["height"] <= 844, "ASK button out of mobile viewport!"
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_390_home_light.png"))
        print("Captured: screenshot_390_home_light.png")
        ctx_390_light.close()

        # -------------------------------------------------------------
        # 5. Agent Strip Wire Hover Interaction (1440x900)
        # -------------------------------------------------------------
        ctx_wire = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1.0
        )
        page = ctx_wire.new_page()
        page.goto(BASE_URL)
        page.wait_for_timeout(600)
        strip = page.locator("[aria-label='3-Agent Verification Pipeline']")
        strip_box = strip.bounding_box()
        wire_hover_x = strip_box["x"] + strip_box["width"] * 0.32
        wire_hover_y = strip_box["y"] + strip_box["height"] * 0.45
        page.mouse.move(wire_hover_x, wire_hover_y)
        page.wait_for_timeout(600)
        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_agent_strip_wire_hover.png"))
        print(f"Captured: screenshot_agent_strip_wire_hover.png (hovered at {wire_hover_x:.1f}, {wire_hover_y:.1f})")
        ctx_wire.close()

        # -------------------------------------------------------------
        # 6. Chat 1366x768 Long AI Answer (Last line clear of dock)
        # -------------------------------------------------------------
        ctx_chat_1366 = browser.new_context(
            viewport={"width": 1366, "height": 768},
            device_scale_factor=1.0
        )
        page = ctx_chat_1366.new_page()
        page.goto(BASE_URL)
        page.evaluate(
            """(s) => {
                localStorage.setItem('veraxis_sessions', JSON.stringify(s));
                document.documentElement.setAttribute('data-theme', 'light');
                localStorage.setItem('veraxis-theme', 'light');
            }""",
            MOCK_CHAT_SESSION
        )
        page.reload()
        page.wait_for_timeout(400)
        
        # Open sidebar and click session row
        page.locator("button[aria-label='Toggle Archive Sidebar']").click()
        page.wait_for_timeout(400)
        page.locator("aside div.cursor-pointer").first.click()
        page.wait_for_timeout(400)
        # Close sidebar to show full chat layout
        page.locator("button[aria-label='Toggle Archive Sidebar']").click()
        page.wait_for_timeout(400)

        # Skip typewriter reveal if present
        skip_btn = page.locator("text=SKIP REVEAL")
        if skip_btn.is_visible():
            skip_btn.click()
            page.wait_for_timeout(400)

        # Scroll to bottom of message list
        stage = page.locator(".chat-scroll-container").first
        stage.evaluate("el => el.scrollTop = el.scrollHeight")
        page.wait_for_timeout(400)

        # Check dock position vs last text
        dock = page.locator("div.border-t-\\[3px\\]:has(button[aria-label='Ask'])").first
        dock_box = dock.bounding_box()
        print(f"[TEST Chat 1366x768] Dock box: {dock_box}")

        # Check last paragraph containing "...device longevity."
        last_p = page.locator("text=long-term device longevity.")
        last_p_box = last_p.bounding_box()
        print(f"[TEST Chat 1366x768] Last line bounding box: {last_p_box}")

        assert dock_box is not None and last_p_box is not None
        assert last_p_box["y"] + last_p_box["height"] < dock_box["y"], "Last line is occluded by dock!"
        clearance = dock_box["y"] - (last_p_box["y"] + last_p_box["height"])
        print(f"[TEST Chat 1366x768] Clearance above dock: {clearance:.1f}px (target >= 24px)")
        assert clearance >= 24, f"Clearance is {clearance}px, expected >= 24px!"

        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1366_chat_long_answer.png"))
        print("Captured: screenshot_1366_chat_long_answer.png")
        ctx_chat_1366.close()

        # -------------------------------------------------------------
        # 7. Chat 1920x940 Long AI Answer (Dock alignment & clearance)
        # -------------------------------------------------------------
        ctx_chat_1920 = browser.new_context(
            viewport={"width": 1920, "height": 940},
            device_scale_factor=1.0
        )
        page = ctx_chat_1920.new_page()
        page.goto(BASE_URL)
        page.evaluate(
            """(s) => {
                localStorage.setItem('veraxis_sessions', JSON.stringify(s));
                document.documentElement.setAttribute('data-theme', 'light');
                localStorage.setItem('veraxis-theme', 'light');
            }""",
            MOCK_CHAT_SESSION
        )
        page.reload()
        page.wait_for_timeout(400)
        page.locator("button[aria-label='Toggle Archive Sidebar']").click()
        page.wait_for_timeout(400)
        page.locator("aside div.cursor-pointer").first.click()
        page.wait_for_timeout(400)
        page.locator("button[aria-label='Toggle Archive Sidebar']").click()
        page.wait_for_timeout(400)

        skip_btn = page.locator("text=SKIP REVEAL")
        if skip_btn.is_visible():
            skip_btn.click()
            page.wait_for_timeout(400)

        stage = page.locator(".chat-scroll-container").first
        stage.evaluate("el => el.scrollTop = el.scrollHeight")
        page.wait_for_timeout(400)

        # Check alignment between answer sheet and dock inner box
        answer_sheet = page.locator("div.w-full.bg-\\[var\\(--panel\\)\\]:has(a[download])").first
        answer_box = answer_sheet.bounding_box()

        dock_inner = page.locator("div.command-box-shadow-compact:has(button[aria-label='Ask'])").first
        dock_inner_box = dock_inner.bounding_box()

        print(f"[TEST Chat 1920x940] Answer sheet box: {answer_box}")
        print(f"[TEST Chat 1920x940] Dock inner box: {dock_inner_box}")
        left_diff = abs(answer_box['x'] - dock_inner_box['x'])
        width_diff = abs(answer_box['width'] - dock_inner_box['width'])
        print(f"[TEST Chat 1920x940] Left diff: {left_diff:.1f}px, Width diff: {width_diff:.1f}px")
        print(f"[TEST Chat 1920x940] Dock height: {dock_inner_box['height']:.1f}px (target <= 140px)")
        assert dock_inner_box["height"] <= 140, f"Dock too tall: {dock_inner_box['height']}px"
        assert left_diff <= 2, f"Left edges not aligned! Diff: {left_diff}px"
        assert width_diff <= 2, f"Widths not aligned! Diff: {width_diff}px"

        page.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1920_chat_long_answer.png"))
        print("Captured: screenshot_1920_chat_long_answer.png")
        ctx_chat_1920.close()

        browser.close()
        print("\nAll verification checks and screenshot captures PASSED flawlessly!")

if __name__ == "__main__":
    run_tests()
