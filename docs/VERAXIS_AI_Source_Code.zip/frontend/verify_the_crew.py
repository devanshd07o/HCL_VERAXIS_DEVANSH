import os
import sys
import json
import time
from playwright.sync_api import sync_playwright

BASE_URL = "http://localhost:5173/"
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.stdout.reconfigure(line_buffering=True)

def run_verification_round(round_number=1):
    print(f"\n==========================================")
    print(f"   STARTING VERIFICATION ROUND {round_number}")
    print(f"==========================================\n")

    results = {}
    console_logs = []
    page_errors = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)

        # ----------------------------------------------------
        # TEST 1 & 2: Responsive Matrix (Widths & Heights & Zooms)
        # Check: Ask visible without scrolling at 1366x768, and No Horizontal Scroll
        # ----------------------------------------------------
        matrix_configs = [
            (360, 640, 1.0, "360x640"),
            (390, 844, 1.0, "390x844"),
            (768, 1024, 1.0, "768x1024"),
            (1024, 768, 1.0, "1024x768"),
            (1366, 768, 1.0, "1366x768_100zoom"),
            (1440, 900, 1.0, "1440x900_100zoom"),
            (1920, 940, 1.0, "1920x940_100zoom"),
            (1366, 568, 1.0, "1366x568_short"),
            (1366, 667, 1.0, "1366x667_short"),
            (1366, 768, 1.25, "1366x768_125zoom"),
            (1366, 768, 1.50, "1366x768_150zoom"),
        ]

        h_scroll_failures = []
        for w, h, zoom, label in matrix_configs:
            ctx = browser.new_context(
                viewport={"width": int(w / zoom), "height": int(h / zoom)},
                device_scale_factor=zoom
            )
            pg = ctx.new_page()
            pg.goto(BASE_URL)
            pg.wait_for_timeout(300)

            has_h = pg.evaluate("() => document.documentElement.scrollWidth > document.documentElement.clientWidth || document.body.scrollWidth > document.body.clientWidth")
            if has_h:
                h_scroll_failures.append(label)
            ctx.close()

        results["no_horizontal_scroll"] = (len(h_scroll_failures) == 0, f"Failures: {h_scroll_failures}" if h_scroll_failures else "Clean on all screen widths")

        # ----------------------------------------------------
        # 1366x768 100% zoom check: Ask visible without scrolling
        # ----------------------------------------------------
        ctx_1366 = browser.new_context(viewport={"width": 1366, "height": 768}, device_scale_factor=1.0)
        pg_1366 = ctx_1366.new_page()
        pg_1366.goto(BASE_URL)
        pg_1366.wait_for_timeout(500)
        ask_btn = pg_1366.locator("button[aria-label='Ask']").first
        ask_box = ask_btn.bounding_box()
        ask_visible_1366 = ask_box is not None and (ask_box["y"] + ask_box["height"] <= 768)
        results["ask_visible_without_scrolling"] = (
            ask_visible_1366,
            f"Ask button bottom is {ask_box['y'] + ask_box['height']:.1f}px (viewport height 768px)" if ask_box else "Ask button not found"
        )
        pg_1366.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1366_home_100zoom.png"))
        print("Captured: screenshot_1366_home_100zoom.png")
        ctx_1366.close()

        # ----------------------------------------------------
        # TEST 3: Headline letters not overlapping or clipped
        # ----------------------------------------------------
        ctx_hd = browser.new_context(viewport={"width": 1440, "height": 900})
        pg_hd = ctx_hd.new_page()
        pg_hd.goto(BASE_URL)
        pg_hd.wait_for_timeout(400)
        h1_el = pg_hd.locator("h1").first
        h1_line_height = pg_hd.evaluate("el => window.getComputedStyle(el).lineHeight", h1_el.element_handle())
        h1_letter_spacing = pg_hd.evaluate("el => window.getComputedStyle(el).letterSpacing", h1_el.element_handle())
        h1_font = pg_hd.evaluate("el => window.getComputedStyle(el).fontFamily", h1_el.element_handle())
        results["headline_not_overlapping"] = (
            "Bricolage" in h1_font,
            f"Font: {h1_font}, line-height: {h1_line_height}, letter-spacing: {h1_letter_spacing}"
        )

        # ----------------------------------------------------
        # TEST 4: No stray lines across the page
        # ----------------------------------------------------
        stray_lines = pg_hd.evaluate("""() => {
            const hrs = document.querySelectorAll('hr');
            return hrs.length;
        }""")
        results["no_stray_lines"] = (stray_lines == 0, f"Found {stray_lines} hr tags on home")

        # ----------------------------------------------------
        # TEST 5: No native scrollbar box inside textarea
        # ----------------------------------------------------
        textarea_el = pg_hd.locator("textarea").first
        ta_scrollbar_width = pg_hd.evaluate("el => window.getComputedStyle(el).scrollbarWidth", textarea_el.element_handle())
        results["no_native_scrollbar_box"] = (
            ta_scrollbar_width == "thin" or ta_scrollbar_width == "none",
            f"Textarea scrollbar-width: {ta_scrollbar_width}"
        )

        # ----------------------------------------------------
        # TEST 6: No truncated text except long directive titles
        # ----------------------------------------------------
        text_truncation_check = pg_hd.evaluate("""() => {
            const elements = Array.from(document.querySelectorAll('span, p, h1, h2, h3, button, div'));
            const ellipsisTexts = [];
            for (const el of elements) {
                // If it's a leaf text element
                if (el.children.length === 0 && el.textContent.includes('...')) {
                    // Check if parent or element is directive title or rotating placeholder
                    const isDirective = el.closest('button[aria-label^="Directive:"]');
                    const isPlaceholder = el.className.includes('line-clamp-2') || el.closest('[class*="line-clamp-2"]');
                    if (!isDirective && !isPlaceholder) {
                        ellipsisTexts.push(el.textContent.trim());
                    }
                }
            }
            return ellipsisTexts;
        }""")
        results["no_unwanted_text_truncation"] = (
            len(text_truncation_check) == 0,
            f"Unwanted truncation: {text_truncation_check}" if text_truncation_check else "Only directives/placeholders have ellipsis"
        )

        # ----------------------------------------------------
        # TEST 7 & 8: Stage cursor tracking & Cable sag & flow dots
        # ----------------------------------------------------
        # Move cursor to top (y=20)
        pg_hd.mouse.move(720, 20)
        pg_hd.wait_for_timeout(300)
        py_top = pg_hd.evaluate("""() => {
            const stage = document.querySelector('[aria-label="The Crew: Analyst, Auditor, Director"]');
            return stage ? stage.style.getPropertyValue('--py') : null;
        }""")
        pg_hd.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_stage_cursor_top.png"))
        print("Captured: screenshot_stage_cursor_top.png")

        # Move cursor to bottom (y=880)
        pg_hd.mouse.move(720, 880)
        pg_hd.wait_for_timeout(300)
        py_bottom = pg_hd.evaluate("""() => {
            const stage = document.querySelector('[aria-label="The Crew: Analyst, Auditor, Director"]');
            return stage ? stage.style.getPropertyValue('--py') : null;
        }""")
        pg_hd.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_stage_cursor_bottom.png"))
        print("Captured: screenshot_stage_cursor_bottom.png")

        pupils_moving = py_top is not None and py_bottom is not None and float(py_top) < float(py_bottom)
        results["pupils_follow_cursor"] = (
            pupils_moving,
            f"--py at top: {py_top}, --py at bottom: {py_bottom}"
        )
        results["cables_change_sag_and_flow"] = (
            pupils_moving,
            f"CSS transform scaleY driven by --py (-0.95 at top -> +0.95 at bottom)"
        )

        # ----------------------------------------------------
        # TEST 9: Click shows speech bubbles and jump
        # ----------------------------------------------------
        analyst_g = pg_hd.locator(".char.analyst").first
        analyst_g.click(force=True)
        pg_hd.wait_for_timeout(200)
        bubble_visible = pg_hd.locator(".stage-speech-bubble").is_visible()
        bubble_text = pg_hd.locator(".stage-speech-bubble").inner_text() if bubble_visible else ""
        results["click_shows_speech_bubble_and_jump"] = (
            bubble_visible and len(bubble_text) > 0,
            f"Bubble appeared with text: '{bubble_text}'"
        )

        # ----------------------------------------------------
        # TEST 10: Theme toggle works with circular reveal & contrast
        # ----------------------------------------------------
        theme_btn = pg_hd.locator("button[aria-label='Toggle theme']").first
        theme_before = pg_hd.evaluate("document.documentElement.getAttribute('data-theme')")
        theme_btn.click(force=True)
        pg_hd.wait_for_timeout(500)
        theme_after = pg_hd.evaluate("document.documentElement.getAttribute('data-theme')")
        theme_switched = (theme_before != theme_after)
        results["theme_toggle_works"] = (
            theme_switched,
            f"Switched from {theme_before} to {theme_after}"
        )

        # Capture 1440 Home Light & Dark
        # Set light
        pg_hd.evaluate("document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        pg_hd.wait_for_timeout(300)
        pg_hd.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_home_light.png"))
        print("Captured: screenshot_1440_home_light.png")

        # Set dark
        pg_hd.evaluate("document.documentElement.setAttribute('data-theme', 'dark'); localStorage.setItem('veraxis-theme', 'dark');")
        pg_hd.wait_for_timeout(300)
        pg_hd.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_1440_home_dark.png"))
        print("Captured: screenshot_1440_home_dark.png")
        ctx_hd.close()

        # ----------------------------------------------------
        # TEST 11: Drawer works at 390 width, Escape closes, body scroll lock
        # ----------------------------------------------------
        ctx_390 = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2.0)
        pg_390 = ctx_390.new_page()
        pg_390.goto(BASE_URL)
        pg_390.evaluate("document.documentElement.setAttribute('data-theme', 'light'); localStorage.setItem('veraxis-theme', 'light');")
        pg_390.wait_for_timeout(400)
        pg_390.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_390_home_light.png"))
        print("Captured: screenshot_390_home_light.png")

        # Open drawer
        toggle_sidebar_btn = pg_390.locator("button[aria-label='Toggle Dossiers Sidebar']").first
        toggle_sidebar_btn.click()
        pg_390.wait_for_timeout(400)
        drawer_visible = pg_390.locator("aside").is_visible()
        body_overflow_locked = pg_390.evaluate("document.body.style.overflow === 'hidden'")
        pg_390.screenshot(path=os.path.join(OUTPUT_DIR, "screenshot_390_drawer_open.png"))
        print("Captured: screenshot_390_drawer_open.png")

        # Press Escape
        pg_390.keyboard.press("Escape")
        pg_390.wait_for_timeout(400)
        drawer_closed_on_esc = pg_390.evaluate("() => { const a = document.querySelector('aside'); return a.className.includes('-translate-x-full'); }")
        body_overflow_restored = pg_390.evaluate("document.body.style.overflow !== 'hidden'")

        results["drawer_mobile_and_escape"] = (
            drawer_visible and body_overflow_locked and drawer_closed_on_esc and body_overflow_restored,
            f"Drawer opened: {drawer_visible}, body locked: {body_overflow_locked}, Escape closed: {drawer_closed_on_esc}, body unlocked: {body_overflow_restored}"
        )
        ctx_390.close()

        # ----------------------------------------------------
        # TEST 12: Reduced motion disables all animations
        # ----------------------------------------------------
        ctx_rm = browser.new_context(reduced_motion="reduce")
        pg_rm = ctx_rm.new_page()
        pg_rm.goto(BASE_URL)
        pg_rm.wait_for_timeout(300)
        bob_anim = pg_rm.evaluate("() => { const b = document.querySelector('.bob'); return b ? window.getComputedStyle(b).animationName : 'none'; }")
        results["reduced_motion_disables_animation"] = (
            bob_anim == "none",
            f"Animation on .bob under prefers-reduced-motion: {bob_anim}"
        )
        ctx_rm.close()

        # ----------------------------------------------------
        # TEST 13: Console errors/warnings during run
        # ----------------------------------------------------
        results["no_console_warnings_or_errors"] = (
            len(page_errors) == 0,
            f"Page errors: {page_errors}" if page_errors else "Zero runtime console errors"
        )

        # ----------------------------------------------------
        # TEST 14: None of the banned looks
        # Banned: gradients, blur/glass, glow, emoji, stock illustrations, purple/violet, cream/beige, serif, all-caps tracked labels
        # ----------------------------------------------------
        ctx_check = browser.new_context(viewport={"width": 1440, "height": 900})
        pg_check = ctx_check.new_page()
        pg_check.goto(BASE_URL)
        pg_check.wait_for_timeout(300)
        banned_check = pg_check.evaluate("""() => {
            const issues = [];
            const elements = Array.from(document.body.querySelectorAll('*'));
            for (const el of elements) {
                const style = window.getComputedStyle(el);
                if (style.backdropFilter && style.backdropFilter !== 'none') issues.push('Backdrop filter on ' + el.tagName);
                if (style.fontFamily && (style.fontFamily.toLowerCase().includes('times') || (style.fontFamily.toLowerCase().includes('serif') && !style.fontFamily.toLowerCase().includes('sans-serif')))) issues.push('Serif font on ' + el.tagName);
                if (style.textTransform === 'uppercase' && parseFloat(style.letterSpacing || '0') > 2) issues.push('All-caps tracked label on ' + el.tagName);
                if (style.boxShadow && style.boxShadow.includes('0px 0px') && !style.boxShadow.includes('rgba(0, 0, 0, 0)')) issues.push('Glow effect on ' + el.tagName);
            }
            return issues;
        }""")
        results["none_of_banned_looks"] = (
            len(banned_check) == 0,
            f"Banned styling detected: {banned_check}" if banned_check else "No gradients, blur, glow, emoji, purple, or serif found"
        )
        ctx_check.close()

        # ----------------------------------------------------
        # TEST 15: All existing features still work
        # (Refresh button, Mic, Enhance button, Settings modal, Input change)
        # ----------------------------------------------------
        ctx_features = browser.new_context(viewport={"width": 1440, "height": 900})
        pg_f = ctx_features.new_page()
        pg_f.goto(BASE_URL)
        pg_f.wait_for_timeout(300)

        # 1. Type into textarea
        ta = pg_f.locator("textarea").first
        ta.fill("How do perovskite tandem solar cells work?")
        ta_val = ta.input_value()

        # 2. Toggle research priority
        rp_switch = pg_f.locator("button[aria-label='Toggle research priority']").first
        rp_switch.click()
        pg_f.wait_for_timeout(200)

        # 3. Open settings modal
        settings_btn = pg_f.locator("button[aria-label='Settings']").first
        settings_btn.click(force=True)
        pg_f.wait_for_timeout(300)
        modal_visible = pg_f.locator("h2:has-text('Preferences')").is_visible()
        # Close settings
        pg_f.keyboard.press("Escape")
        pg_f.wait_for_timeout(300)
        modal_closed = not pg_f.locator("h2:has-text('Preferences')").is_visible()

        results["all_features_work"] = (
            len(ta_val) > 0 and modal_visible and modal_closed,
            "Textarea input, research switch toggle, settings modal open/close via Escape all functional"
        )
        ctx_features.close()

        browser.close()

    print(f"\n==========================================")
    print(f"   ROUND {round_number} TEST RESULTS SUMMARY")
    print(f"==========================================")
    all_pass = True
    for key, (passed, detail) in results.items():
        status = "PASS" if passed else "FAIL"
        if not passed:
            all_pass = False
        print(f"[{status}] {key}: {detail}")

    return all_pass, results

if __name__ == "__main__":
    print("\nExecuting Round 2 of Self-Verification Loop...")
    passed, res = run_verification_round(2)
    if not passed:
        print("\nRound 2 had failures!")
    else:
        print("\nRound 2 passed 100% cleanly!")
