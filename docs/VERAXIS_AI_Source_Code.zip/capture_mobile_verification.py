import asyncio
from playwright.async_api import async_playwright

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch()

        # Test 1: Mobile Light Mode (375x667 - iPhone SE / standard mobile)
        context_light = await browser.new_context(
            viewport={"width": 375, "height": 667},
            device_scale_factor=2,
            is_mobile=True,
            has_touch=True,
        )
        page_light = await context_light.new_page()
        await page_light.add_init_script("localStorage.setItem('veraxis-theme', 'light'); localStorage.removeItem('veraxis_sessions'); localStorage.removeItem('veraxis-active-session');")
        await page_light.goto("http://localhost:8000")
        await page_light.wait_for_timeout(1500)
        await page_light.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/mobile_375_light.png")
        print("Captured mobile_375_light.png")

        # Test 2: Mobile Dark Mode (390x844 - iPhone 14)
        context_dark = await browser.new_context(
            viewport={"width": 390, "height": 844},
            device_scale_factor=2,
            is_mobile=True,
            has_touch=True,
        )
        page_dark = await context_dark.new_page()
        await page_dark.add_init_script("localStorage.setItem('veraxis-theme', 'dark'); localStorage.removeItem('veraxis_sessions'); localStorage.removeItem('veraxis-active-session');")
        await page_dark.goto("http://localhost:8000")
        await page_dark.wait_for_timeout(1500)
        await page_dark.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/mobile_390_dark.png")
        print("Captured mobile_390_dark.png")

        # Test 3: Desktop Light Mode (1280x800)
        context_desktop = await browser.new_context(
            viewport={"width": 1280, "height": 800},
            device_scale_factor=1,
        )
        page_desk = await context_desktop.new_page()
        await page_desk.add_init_script("localStorage.setItem('veraxis-theme', 'light'); localStorage.removeItem('veraxis_sessions'); localStorage.removeItem('veraxis-active-session');")
        await page_desk.goto("http://localhost:8000")
        await page_desk.wait_for_timeout(1500)
        await page_desk.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/desktop_1280_light.png")
        print("Captured desktop_1280_light.png")

        # Test 4: Query flow in mobile light mode
        textarea = await page_light.query_selector("textarea")
        if textarea:
            await textarea.fill("hello")
            await page_light.keyboard.press("Enter")
            await page_light.wait_for_timeout(4000)
            await page_light.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/mobile_chat_light.png")
            print("Captured mobile_chat_light.png")

        await browser.close()

asyncio.run(run())
