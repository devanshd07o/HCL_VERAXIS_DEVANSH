import asyncio
from playwright.async_api import async_playwright

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        context = await browser.new_context(viewport={"width": 1280, "height": 800}, device_scale_factor=1)
        page = await context.new_page()
        await page.goto("http://localhost:8000")
        await page.wait_for_timeout(1000)

        # Find which session in localStorage has research messages
        session_info = await page.evaluate("""() => {
            const raw = localStorage.getItem('veraxis_sessions');
            if (!raw) return null;
            const sessions = JSON.parse(raw);
            const found = sessions.find(s => s.messages && s.messages.some(m => m.type === 'research'));
            return found ? { id: found.id, title: found.title } : null;
        }""")
        print("Research session found:", session_info)

        if session_info:
            await page.evaluate(f"localStorage.setItem('veraxis-active-session', '{session_info['id']}');")
            await page.reload()
            await page.wait_for_timeout(1500)
            await page.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/research_inspector_open.png")
            print("Captured research_inspector_open.png")

            # Click Hide Panel
            hide_btn = await page.query_selector("button:has-text('Hide Panel'), button[title*='Hide research panel']")
            if hide_btn:
                print("Found Hide button, clicking...")
                await hide_btn.click()
                await page.wait_for_timeout(800)
                await page.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/research_inspector_hidden.png")
                print("Captured research_inspector_hidden.png")

                # Click floating Sources & Steps button to unhide
                floating_btn = await page.query_selector("button:has-text('Sources & Steps'), button[title*='Expand Sources']")
                if floating_btn:
                    print("Found floating unhide button, clicking...")
                    await floating_btn.click()
                    await page.wait_for_timeout(800)
                    await page.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/research_inspector_restored.png")
                    print("Captured research_inspector_restored.png")
        else:
            print("No saved research session in localStorage, triggering new quick research query...")
            # Let's insert a mock research session into localStorage to test the UI reliably
            await page.evaluate("""() => {
                const mockSession = {
                    id: "test-research-session",
                    title: "Solid-State Battery Electrolytes Research",
                    createdAt: new Date().toISOString(),
                    messages: [
                        { id: "u-1", role: "user", content: "Explain Solid-State Battery Ceramic Electrolytes in simple words.", createdAt: new Date().toISOString() },
                        {
                            id: "r-1",
                            role: "assistant",
                            type: "research",
                            topic: "Solid-State Battery Ceramic Electrolytes",
                            duration: "14.2s",
                            sources: [
                                { title: "Wikipedia: Solid-state battery", url: "https://en.wikipedia.org/wiki/Solid-state_battery", badge: "Wikipedia" },
                                { title: "Nature Energy: Ceramic electrolytes for lithium batteries", url: "https://www.nature.com/articles/nenergy.2023.1", badge: "Nature" },
                                { title: "Science: Solid-state lithium transport kinetics", url: "https://science.org/doi/10.1126/science.abg1234", badge: "Science" }
                            ],
                            thinkingSteps: [
                                { agent: "Planner", step: "Decomposed question into core ceramic electrolyte categories (LLZO, NASICON, Sulfides)" },
                                { agent: "Searcher", step: "Queried Wikipedia, Nature Energy, Science for ionic conductivity benchmarks" },
                                { agent: "Fact-Checker", step: "Verified ambient conductivity thresholds: >1.0 mS/cm at 25°C" },
                                { agent: "Writer", step: "Synthesized clear multi-section verified dossier with plain explanations" }
                            ],
                            pdf_filename: "Solid-State_Battery_Electrolytes.pdf",
                            content: "# Solid-State Battery Ceramic Electrolytes\\n\\n### Simple Summary\\nSolid-state ceramic electrolytes replace flammable liquid solutions in traditional lithium batteries with solid ceramic pellets or flexible ceramic films.\\n\\n### Key Advantages\\n- **Zero fire hazard**: Ceramics do not catch fire or leak.\\n- **Higher energy density**: Enables pure metallic lithium anodes.\\n- **Longer cycle life**: Resists dendrite punctures.",
                            createdAt: new Date().toISOString()
                        }
                    ]
                };
                const existing = JSON.parse(localStorage.getItem('veraxis_sessions') || '[]');
                existing.unshift(mockSession);
                localStorage.setItem('veraxis_sessions', JSON.stringify(existing));
                localStorage.setItem('veraxis-active-session', 'test-research-session');
            }""")
            await page.reload()
            await page.wait_for_timeout(1500)
            await page.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/research_inspector_open.png")
            print("Captured research_inspector_open.png with mock session")

            # Click Hide Panel
            hide_btn = await page.query_selector("button:has-text('Hide Panel'), button[title*='Hide research panel']")
            if hide_btn:
                print("Found Hide button, clicking...")
                await hide_btn.click()
                await page.wait_for_timeout(800)
                await page.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/research_inspector_hidden.png")
                print("Captured research_inspector_hidden.png")

                # Click floating Sources & Steps button to unhide
                floating_btn = await page.query_selector("button:has-text('Sources & Steps'), button[title*='Expand Sources']")
                if floating_btn:
                    print("Found floating unhide button, clicking...")
                    await floating_btn.click()
                    await page.wait_for_timeout(800)
                    await page.screenshot(path="C:/Users/devan/.gemini/antigravity/brain/a88ade6b-6101-4028-9398-fd927f10433f/research_inspector_restored.png")
                    print("Captured research_inspector_restored.png")

        await browser.close()

asyncio.run(run())
