"""
VERAXIS AI — Dual-Engine Router, Live Token Streamer & Plain-Language Fast Chat LLM
1. ThinkFilterStream: Strips <think>...</think> safely during token-by-token SSE streaming.
2. Intent Classifier: Routes everyday questions/chat -> GENERAL_CHAT, deep research/comparisons -> DEEP_RESEARCH.
3. Fast Chat Engine & Streamer: Warm, crystal-clear 10th-grade understandable answers via Groq LPU.
"""

import json
import re
from typing import Dict, Any, List, Iterator
from openai import OpenAI

try:
    from backend.config import key_manager
except ImportError:
    from config import key_manager


def strip_think_tags(text: str) -> str:
    """Remove internal reasoning <think>...</think> tags from LLM output."""
    if not text:
        return ""
    return re.sub(r"<think>[\s\S]*?</think>", "", text).strip()


class ThinkFilterStream:
    """Incremental streaming filter that drops <think>...</think> blocks cleanly."""

    def __init__(self) -> None:
        self._buf = ""
        self._inside_think = False
        self._started = False

    def feed(self, token: str) -> str:
        if not token:
            return ""
        self._buf += token
        out: List[str] = []

        while self._buf:
            if self._inside_think:
                end_idx = self._buf.find("</think>")
                if end_idx != -1:
                    self._buf = self._buf[end_idx + len("</think>"):]
                    self._inside_think = False
                else:
                    # Retain small suffix in case '</think>' straddles chunks
                    if len(self._buf) > 12:
                        self._buf = self._buf[-12:]
                    break
            else:
                start_idx = self._buf.find("<think>")
                if start_idx != -1:
                    before = self._buf[:start_idx]
                    if before:
                        out.append(before)
                    self._buf = self._buf[start_idx + len("<think>"):]
                    self._inside_think = True
                else:
                    # Hold trailing partial prefix if buffer ends with '<' match prefix
                    hold = 0
                    for k in range(min(len(self._buf), 7), 0, -1):
                        if "<think>".startswith(self._buf[-k:]):
                            hold = k
                            break
                    if hold:
                        emit_part = self._buf[:-hold]
                        if emit_part:
                            out.append(emit_part)
                        self._buf = self._buf[-hold:]
                        break
                    out.append(self._buf)
                    self._buf = ""

        joined = "".join(out)
        if not self._started:
            joined = joined.lstrip()
            if joined:
                self._started = True
        return joined

    def flush(self) -> str:
        if self._inside_think:
            self._buf = ""
            return ""
        rem = self._buf
        self._buf = ""
        return rem if self._started else rem.lstrip()


def get_groq_client() -> OpenAI:
    """Return an OpenAI client configured for Groq with key rotation."""
    key = key_manager.get_active_groq_key()
    return OpenAI(
        base_url="https://api.groq.com/openai/v1",
        api_key=key
    )


def stream_groq_tokens(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float = 0.25,
    max_tokens: int = 1200,
) -> Iterator[str]:
    """Stream clean text tokens from Groq with <think> filtering and key failover."""
    max_attempts = min(3, len(key_manager.groq_keys) or 1)
    last_err: Exception | None = None

    for _ in range(max_attempts):
        client = None
        emitted_any = False
        think_filter = ThinkFilterStream()
        try:
            client = get_groq_client()
            stream = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )
            for chunk in stream:
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if not delta:
                    continue
                cleaned = think_filter.feed(delta)
                if cleaned:
                    emitted_any = True
                    yield cleaned
            tail = think_filter.flush()
            if tail:
                emitted_any = True
                yield tail
            return
        except Exception as err:
            last_err = err
            print(f"[RouterStream] Attempt error: {err}")
            try:
                if client is not None and getattr(client, "api_key", None):
                    key_manager.mark_rate_limited(client.api_key)
            except Exception:
                pass
            if emitted_any:
                break

    if last_err:
        yield f"\n\nNotice: Response interrupted ({str(last_err)})."


def classify_query_intent(query: str, chat_history: List[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Classifies user intent cleanly:
    - GENERAL_CHAT: Greetings, everyday questions, simple definitions, follow-ups, quick help.
    - DEEP_RESEARCH: Explicit deep analysis, multi-paper benchmarks, comparisons, feasibility, literature reviews.
    """
    clean_q = query.strip().lower()

    common_chats = [
        "hello", "hi", "hey", "hola", "namaste", "good morning", "good evening",
        "good afternoon", "how are you", "how are you doing", "what's up", "whats up",
        "who are you", "what can you do", "help", "thanks", "thank you", "bye",
        "goodbye", "test", "ping", "ok", "okay", "sup", "yo"
    ]
    if clean_q in common_chats or any(clean_q.startswith(g + " ") for g in ["hello", "hi", "hey"]):
        return {
            "intent": "GENERAL_CHAT",
            "extracted_topic": query,
            "confidence": 1.0,
            "reasoning": "Instant zero-latency casual greeting match"
        }

    system_prompt = (
        "You are the VERAXIS Intent Classifier.\n"
        "Choose 'DEEP_RESEARCH' ONLY when the user wants a detailed multi-source research report, literature/paper analysis, market comparison, benchmarks, clinical trials, feasibility study, or long technical deep dive.\n"
        "Choose 'GENERAL_CHAT' for greetings, normal conversation, simple explanations ('what is X', 'explain Y simply', homework help), short coding questions, or summaries of attached notes.\n\n"
        "Respond ONLY with valid JSON (no markdown, no backticks):\n"
        '{"intent": "GENERAL_CHAT" | "DEEP_RESEARCH", "extracted_topic": "short 2-5 word topic", "confidence": 0.95, "reasoning": "brief reason"}'
    )

    try:
        client = get_groq_client()
        response = client.chat.completions.create(
            model=key_manager.fast_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query}
            ],
            temperature=0.0,
            max_tokens=100
        )
        content = strip_think_tags(response.choices[0].message.content or "")
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group(0))
            if "intent" in data and data["intent"] in ["GENERAL_CHAT", "DEEP_RESEARCH"]:
                return data
    except Exception:
        pass

    research_indicators = [
        "commercial", "viability", "benchmark", "paper", "arxiv", "literature",
        "feasibility", "versus", " vs ", "forecast", "comparison", "compare",
        "empirical", "clinical trial", "state of the art", "roadmap", "report",
        "pdf", "deep research", "peer-reviewed", "evidence", "breakthrough"
    ]
    is_deep = any(term in clean_q for term in research_indicators)

    return {
        "intent": "DEEP_RESEARCH" if is_deep else "GENERAL_CHAT",
        "extracted_topic": query,
        "confidence": 0.85,
        "reasoning": "Keyword intent analysis"
    }


def rephrase_query_for_research(query: str) -> Dict[str, str]:
    """
    Creates a clean short topic title + tight 3-5 word academic search phrase
    so Wikipedia, OpenAlex & arXiv return highly relevant on-topic sources.
    """
    client = get_groq_client()
    system_instruction = (
        "You optimize a user's question for encyclopedias and science search APIs.\n"
        "Return JSON ONLY with 3 fields:\n"
        '{"topic_title": "Short 2-5 word title", "enhanced_query": "Clear 1-sentence question in plain English", "search_keywords": "3 to 5 core topic words separated by spaces (no commas)"}\n'
        "Keep search_keywords clean and tight (example: 'solid state battery ceramic electrolyte')."
    )
    try:
        response = client.chat.completions.create(
            model=key_manager.fast_model,
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": query}
            ],
            temperature=0.15,
            max_tokens=200
        )
        content = strip_think_tags(response.choices[0].message.content or "")
        json_match = re.search(r'\{.*\}', content, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group(0))
            if "enhanced_query" in data:
                return data
    except Exception as err:
        print(f"[Router] Rephrase fallback: {err}")
    short = " ".join(query.strip().split()[:5])
    return {"topic_title": short, "enhanced_query": query, "search_keywords": short}


FAST_CHAT_SYSTEM_PROMPT = (
    "You are Veraxis, a friendly and clear AI assistant.\n"
    "RULES FOR WRITING QUALITY:\n"
    "1. Write so simply and clearly that a smart 10th-class student understands every sentence immediately.\n"
    "2. Never use heavy corporate or PhD jargon when an everyday word works better. If a technical word is needed, explain it in parentheses right away.\n"
    "3. Keep greetings super brief (1-2 friendly sentences).\n"
    "4. For questions or file summaries, answer directly using short paragraphs (2-3 lines max) and crisp bullet points when helpful.\n"
    "5. Reply in clean English or Hinglish to match the user's style. Never add fake citations or talk about internal modes."
)


def prepare_fast_chat_messages(messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Build sanitized multi-turn message list for fast chat streaming or sync calls."""
    clean_history = []
    for m in messages[-10:]:
        if isinstance(m, dict) and "role" in m and "content" in m and isinstance(m["content"], str):
            role = "assistant" if m["role"] == "bot" else m["role"]
            if role in ("user", "assistant"):
                clean_history.append({"role": role, "content": m["content"][:3000]})
    return [{"role": "system", "content": FAST_CHAT_SYSTEM_PROMPT}] + clean_history


def generate_fast_chat_response(messages: List[Dict[str, str]]) -> str:
    """Generate a clear, conversational response for GENERAL_CHAT queries."""
    client = get_groq_client()
    full_messages = prepare_fast_chat_messages(messages)

    try:
        response = client.chat.completions.create(
            model=key_manager.fast_model,
            messages=full_messages,
            temperature=0.3,
            max_tokens=750
        )
        return strip_think_tags(response.choices[0].message.content or "")
    except Exception as e:
        return f"Encountered temporary error: {str(e)}. Please retry."

