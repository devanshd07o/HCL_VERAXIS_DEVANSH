import sys
import json
import os

sys.path.insert(0, r'D:\LetsCode\My_Project\ZERNEXA\backend')
import config

cfg = config.load_config()
fernet = config._get_fernet()

all_extracted = {
    'models': {},
    'auxiliary_services': {}
}

# 1. Models
for m_name, m_cfg in cfg.get('models', {}).items():
    all_extracted['models'][m_name] = []
    for k_item in m_cfg.get('keys', []):
        raw_val = k_item.get('key', '') if isinstance(k_item, dict) else str(k_item)
        dec_val = config._decrypt_key(fernet, raw_val)
        if dec_val:
            all_extracted['models'][m_name].append({
                'key': dec_val,
                'model_id': k_item.get('model_id', '') if isinstance(k_item, dict) else ''
            })

# 2. Auxiliary Services
for s_name, s_keys in cfg.get('auxiliary_services', {}).items():
    all_extracted['auxiliary_services'][s_name] = []
    if isinstance(s_keys, list):
        for k_item in s_keys:
            raw_val = k_item.get('key', '') if isinstance(k_item, dict) else str(k_item)
            dec_val = config._decrypt_key(fernet, raw_val)
            if dec_val:
                all_extracted['auxiliary_services'][s_name].append(dec_val)

# Save JSON bundle in project root
json_out = r'D:\LetsCode\My_Project\MULTIINTELIGENCE\ZERNEXA_KEYS_EXPORT.json'
with open(json_out, 'w', encoding='utf-8') as f:
    json.dump(all_extracted, f, indent=2)

# Save into assets/service_keys.json for MULTIINTELIGENCE runtime
assets_out = r'D:\LetsCode\My_Project\MULTIINTELIGENCE\assets\service_keys.json'
with open(assets_out, 'w', encoding='utf-8') as f:
    json.dump(all_extracted['auxiliary_services'], f, indent=2)

# Save formatted .env ready text file
env_out = r'D:\LetsCode\My_Project\MULTIINTELIGENCE\ZERNEXA_KEYS_ENV.txt'
lines = [
    '# =============================================================================',
    '# ZERNEXA MASTER API KEYS BUNDLE (IMPORTED FOR MULTIINTELIGENCE)',
    '# =============================================================================\n'
]

lines.append('# --- RESEARCH & ACADEMIC SEARCH KEYS ---')
if all_extracted['auxiliary_services'].get('tavily'):
    t_keys = all_extracted['auxiliary_services']['tavily']
    joined = ','.join(t_keys)
    lines.append(f'TAVILY_API_KEY={t_keys[0]}')
    lines.append(f'TAVILY_KEYS={joined}')
    lines.append(f'# Total Tavily Keys: {len(t_keys)} (8 keys x 950 = ~7,600 free queries/month)\n')

if all_extracted['auxiliary_services'].get('semantic_scholar'):
    s2 = all_extracted['auxiliary_services']['semantic_scholar']
    lines.append(f'SEMANTIC_SCHOLAR_API_KEY={s2[0]}\n')

if all_extracted['auxiliary_services'].get('serper'):
    serp = all_extracted['auxiliary_services']['serper']
    lines.append(f'SERPER_API_KEY={serp[0]}  # Google Scholar API\n')

if all_extracted['auxiliary_services'].get('exa'):
    exa = all_extracted['auxiliary_services']['exa']
    joined = ','.join(exa)
    lines.append(f'EXA_API_KEY={exa[0]}')
    lines.append(f'EXA_KEYS={joined}\n')

if all_extracted['auxiliary_services'].get('jina'):
    jina = all_extracted['auxiliary_services']['jina']
    lines.append(f'JINA_API_KEY={jina[0]}\n')

lines.append('\n# --- LLM INFERENCE ENGINE KEYS ---')
if all_extracted['models'].get('groq-llama'):
    groq_list = [k['key'] for k in all_extracted['models']['groq-llama'] if k['key']]
    joined = ','.join(groq_list)
    lines.append(f'GROQ_PRIMARY_KEY={groq_list[0]}')
    lines.append(f'GROQ_ALL_KEYS={joined}')
    lines.append(f'# Total Groq Keys available: {len(groq_list)}\n')

if all_extracted['models'].get('gemini-flash'):
    gem_list = [k['key'] for k in all_extracted['models']['gemini-flash'] if k['key']]
    joined = ','.join(gem_list)
    lines.append(f'GEMINI_API_KEY={gem_list[0]}')
    lines.append(f'GEMINI_ALL_KEYS={joined}')
    lines.append(f'# Total Gemini Keys available: {len(gem_list)}\n')

if all_extracted['models'].get('cerebras'):
    cer_list = [k['key'] for k in all_extracted['models']['cerebras'] if k['key']]
    joined = ','.join(cer_list)
    lines.append(f'CEREBRAS_API_KEY={cer_list[0]}')
    lines.append(f'CEREBRAS_ALL_KEYS={joined}')
    lines.append(f'# Total Cerebras Keys available: {len(cer_list)}\n')

if all_extracted['models'].get('openrouter'):
    or_list = [k['key'] for k in all_extracted['models']['openrouter'] if k['key']]
    joined = ','.join(or_list)
    lines.append(f'OPENROUTER_API_KEY={or_list[0]}')
    lines.append(f'OPENROUTER_ALL_KEYS={joined}\n')

if all_extracted['models'].get('nvidia'):
    nv_list = [k['key'] for k in all_extracted['models']['nvidia'] if k['key']]
    lines.append(f'NVIDIA_API_KEY={nv_list[0]}\n')

lines.append('\n# --- VOICE & TTS ENGINES ---')
for v_name in ['elevenlabs', 'cartesia', 'lmnt', 'unreal', 'hume']:
    if all_extracted['auxiliary_services'].get(v_name):
        v_keys = all_extracted['auxiliary_services'][v_name]
        joined = ','.join(v_keys)
        lines.append(f'{v_name.upper()}_API_KEY={v_keys[0]}')
        lines.append(f'{v_name.upper()}_ALL_KEYS={joined}')
        lines.append(f'# Total {v_name} keys: {len(v_keys)}\n')

with open(env_out, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines))

print('SUCCESS: Created ZERNEXA_KEYS_EXPORT.json and ZERNEXA_KEYS_ENV.txt')
