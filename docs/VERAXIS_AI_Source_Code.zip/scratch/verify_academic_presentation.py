import asyncio
from playwright.async_api import async_playwright

ARTIFACT_DIR = r"C:\Users\devan\.gemini\antigravity\brain\a88ade6b-6101-4028-9398-fd927f10433f"

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)

        mock_session = [{
            "id": "sess-presentation-upgrade",
            "title": "Quantum Error Correction Surface Codes",
            "createdAt": "2026-11-14T08:00:00.000Z",
            "messages": [
                {
                    "id": "u-1",
                    "role": "user",
                    "content": "What is quantum error correction in surface codes?"
                },
                {
                    "id": "b-1",
                    "role": "bot",
                    "type": "research",
                    "topic": "Quantum Error Correction Surface Codes",
                    "duration": "12.4s",
                    "pdf_filename": "VERAXIS_Quantum_Error_20261114.pdf",
                    "sources": [
                        {"title": "Stabilizer codes and quantum error correction (Cited by 4366)", "url": "https://scholar.google.com/citations?view_op=view_citation&citation_for_view=1", "badge": "Google"},
                        {"title": "Quantum error correction for beginners (841)", "url": "https://openalex.org/W2145329876", "badge": "OpenAlex"},
                        {"title": "Fault-tolerant quantum computation with surface codes", "url": "https://semanticscholar.org/paper/12345", "badge": "Semantic"},
                        {"title": "Surface code preprints on physical qubits", "url": "https://arxiv.org/abs/1208.0928", "badge": "ArXiv"},
                        {"title": "Wikipedia: Quantum error correction", "url": "https://en.wikipedia.org/wiki/Quantum_error_correction", "badge": "Wikipedia"},
                        {"title": "Journal of Quantum Information and Computation", "url": "https://europepmc.org/article/PMC/123456", "badge": "Journal"},
                        {"title": "Market Benchmarks for Fault-Tolerant Qubits", "url": "https://tavily.com/market-brief", "badge": "Market"}
                    ],
                    "content": """# Executive Summary & Scientific Consensus
Quantum error correction (QEC) protects fragile quantum information from environmental decoherence by redundantly encoding logical qubits across 2D physical qubit lattices. In planar surface codes, stabilizer syndrome measurements detect bit-flip ($X$) and phase-flip ($Z$) errors without collapsing superposed logical state vectors.

> **GRADE Evidence Certainty:** High | **Consensus Level:** ~92% agreement across empirical transmon and ion-trap implementations.

## Comparative Methodology Matrix
| Study / Paper | Core Paradigm & Approach | Primary Reported Findings | Platform / Scope | Stated Trade-offs & Limitations |
| :--- | :--- | :--- | :--- | :--- |
| **Gottesman (1997)** | Stabilizer Formalism | Unified algebraic formulation for abelian Pauli syndrome extraction. | Theoretical Group Theory | Exponential gate overhead if Clifford boundaries aren't fault-tolerant. |
| **Fowler et al. (2012)** | Surface Code on 2D Lattices | Achieved ~1% fault-tolerance threshold with 2D nearest-neighbor coupling. | Transmon Superconducting Array | 1,000 to 10,000 physical qubits required per logical qubit. |
| **Google Quantum AI (2023)** | Sycamore Distance-5 Surface Code | Suppressed logical error rates below distance-3 in physical hardware. | Superconducting Qubit Processor | Residual leakage states and crosstalk during syndromic extraction. |
| **Bluvstein et al. (2024)** | Neutral-Atom Logical Arrays | Demonstrated 48 logical qubits with transversal non-Clifford gates. | Rydberg Optical Tweezers | Laser phase noise and shuttle shuttling latency constraints. |

## Methodological Mechanisms & Empirical Findings
Physical qubits suffer from both relaxation ($T_1$) and dephasing ($T_2$) noise. The 2D surface code arranges data qubits and syndrome (measure) qubits on an alternating checkerboard. The stabilizer operators are defined as:

$$S_v = \\prod_{i \\in v} X_i, \\quad P_p = \\prod_{j \\in p} Z_j$$

Empirical benchmarks demonstrate that when the physical gate error rate $p < p_{th} \\approx 1.0\\%$, increasing the code distance $d$ exponentially suppresses logical errors according to $P_L \\propto (p / p_{th})^{(d+1)/2}$.

## Critical Limitations & Diverging Findings
While the theoretical threshold is ~1%, commercial fault tolerance requires physical gate error rates below $10^{-3}$ to keep qubit overhead manageable. Current superconductors face serious scaling bottlenecks:
- **Routing Congestion**: Planar wiring density in cryostats limits monolithic arrays beyond 1,000 physical qubits.
- **Leakage States**: Non-computational $|2\\rangle$ state leakage invalidates standard 2-level Pauli syndrome decoders.

## Bibliography & Citation Ledger
| # | Title | Authors & Year | Venue / Database | Paper / PDF Access |
| :--- | :--- | :--- | :--- | :--- |
| 1 | Stabilizer codes and quantum error correction | D. Gottesman (1997) | Caltech Preprints | [PDF](https://arxiv.org/abs/quant-ph/9705052) |
| 2 | Surface codes: Towards practical large-scale quantum computation | A. Fowler et al. (2012) | Phys. Rev. A | [DOI](https://doi.org/10.1103/PhysRevA.86.032324) |
| 3 | Suppressing quantum errors by scaling a quantum error-correcting code | Google Quantum AI (2023) | Nature 614 | [DOI](https://doi.org/10.1038/s41586-022-05434-1) |
| 4 | Architectural benchmarks for neutral atom processors | M. Bluvstein et al. (2024) | Nature 626 | [DOI](https://doi.org/10.1038/s41586-023-06927-3) |
"""
                }
            ]
        }]

        # Dark Mode
        page_dark = await browser.new_page(viewport={"width": 1440, "height": 950})
        await page_dark.goto("http://localhost:8000/#/")
        await page_dark.evaluate("""(sessions) => {
            localStorage.setItem("veraxis_sessions", JSON.stringify(sessions));
            localStorage.setItem("veraxis-active-session", "sess-presentation-upgrade");
            localStorage.setItem("veraxis-theme", "dark");
            window.location.reload();
        }""", mock_session)
        await page_dark.wait_for_timeout(2500)
        await page_dark.screenshot(path=f"{ARTIFACT_DIR}\\report_presentation_dark.png", full_page=False)
        print("Captured report_presentation_dark.png")

        # Light Mode
        page_light = await browser.new_page(viewport={"width": 1440, "height": 950})
        await page_light.goto("http://localhost:8000/#/")
        await page_light.evaluate("""(sessions) => {
            localStorage.setItem("veraxis_sessions", JSON.stringify(sessions));
            localStorage.setItem("veraxis-active-session", "sess-presentation-upgrade");
            localStorage.setItem("veraxis-theme", "light");
            window.location.reload();
        }""", mock_session)
        await page_light.wait_for_timeout(2500)
        await page_light.screenshot(path=f"{ARTIFACT_DIR}\\report_presentation_light.png", full_page=False)
        print("Captured report_presentation_light.png")

        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())
