const { marked } = require("marked");

const raw = `[Wikipedia: Solid state](https://en.wikipedia.org/wiki/Solid_state)
[Paper: PEO/garnet composite electrolytes for solid-state lithium batteries: From “ceramic-in-polymer” to “polymer-in-ceramic” (1434 citations)]
(https://doi.org/10.1016/j.nanoen.2017.12.037)
[Paper: Rational Design of Hierarchical “Ceramic-in-Polymer” and “Polymer-in-Ceramic” Electrolytes for Dendrite-Free Solid-State Batteries (584 citations)]
(https://doi.org/10.1002/aenm.201804004)`;

console.log("DEFAULT MARKED:");
console.log(marked.parse(raw));

const normalized = raw.replace(/\[([^\]]+)\]\s*\n?\s*\((https?:\/\/[^\s)]+)\)/g, "[$1]($2)");
console.log("AFTER NORMALIZATION:");
console.log(marked.parse(normalized));
