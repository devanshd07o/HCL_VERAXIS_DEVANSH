import asyncio
from playwright.async_api import async_playwright

ARTIFACT_DIR = r"C:\Users\devan\.gemini\antigravity\brain\a88ade6b-6101-4028-9398-fd927f10433f"

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)

        # 1. Desktop Clean View
        page = await browser.new_page(viewport={"width": 1440, "height": 900})
        await page.goto("http://localhost:8000/#/")
        await page.wait_for_timeout(2000)
        await page.screenshot(path=f"{ARTIFACT_DIR}\\desktop_clean_composer.png", full_page=False)
        print("Captured desktop_clean_composer.png")

        # 2. Mic Inline Dictation Active
        mic_btn = page.locator('button[aria-label="Open voice query dictation"]')
        if await mic_btn.count() > 0:
            await mic_btn.click()
            await page.wait_for_timeout(1000)
            await page.screenshot(path=f"{ARTIFACT_DIR}\\mic_active_compact.png", full_page=False)
            print("Captured mic_active_compact.png")
            # Close mic
            done_btn = page.locator('button:has-text("Done")')
            if await done_btn.count() > 0:
                await done_btn.click()
                await page.wait_for_timeout(500)

        # 3. Mobile View (390 x 844)
        mobile_page = await browser.new_page(viewport={"width": 390, "height": 844})
        await mobile_page.goto("http://localhost:8000/#/")
        await mobile_page.wait_for_timeout(2000)
        await mobile_page.screenshot(path=f"{ARTIFACT_DIR}\\mobile_clean_composer.png", full_page=False)
        print("Captured mobile_clean_composer.png")

        # 4. Academic Research Session with Table & Badges
        mock_session = [{
            "id": "sess-academic-verify",
            "title": "Quantum Error Correction Surface Codes",
            "createdAt": "2026-11-14T08:00:00.000Z",
            "messages": [
                {
                    "id": "u-1",
                    "role": "user",
                    "content": "What is quantum error correction in surface codes?"
                },
                {
                    "id": "b-1",
                    "role": "bot",
                    "type": "research",
                    "topic": "Quantum Error Correction Surface Codes",
                    "duration": "12.4s",
                    "sources": [
                        {"title": "Stabilizer codes and quantum error correction (Cited by 4366)", "url": "https://scholar.google.com/citations?view_op=view_citation&citation_for_view=1", "badge": "Google"},
                        {"title": "Quantum error correction for beginners (841)", "url": "https://openalex.org/W2145329876", "badge": "OpenAlex"},
                        {"title": "Fault-tolerant quantum computation with surface codes", "url": "https://semanticscholar.org/paper/12345", "badge": "Semantic"},
                        {"title": "Surface code preprints on physical qubits", "url": "https://arxiv.org/abs/1208.0928", "badge": "ArXiv"},
                        {"title": "Wikipedia: Quantum error correction", "url": "https://en.wikipedia.org/wiki/Quantum_error_correction", "badge": "Wikipedia"},
                        {"title": "Journal of Quantum Information and Computation", "url": "https://europepmc.org/article/PMC/123456", "badge": "Journal"},
                        {"title": "Market Benchmarks for Fault-Tolerant Qubits", "url": "https://tavily.com/market-brief", "badge": "Market"}
                    ],
                    "content": """# Executive Summary
Quantum error correction (QEC) protects fragile quantum information from decoherence by redundantly encoding logical qubits across physical qubit lattices.

## Comparative Methodology Matrix
| Study / Paper | Core Paradigm & Approach | Primary Reported Findings | Platform / Scope | Stated Trade-offs & Limitations |
| :--- | :--- | :--- | :--- | :--- |
| **Gottesman (1997)** | Stabilizer Formalism | Unified algebraic formulation for abelian Pauli syndrome extraction. | Theoretical Group Theory | Exponential scaling if Clifford boundaries aren't fault-tolerant. |
| **Fowler et al. (2012)** | Surface Code on 2D Lattices | Achieved ~1% fault-tolerance threshold with 2D nearest-neighbor coupling. | Transmon Superconducting Array | 1,000 to 10,000 physical qubits required per logical qubit. |
| **Google Quantum AI (2023)** | Sycamore Distance-5 Surface Code | Suppressed logical error rates below distance-3 in physical hardware. | Superconducting Qubit Processor | Residual leakage states and crosstalk during syndromic extraction. |

## Sources Used
- [Stabilizer codes and quantum error correction](https://scholar.google.com)
- [Quantum error correction for beginners](https://openalex.org)
- [Fault-tolerant quantum computation](https://semanticscholar.org)
- [Surface code preprints](https://arxiv.org)
- [Wikipedia: Quantum error correction](https://en.wikipedia.org)
"""
                }
            ]
        }]

        research_page = await browser.new_page(viewport={"width": 1440, "height": 900})
        await research_page.goto("http://localhost:8000/#/")
        await research_page.evaluate("""(sessions) => {
            localStorage.setItem("veraxis_sessions", JSON.stringify(sessions));
            localStorage.setItem("veraxis-active-session", "sess-academic-verify");
            window.location.reload();
        }""", mock_session)
        await research_page.wait_for_timeout(2500)
        await research_page.screenshot(path=f"{ARTIFACT_DIR}\\academic_research_session.png", full_page=False)
        print("Captured academic_research_session.png")

        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())
