import { marked } from "../frontend/node_modules/marked/lib/marked.esm.js";

const text = `[Wikipedia: Solid state] (https://en.wikipedia.org/wiki/Solid_state)
[Paper: PEO/garnet composite electrolytes]
(https://doi.org/10.1016/j.nanoen.2017.12.037)`;

console.log("DEFAULT MARKED OUTPUT:\n", marked.parse(text));

// Normalizer:
function normalizeLinks(input) {
  // Join [Title] (url) -> [Title](url) and [Title]\n(url) -> [Title](url)
  return input.replace(/\[([^\]\n]+)\]\s*\n?\s*\((https?:\/\/[^\s)]+)\)/g, "[$1]($2)");
}

console.log("NORMALIZED MARKED OUTPUT:\n", marked.parse(normalizeLinks(text)));
