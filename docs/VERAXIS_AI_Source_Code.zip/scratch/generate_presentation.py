import os
import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

def create_deck():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6] # Blank slide

    # Color Palette Tokens (Anti-AI-Slop, High-Contrast Precision Dark Theme)
    BG_COLOR = RGBColor(10, 15, 29)          # Deep Obsidian / Canvas
    CARD_BG = RGBColor(17, 24, 39)           # Dark Slate Surface
    CARD_BG_ELEVATED = RGBColor(23, 33, 53)  # Slightly lighter card
    BORDER_COLOR = RGBColor(30, 41, 59)      # Subtle Slate Border 1px
    BORDER_HIGHLIGHT = RGBColor(51, 65, 85)  # Hover / prominent border
    TEXT_PRIMARY = RGBColor(248, 250, 252)   # Titanium White (100%)
    TEXT_MUTED = RGBColor(148, 163, 184)     # Silver Secondary (70%)
    TEXT_DIM = RGBColor(100, 116, 139)       # Slate Dim (50%)
    ACCENT_CYAN = RGBColor(14, 165, 233)     # Electric Cyan (Primary Accent)
    ACCENT_GREEN = RGBColor(16, 185, 129)    # Emerald Verification (Fact-check)
    ACCENT_AMBER = RGBColor(245, 158, 11)    # Amber Warning / Router
    ACCENT_ROSE = RGBColor(244, 63, 94)      # Crimson Error / Fallback

    def set_slide_background(slide):
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = BG_COLOR
        bg.line.fill.background() # No border
        return bg

    def add_header(slide, tag_text, title_text, subtitle_text=""):
        # Header Box
        header_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.733), Inches(1.1))
        tf = header_box.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0
        
        # Tag / Category
        p_tag = tf.paragraphs[0]
        p_tag.text = tag_text.upper()
        p_tag.font.name = "Segoe UI"
        p_tag.font.size = Pt(10)
        p_tag.font.bold = True
        p_tag.font.color.rgb = ACCENT_CYAN
        p_tag.space_after = Pt(4)

        # Title
        p_title = tf.add_paragraph()
        p_title.text = title_text
        p_title.font.name = "Segoe UI"
        p_title.font.size = Pt(22)
        p_title.font.bold = True
        p_title.font.color.rgb = TEXT_PRIMARY
        p_title.space_after = Pt(3)

        # Subtitle
        if subtitle_text:
            p_sub = tf.add_paragraph()
            p_sub.text = subtitle_text
            p_sub.font.name = "Segoe UI"
            p_sub.font.size = Pt(11)
            p_sub.font.color.rgb = TEXT_MUTED

    def add_card(slide, left, top, width, height, bg=CARD_BG, border=BORDER_COLOR):
        shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        shape.fill.solid()
        shape.fill.fore_color.rgb = bg
        shape.line.color.rgb = border
        shape.line.width = Pt(1)
        return shape

    def add_speaker_notes(slide, text):
        notes_slide = slide.notes_slide
        tf = notes_slide.notes_text_frame
        tf.text = text

    # ==========================================
    # SLIDE 1: TITLE & EVALUATION DOSSIER (COVER)
    # ==========================================
    slide1 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide1)

    # Top Capstone Pill Badge
    pill = slide1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(0.6), Inches(4.8), Inches(0.38))
    pill.fill.solid()
    pill.fill.fore_color.rgb = CARD_BG_ELEVATED
    pill.line.color.rgb = ACCENT_CYAN
    pill.line.width = Pt(1)
    tf_pill = pill.text_frame
    tf_pill.text = "⚡ FINAL YEAR B.TECH CAPSTONE PROJECT • 2026"
    p = tf_pill.paragraphs[0]
    p.font.name = "Segoe UI"
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = ACCENT_CYAN
    p.alignment = PP_ALIGN.CENTER

    # Main Project Title Box
    title_box = slide1.shapes.add_textbox(Inches(0.8), Inches(1.2), Inches(8.5), Inches(2.2))
    tf1 = title_box.text_frame
    tf1.word_wrap = True
    tf1.margin_left = tf1.margin_top = tf1.margin_right = tf1.margin_bottom = 0

    p_t1 = tf1.paragraphs[0]
    p_t1.text = "VERAXIS AI"
    p_t1.font.name = "Segoe UI"
    p_t1.font.size = Pt(46)
    p_t1.font.bold = True
    p_t1.font.color.rgb = TEXT_PRIMARY
    p_t1.space_after = Pt(6)

    p_sub1 = tf1.add_paragraph()
    p_sub1.text = "Autonomous Multi-Agent Scientific Research & Strategic Intelligence Platform"
    p_sub1.font.name = "Segoe UI"
    p_sub1.font.size = Pt(18)
    p_sub1.font.bold = True
    p_sub1.font.color.rgb = ACCENT_CYAN
    p_sub1.space_after = Pt(8)

    p_desc1 = tf1.add_paragraph()
    p_desc1.text = "Dual-Route Intent Routing • 3-Tier Zero-Hallucination Swarm • Two-Pass Publication Vector Dossiers"
    p_desc1.font.name = "Segoe UI"
    p_desc1.font.size = Pt(12)
    p_desc1.font.color.rgb = TEXT_MUTED

    # Logo Image on Right side
    logo_path = "assets/veraxis_symbol_dark.png"
    if os.path.exists(logo_path):
        slide1.shapes.add_picture(logo_path, Inches(9.8), Inches(1.1), width=Inches(2.7))

    # 4 Bottom Feature Metric Tiles
    tile_w = Inches(2.76)
    tile_h = Inches(1.6)
    tile_top = Inches(3.8)
    tiles_data = [
        ("₹0.00 BUDGET", "Zero Operational Cost", "41+ Groq Key pool round-robin rotation with auto-failover on rate limits.", ACCENT_GREEN),
        ("< 400ms LATENCY", "Dual-Route Intent", "Sub-100ms classifier routes simple queries to LPU chat, deep queries to swarm.", ACCENT_CYAN),
        ("3-TIER SWARM", "Forensic Verification", "Lead Analyst -> Adversarial Fact-Checker -> Executive Dossier Director.", ACCENT_AMBER),
        ("20/20 PASS", "Automated Test Suite", "Comprehensive backend, intent, tools, and PDF generation test gates passing.", ACCENT_GREEN),
    ]

    for i, (stat, title, desc, color) in enumerate(tiles_data):
        left_pos = Inches(0.8 + i * (2.76 + 0.23))
        card = add_card(slide1, left_pos, tile_top, tile_w, tile_h, CARD_BG, BORDER_COLOR)
        tf_card = card.text_frame
        tf_card.word_wrap = True
        tf_card.margin_left = Inches(0.18)
        tf_card.margin_right = Inches(0.18)
        tf_card.margin_top = Inches(0.15)
        
        p0 = tf_card.paragraphs[0]
        p0.text = stat
        p0.font.name = "Segoe UI"
        p0.font.size = Pt(14)
        p0.font.bold = True
        p0.font.color.rgb = color
        p0.space_after = Pt(3)

        p1 = tf_card.add_paragraph()
        p1.text = title
        p1.font.name = "Segoe UI"
        p1.font.size = Pt(11)
        p1.font.bold = True
        p1.font.color.rgb = TEXT_PRIMARY
        p1.space_after = Pt(4)

        p2 = tf_card.add_paragraph()
        p2.text = desc
        p2.font.name = "Segoe UI"
        p2.font.size = Pt(9)
        p2.font.color.rgb = TEXT_MUTED

    # Bottom Metadata Strip
    meta_bar = slide1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(5.8), Inches(11.733), Inches(1.1))
    meta_bar.fill.solid()
    meta_bar.fill.fore_color.rgb = CARD_BG_ELEVATED
    meta_bar.line.color.rgb = BORDER_HIGHLIGHT
    meta_bar.line.width = Pt(1)
    tf_mb = meta_bar.text_frame
    tf_mb.word_wrap = True
    tf_mb.margin_left = Inches(0.25)
    tf_mb.margin_top = Inches(0.18)

    p_m1 = tf_mb.paragraphs[0]
    p_m1.text = "EVALUATION DOSSIER & SYSTEM METADATA"
    p_m1.font.name = "Segoe UI"
    p_m1.font.size = Pt(9.5)
    p_m1.font.bold = True
    p_m1.font.color.rgb = ACCENT_CYAN
    p_m1.space_after = Pt(4)

    p_m2 = tf_mb.add_paragraph()
    p_m2.text = "Department: Computer Science & Engineering (CSE) / IT  |  Domain: Multi-Agent Systems & Scientific IR\nHost Architecture: FastAPI 0.110 + CrewAI 1.15 + Groq LPU + React 19 + WebGL 2 + ReportLab 4.x Vector PDF Engine"
    p_m2.font.name = "Segoe UI"
    p_m2.font.size = Pt(10)
    p_m2.font.color.rgb = TEXT_MUTED

    add_speaker_notes(slide1, 
        "Welcome Respected Evaluators and Committee Members. Today I present VERAXIS AI, our Major Capstone Project. "
        "VERAXIS is an enterprise-grade autonomous scientific intelligence platform engineered to eliminate LLM hallucinations "
        "and provide instant McKinsey/Gartner style literature dossiers at zero operational infrastructure cost."
    )

    # ==========================================
    # SLIDE 2: PROBLEM FORMULATION (CRISIS IN LITERATURE DISCOVERY)
    # ==========================================
    slide2 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide2)
    add_header(slide2, "01 | PROBLEM FORMULATION", "The Epistemic Crisis in Scientific Literature Discovery", 
               "Unchecked foundational LLMs fail catastrophically in academic, medical, and deep-tech research environments.")

    pillar_w = Inches(3.72)
    pillar_h = Inches(5.2)
    pillar_top = Inches(1.6)

    pillars = [
        ("23% – 38%", "CRITICAL FAILURE", "Epistemic Confabulation", ACCENT_ROSE, [
            "Hallucinated Identifiers: Foundational LLMs routinely invent syntactically plausible DOIs, author affiliations, and paper titles.",
            "Cross-Conflation: Numerical findings (e.g., battery energy density in Wh/kg, clinical efficacy) get merged across unrelated papers.",
            "Zero Traceability: Standard chats offer zero auditable evidence trails to back statistical claims."
        ]),
        ("30s – 60s", "LATENCY PARADOX", "Agentic Overkill Trap", ACCENT_AMBER, [
            "Heavy Frameworks: AutoGen and standard CrewAI fire complex multi-agent swarms even for trivial queries ('hi', 'what is DNA?').",
            "Severe Delay: Users suffer 30-60 second wait times on casual queries, destroying conversational ergonomics.",
            "Token Exhaustion: Wastes massive compute and exhausts API rate limits on non-research interactions."
        ]),
        ("$20 – $50/mo", "ECONOMIC BARRIER", "Commercial Paywall Moats", ACCENT_CYAN, [
            "High Recurring Costs: Platforms like Perplexity Pro, Elicit, and Consensus cost $240–$600/year per researcher.",
            "Inaccessible: Completely prohibitive for undergraduate students, independent scholars, and emerging labs.",
            "Proprietary Formats: Lack exportable, publication-grade vector documentation formatted for institutional review."
        ])
    ]

    for i, (stat, tag, title, color, points) in enumerate(pillars):
        left_pos = Inches(0.8 + i * (3.72 + 0.28))
        card = add_card(slide2, left_pos, pillar_top, pillar_w, pillar_h, CARD_BG, BORDER_COLOR)
        tf_c = card.text_frame
        tf_c.word_wrap = True
        tf_c.margin_left = Inches(0.25)
        tf_c.margin_right = Inches(0.25)
        tf_c.margin_top = Inches(0.25)

        # Tag
        p_tag = tf_c.paragraphs[0]
        p_tag.text = tag
        p_tag.font.name = "Segoe UI"
        p_tag.font.size = Pt(9)
        p_tag.font.bold = True
        p_tag.font.color.rgb = color
        p_tag.space_after = Pt(2)

        # Stat
        p_stat = tf_c.add_paragraph()
        p_stat.text = stat
        p_stat.font.name = "Segoe UI"
        p_stat.font.size = Pt(28)
        p_stat.font.bold = True
        p_stat.font.color.rgb = color
        p_stat.space_after = Pt(2)

        # Title
        p_t = tf_c.add_paragraph()
        p_t.text = title
        p_t.font.name = "Segoe UI"
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_PRIMARY
        p_t.space_after = Pt(12)

        # Divider line simulated by space
        for pt_text in points:
            p_pt = tf_c.add_paragraph()
            p_pt.text = "• " + pt_text
            p_pt.font.name = "Segoe UI"
            p_pt.font.size = Pt(10)
            p_pt.font.color.rgb = TEXT_MUTED
            p_pt.space_after = Pt(8)

    add_speaker_notes(slide2,
        "Here we define the core problem motivating VERAXIS. Three fatal breakdowns exist in modern AI research: "
        "First, hallucination rates up to 38% in specialized literature. "
        "Second, the latency-vs-depth dilemma where monolithic agent swarms waste 45 seconds on simple greetings. "
        "Third, commercial tools charge hundreds of dollars annually, blocking students and academic researchers."
    )

    # ==========================================
    # SLIDE 3: SYSTEM ARCHITECTURE & DUAL-ROUTE ROUTER
    # ==========================================
    slide3 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide3)
    add_header(slide3, "02 | SYSTEM ARCHITECTURE", "High-Throughput Dual-Engine Architecture", 
               "Sub-100ms intent dispatching segregates fast chat from autonomous 3-tier deep research swarms.")

    # Diagram Canvas Container
    canvas_card = add_card(slide3, Inches(0.8), Inches(1.6), Inches(11.733), Inches(4.3), CARD_BG, BORDER_COLOR)
    
    # 1. User Ingestion Node
    n_user = add_card(slide3, Inches(1.1), Inches(3.1), Inches(2.2), Inches(1.4), CARD_BG_ELEVATED, ACCENT_CYAN)
    tf_u = n_user.text_frame
    tf_u.word_wrap = True
    tf_u.margin_left = tf_u.margin_right = Inches(0.12)
    tf_u.margin_top = Inches(0.15)
    p = tf_u.paragraphs[0]
    p.text = "RESEARCH QUERY"
    p.font.name = "Segoe UI"
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = ACCENT_CYAN
    p.alignment = PP_ALIGN.CENTER
    p2 = tf_u.add_paragraph()
    p2.text = "React 19 Interface\nWebGL 2 Liquid Glass\nNatural Language Prompt"
    p2.font.name = "Segoe UI"
    p2.font.size = Pt(9)
    p2.font.color.rgb = TEXT_MUTED
    p2.alignment = PP_ALIGN.CENTER

    # Arrow 1 -> Router
    arrow1 = slide3.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(3.35), Inches(3.6), Inches(0.55), Inches(0.3))
    arrow1.fill.solid()
    arrow1.fill.fore_color.rgb = BORDER_HIGHLIGHT
    arrow1.line.fill.background()

    # 2. Router Node
    n_router = add_card(slide3, Inches(3.95), Inches(2.8), Inches(2.4), Inches(2.0), CARD_BG_ELEVATED, ACCENT_AMBER)
    tf_r = n_router.text_frame
    tf_r.word_wrap = True
    tf_r.margin_left = tf_r.margin_right = Inches(0.12)
    tf_r.margin_top = Inches(0.15)
    p = tf_r.paragraphs[0]
    p.text = "INTENT ROUTER"
    p.font.name = "Segoe UI"
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = ACCENT_AMBER
    p.alignment = PP_ALIGN.CENTER
    p2 = tf_r.add_paragraph()
    p2.text = "router.py Classifier\nLatency < 100ms\nHeuristic & Keyword Engine\nEvaluates Query Rigor"
    p2.font.name = "Segoe UI"
    p2.font.size = Pt(9)
    p2.font.color.rgb = TEXT_PRIMARY
    p2.alignment = PP_ALIGN.CENTER

    # Top Arrow -> Fast Chat
    arrow_up = slide3.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(6.4), Inches(2.5), Inches(0.65), Inches(0.28))
    arrow_up.fill.solid()
    arrow_up.fill.fore_color.rgb = ACCENT_CYAN
    arrow_up.line.fill.background()

    # Bottom Arrow -> Swarm
    arrow_down = slide3.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(6.4), Inches(4.3), Inches(0.65), Inches(0.28))
    arrow_down.fill.solid()
    arrow_down.fill.fore_color.rgb = ACCENT_GREEN
    arrow_down.line.fill.background()

    # 3A. Fast Chat Box (Top Route)
    n_fast = add_card(slide3, Inches(7.1), Inches(1.9), Inches(4.9), Inches(1.5), CARD_BG_ELEVATED, ACCENT_CYAN)
    tf_f = n_fast.text_frame
    tf_f.word_wrap = True
    tf_f.margin_left = tf_f.margin_right = Inches(0.18)
    tf_f.margin_top = Inches(0.12)
    p = tf_f.paragraphs[0]
    p.text = "ROUTE A: GENERAL_CHAT  (<400ms Ultra-Fast Stream)"
    p.font.name = "Segoe UI"
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = ACCENT_CYAN
    p2 = tf_f.add_paragraph()
    p2.text = "• Bypasses agent overhead completely for greetings and direct factual Q&A.\n• Groq LPU hardware acceleration with Llama-3.1-8B-Instant.\n• Delivers instant token streaming directly to UI chat thread."
    p2.font.name = "Segoe UI"
    p2.font.size = Pt(9)
    p2.font.color.rgb = TEXT_MUTED

    # 3B. Multi-Agent Swarm Box (Bottom Route)
    n_swarm = add_card(slide3, Inches(7.1), Inches(3.7), Inches(4.9), Inches(2.0), CARD_BG_ELEVATED, ACCENT_GREEN)
    tf_s = n_swarm.text_frame
    tf_s.word_wrap = True
    tf_s.margin_left = tf_s.margin_right = Inches(0.18)
    tf_s.margin_top = Inches(0.15)
    p = tf_s.paragraphs[0]
    p.text = "ROUTE B: DEEP_RESEARCH  (Autonomous 3-Tier Swarm)"
    p.font.name = "Segoe UI"
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = ACCENT_GREEN
    p2 = tf_s.add_paragraph()
    p2.text = "• Tier 1: Lead Analyst queries ArXiv, DuckDuckGo & Wikipedia preprints.\n• Tier 2: Forensic Fact-Checker calculates 0-100% confidence matrix.\n• Tier 3: Executive Dossier Director compiles structured synthesis.\n• Compiles 2-Pass Publication-Grade Vector PDF via ReportLab 4.x."
    p2.font.name = "Segoe UI"
    p2.font.size = Pt(9)
    p2.font.color.rgb = TEXT_PRIMARY

    # Bottom Callout Summary
    bot_callout = add_card(slide3, Inches(0.8), Inches(6.05), Inches(11.733), Inches(0.85), CARD_BG_ELEVATED, BORDER_HIGHLIGHT)
    tf_bc = bot_callout.text_frame
    tf_bc.word_wrap = True
    tf_bc.margin_left = Inches(0.2)
    tf_bc.margin_top = Inches(0.1)
    p = tf_bc.paragraphs[0]
    p.text = "CORE ARCHITECTURAL ADVANTAGE:"
    p.font.name = "Segoe UI"
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = ACCENT_CYAN
    p2 = tf_bc.add_paragraph()
    p2.text = "Solves the industry-wide Latency-vs-Depth paradox. Casual questions take 0.3s; deep scientific literature queries receive rigorous multi-source forensic scrutiny."
    p2.font.name = "Segoe UI"
    p2.font.size = Pt(10)
    p2.font.color.rgb = TEXT_MUTED

    add_speaker_notes(slide3,
        "This slide presents the core architectural flow of VERAXIS. "
        "Notice the dual-route dispatcher: In under 100 milliseconds, it classifies whether a query requires full academic investigation or fast conversational response. "
        "General questions stream back in under 400 milliseconds via Groq LPUs. "
        "Research questions trigger our autonomous 3-tier CrewAI swarm, producing both an interactive UI stream and a downloadable publication PDF."
    )

    # ==========================================
    # SLIDE 4: 3-TIER MULTI-AGENT SWARM
    # ==========================================
    slide4 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide4)
    add_header(slide4, "03 | AGENTIC ORCHESTRATION", "Role-Segregated 3-Tier Multi-Agent Swarm", 
               "Strict division of labor enforces adversarial verification and eliminates single-agent confirmation bias.")

    agent_w = Inches(3.72)
    agent_h = Inches(5.2)
    agent_top = Inches(1.6)

    agents = [
        ("TIER 1 • DISCOVERY", "Lead Scientific Research Analyst", ACCENT_CYAN, [
            ("Core Mandate", "Exhaustive literature gathering across academic preprints & live web indexes."),
            ("Integrated Tools", "ArXiv API (preprints), DuckDuckGo Search (live developments), Wikipedia REST API (foundational ontologies)."),
            ("Operating Logic", "Executes multi-term parametric queries, filters non-academic noise, extracts raw empirical abstracts and author data."),
            ("Primary Output", "Unfiltered empirical corpus with verbatim source citations & metadata.")
        ]),
        ("TIER 2 • AUDITING", "Forensic Truth Auditor", ACCENT_GREEN, [
            ("Core Mandate", "Adversarial cross-examination of every factual claim against retrieved evidence."),
            ("Verification Engine", "Calculates a mathematical 0–100% Verification Confidence Matrix."),
            ("Classification Rules", "Tags claims as VERIFIED (corroborated), CONTESTED (conflicting findings), or UNVERIFIED (excised)."),
            ("Primary Output", "Audited assertion registry with 0% ungrounded citations guarantee.")
        ]),
        ("TIER 3 • SYNTHESIS", "Executive Dossier Director", ACCENT_AMBER, [
            ("Core Mandate", "Synthesizes audited facts into executive-ready strategic research dossiers."),
            ("Styling Standards", "Follows McKinsey & Gartner executive publication structures."),
            ("Artifact Compilation", "Generates quantitative KPI badges, thematic sections, and hyperlinked references."),
            ("Primary Output", "Structured Markdown payload feeding the ReportLab 4.x Vector PDF engine.")
        ])
    ]

    for i, (badge, title, color, sections) in enumerate(agents):
        left_pos = Inches(0.8 + i * (3.72 + 0.28))
        card = add_card(slide4, left_pos, agent_top, agent_w, agent_h, CARD_BG, BORDER_COLOR)
        tf_a = card.text_frame
        tf_a.word_wrap = True
        tf_a.margin_left = Inches(0.22)
        tf_a.margin_right = Inches(0.22)
        tf_a.margin_top = Inches(0.2)

        # Badge
        p_b = tf_a.paragraphs[0]
        p_b.text = badge
        p_b.font.name = "Segoe UI"
        p_b.font.size = Pt(9)
        p_b.font.bold = True
        p_b.font.color.rgb = color
        p_b.space_after = Pt(3)

        # Title
        p_t = tf_a.add_paragraph()
        p_t.text = title
        p_t.font.name = "Segoe UI"
        p_t.font.size = Pt(13.5)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_PRIMARY
        p_t.space_after = Pt(10)

        for sec_title, sec_desc in sections:
            p_st = tf_a.add_paragraph()
            p_st.text = sec_title.upper()
            p_st.font.name = "Segoe UI"
            p_st.font.size = Pt(8.5)
            p_st.font.bold = True
            p_st.font.color.rgb = color

            p_sd = tf_a.add_paragraph()
            p_sd.text = sec_desc
            p_sd.font.name = "Segoe UI"
            p_sd.font.size = Pt(9.5)
            p_sd.font.color.rgb = TEXT_MUTED
            p_sd.space_after = Pt(7)

    add_speaker_notes(slide4,
        "Here is the breakdown of our 3-tier CrewAI swarm. "
        "Single LLM agents suffer from confirmation bias—they believe their own hallucinations. "
        "VERAXIS solves this with an adversarial relationship: Agent 1 gathers literature, but Agent 2 acts as a strict auditor. "
        "Agent 2 scores every claim on a 0 to 100% confidence scale and excises unverified points. "
        "Only verified facts reach Agent 3, who structures the final publication dossier."
    )

    # ==========================================
    # SLIDE 5: KEY TECHNICAL INNOVATIONS
    # ==========================================
    slide5 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide5)
    add_header(slide5, "04 | TECHNICAL INNOVATIONS", "Zero-Cost Resilience & Vector PDF Engine", 
               "Engineering solutions built to overcome free-tier cloud limits and compile publication-grade documents.")

    inno_w = Inches(3.72)
    inno_h = Inches(5.2)
    inno_top = Inches(1.6)

    innovations = [
        ("RESILIENCE ENGINE", "KeyManager 41-Key Pool Failover", ACCENT_CYAN, [
            "Zero Cloud Budget: Eliminates API billing by managing an automated pool of 41+ Groq API keys.",
            "Round-Robin Rotation: Distributes incoming prompt load sequentially to stay within free-tier RPM and TPM limits.",
            "Exponential Backoff: Intercepts HTTP 429 (Rate Limit Exceeded) errors silently, rotates to the next available healthy key, and completes tasks without user interruption."
        ]),
        ("VECTOR COMPILER", "Two-Pass ReportLab 4.x Engine", ACCENT_GREEN, [
            "Two-Pass Pagination: Custom NumberedCanvas callback counts total pages in Pass 1, then stamps dynamic 'Page X of Y' headers in Pass 2.",
            "McKinsey / Gartner Layout: Formats executive summary, KPI matrix cards, methodology tables, and hyperlinked bibliography.",
            "Sub-2.5s Generation: Compiles sharp, high-DPI vector PDFs ready for academic submission and institutional sharing."
        ]),
        ("OPTICAL PHYSICS", "WebGL 2 Liquid Glass Shader", ACCENT_AMBER, [
            "Super-Oval Geometry: Custom GLSL fragment shader rendering continuous super-oval curves (p = 2.5) with zero hard box corners.",
            "Snell's Law Refraction: Realistic index of refraction (n = 1.52) with mouse-driven rainbow chromatic dispersion.",
            "Locked 60 FPS: Pure GPU-accelerated canvas background with zero DOM layout recalculation or scroll jank."
        ])
    ]

    for i, (badge, title, color, points) in enumerate(innovations):
        left_pos = Inches(0.8 + i * (3.72 + 0.28))
        card = add_card(slide5, left_pos, inno_top, inno_w, inno_h, CARD_BG, BORDER_COLOR)
        tf_i = card.text_frame
        tf_i.word_wrap = True
        tf_i.margin_left = Inches(0.22)
        tf_i.margin_right = Inches(0.22)
        tf_i.margin_top = Inches(0.22)

        # Badge
        p_b = tf_i.paragraphs[0]
        p_b.text = badge
        p_b.font.name = "Segoe UI"
        p_b.font.size = Pt(9)
        p_b.font.bold = True
        p_b.font.color.rgb = color
        p_b.space_after = Pt(3)

        # Title
        p_t = tf_i.add_paragraph()
        p_t.text = title
        p_t.font.name = "Segoe UI"
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_PRIMARY
        p_t.space_after = Pt(12)

        for pt in points:
            title_part, desc_part = pt.split(":", 1)
            p_pt1 = tf_i.add_paragraph()
            p_pt1.text = "• " + title_part.strip() + ":"
            p_pt1.font.name = "Segoe UI"
            p_pt1.font.size = Pt(10)
            p_pt1.font.bold = True
            p_pt1.font.color.rgb = color
            
            p_pt2 = tf_i.add_paragraph()
            p_pt2.text = desc_part.strip()
            p_pt2.font.name = "Segoe UI"
            p_pt2.font.size = Pt(9.5)
            p_pt2.font.color.rgb = TEXT_MUTED
            p_pt2.space_after = Pt(8)

    add_speaker_notes(slide5,
        "Slide 5 highlights our major engineering innovations. "
        "First, our KeyManager: To achieve a zero-rupee operational budget, we implemented an automated round-robin rotation across 41 free-tier Groq API keys with seamless failover on HTTP 429 errors. "
        "Second, our two-pass vector PDF engine: Standard web print-to-pdf produces messy page breaks. We built a custom ReportLab 4.x compiler that generates pristine vector dossiers. "
        "Third, our WebGL 2 Liquid Glass shader renders optical refraction and physics at 60 FPS."
    )

    # ==========================================
    # SLIDE 6: ALGORITHMIC FOUNDATIONS & MATH
    # ==========================================
    slide6 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide6)
    add_header(slide6, "05 | MATHEMATICAL FOUNDATIONS", "Algorithmic Models for Intent & Verification", 
               "Deterministic mathematical formulations underpinning sub-100ms routing and forensic verification.")

    card_left = add_card(slide6, Inches(0.8), Inches(1.6), Inches(5.7), Inches(5.2), CARD_BG, BORDER_COLOR)
    tf_l = card_left.text_frame
    tf_l.word_wrap = True
    tf_l.margin_left = tf_l.margin_right = Inches(0.25)
    tf_l.margin_top = Inches(0.2)

    p = tf_l.paragraphs[0]
    p.text = "ALGORITHM 1: DUAL-ROUTE DISPATCH DISCRIMINATOR"
    p.font.name = "Segoe UI"
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = ACCENT_AMBER
    p.space_after = Pt(6)

    p_math1 = tf_l.add_paragraph()
    p_math1.text = "Let Q be the input user prompt. We extract heuristic feature vector F(Q) = ⟨L(Q), K(Q), S(Q)⟩ where L is token count, K is scientific keyword density, and S is structural inquiry flag."
    p_math1.font.name = "Segoe UI"
    p_math1.font.size = Pt(9.5)
    p_math1.font.color.rgb = TEXT_MUTED
    p_math1.space_after = Pt(6)

    p_eq1 = tf_l.add_paragraph()
    p_eq1.text = "Route(Q) = DEEP_RESEARCH  if  Score(F(Q)) ≥ τ  ∨  ExplicitMode == True\nRoute(Q) = GENERAL_CHAT   otherwise   (τ = 0.72)"
    p_eq1.font.name = "Consolas"
    p_eq1.font.size = Pt(10)
    p_eq1.font.bold = True
    p_eq1.font.color.rgb = ACCENT_CYAN
    p_eq1.space_after = Pt(10)

    p_desc1 = tf_l.add_paragraph()
    p_desc1.text = "Operational Invariants:\n• Classification latency: < 100ms (O(1) lexical scan before inference).\n• Zero agent overhead for conversational banter (latency < 400ms).\n• Full CrewAI swarm allocated exclusively when analytical depth is needed."
    p_desc1.font.name = "Segoe UI"
    p_desc1.font.size = Pt(9.5)
    p_desc1.font.color.rgb = TEXT_MUTED

    card_right = add_card(slide6, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.2), CARD_BG, BORDER_COLOR)
    tf_r = card_right.text_frame
    tf_r.word_wrap = True
    tf_r.margin_left = tf_r.margin_right = Inches(0.25)
    tf_r.margin_top = Inches(0.2)

    p = tf_r.paragraphs[0]
    p.text = "ALGORITHM 2: FORENSIC CONFIDENCE MATRIX"
    p.font.name = "Segoe UI"
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = ACCENT_GREEN
    p.space_after = Pt(6)

    p_math2 = tf_r.add_paragraph()
    p_math2.text = "For every empirical claim c_i in corpus C and retrieved academic evidence documents D, the verification score S(c_i) is evaluated as:"
    p_math2.font.name = "Segoe UI"
    p_math2.font.size = Pt(9.5)
    p_math2.font.color.rgb = TEXT_MUTED
    p_math2.space_after = Pt(6)

    p_eq2 = tf_r.add_paragraph()
    p_eq2.text = "S(c_i) = α · Corroborate(c_i, D) + β · SourceWeight(S) - γ · Conflict(D)\nComposite Confidence = (1 / |C|) · ∑ S(c_i) × 100%"
    p_eq2.font.name = "Consolas"
    p_eq2.font.size = Pt(10)
    p_eq2.font.bold = True
    p_eq2.font.color.rgb = ACCENT_GREEN
    p_eq2.space_after = Pt(10)

    p_desc2 = tf_r.add_paragraph()
    p_desc2.text = "Auditing Threshold Rules:\n• Score ≥ 0.85: VERIFIED — cited in primary peer-reviewed literature.\n• 0.50 ≤ Score < 0.85: CONTESTED — conflicting evidence noted in dossier.\n• Score < 0.50: UNVERIFIED — excised completely to guarantee 0% hallucination."
    p_desc2.font.name = "Segoe UI"
    p_desc2.font.size = Pt(9.5)
    p_desc2.font.color.rgb = TEXT_MUTED

    add_speaker_notes(slide6,
        "On this slide we demonstrate academic and algorithmic depth. "
        "We formalized two deterministic algorithms: "
        "Algorithm 1 evaluates incoming prompts in under 100 milliseconds to decide whether to spin up agents or stream fast chat. "
        "Algorithm 2 models our Forensic Truth Auditor. It scores each assertion using weighted corroboration and source reliability metrics. "
        "Claims scoring below 0.50 are excised automatically, ensuring zero ungrounded assertions."
    )

    # ==========================================
    # SLIDE 7: COMPLETE TECHNOLOGY STACK
    # ==========================================
    slide7 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide7)
    add_header(slide7, "06 | TECHNOLOGY STACK", "Enterprise-Grade Full-Stack Architecture", 
               "Cohesive, modern software stack engineered for performance, modularity, and zero proprietary licensing.")

    stack_w = Inches(2.76)
    stack_h = Inches(5.2)
    stack_top = Inches(1.6)

    layers = [
        ("LAYER 1", "Frontend & UI", ACCENT_CYAN, [
            ("React 19", "Concurrent rendering & modern hooks"),
            ("Tailwind CSS v4", "CSS variable semantic tokens"),
            ("WebGL 2 / GLSL", "Custom liquid glass optical shaders"),
            ("Vite 6", "Sub-second HMR & modern bundling"),
            ("PWA Architecture", "Service-worker & offline resilience")
        ]),
        ("LAYER 2", "Backend & API", ACCENT_GREEN, [
            ("Python 3.11/3.12", "Modern asynchronous execution"),
            ("FastAPI 0.110", "High-throughput ASGI routes"),
            ("CrewAI 1.15", "Role-segregated agent coordination"),
            ("Uvicorn Server", "Lightning-fast ASGI event loop"),
            ("Pydantic v2", "Strict runtime schema validation")
        ]),
        ("LAYER 3", "AI & Inference", ACCENT_AMBER, [
            ("Groq LPU", "Ultra-low-latency hardware inference"),
            ("Llama-3.3-70B", "Deep synthesis & auditing model"),
            ("Llama-3.1-8B", "Sub-400ms general chat model"),
            ("KeyManager", "41-key round-robin failover pool"),
            ("Demo Cache", "Offline failsafe evaluation cache")
        ]),
        ("LAYER 4", "Retrieval & Build", ACCENT_CYAN, [
            ("ArXiv REST API", "Peer-reviewed preprint discovery"),
            ("DuckDuckGo", "Live web & breaking technical news"),
            ("Wikipedia REST", "Ontology & domain taxonomy"),
            ("ReportLab 4.x", "Two-pass publication PDF compiler"),
            ("Pytest & PyMuPDF", "Automated validation & testing")
        ])
    ]

    for i, (badge, title, color, tech_list) in enumerate(layers):
        left_pos = Inches(0.8 + i * (2.76 + 0.23))
        card = add_card(slide7, left_pos, stack_top, stack_w, stack_h, CARD_BG, BORDER_COLOR)
        tf_s = card.text_frame
        tf_s.word_wrap = True
        tf_s.margin_left = tf_s.margin_right = Inches(0.18)
        tf_s.margin_top = Inches(0.2)

        # Badge
        p_b = tf_s.paragraphs[0]
        p_b.text = badge
        p_b.font.name = "Segoe UI"
        p_b.font.size = Pt(9)
        p_b.font.bold = True
        p_b.font.color.rgb = color
        p_b.space_after = Pt(2)

        # Title
        p_t = tf_s.add_paragraph()
        p_t.text = title
        p_t.font.name = "Segoe UI"
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_PRIMARY
        p_t.space_after = Pt(10)

        for name, desc in tech_list:
            p_n = tf_s.add_paragraph()
            p_n.text = name
            p_n.font.name = "Segoe UI"
            p_n.font.size = Pt(10)
            p_n.font.bold = True
            p_n.font.color.rgb = color

            p_d = tf_s.add_paragraph()
            p_d.text = desc
            p_d.font.name = "Segoe UI"
            p_d.font.size = Pt(8.8)
            p_d.font.color.rgb = TEXT_MUTED
            p_d.space_after = Pt(6)

    add_speaker_notes(slide7,
        "Here is our complete software stack. Every component was selected with zero compromise on performance or cost. "
        "Frontend utilizes React 19 and raw WebGL 2 shaders for 60 FPS graphics. "
        "Backend uses FastAPI 0.110 with CrewAI 1.15. "
        "Inference is powered by Groq LPUs running Llama-3.3-70B for research and 8B-Instant for quick chat. "
        "Document compilation is handled by ReportLab 4.x."
    )

    # ==========================================
    # SLIDE 8: EMPIRICAL BENCHMARKING & LIVE EVIDENCE
    # ==========================================
    slide8 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide8)
    add_header(slide8, "07 | BENCHMARKING & EVIDENCE", "Empirical Validation & Live Platform Artifacts", 
               "Rigorous verification through automated test suites, sub-second latency benchmarks, and publication dossiers.")

    # Left: UI Screenshot
    ui_shot_path = "scratch/shot_full_decluttered.png"
    if os.path.exists(ui_shot_path):
        card_img1 = add_card(slide8, Inches(0.8), Inches(1.6), Inches(4.2), Inches(3.8), CARD_BG, BORDER_COLOR)
        slide8.shapes.add_picture(ui_shot_path, Inches(0.9), Inches(1.7), width=Inches(4.0))
        tb1 = slide8.shapes.add_textbox(Inches(0.8), Inches(5.5), Inches(4.2), Inches(0.8))
        tf_tb1 = tb1.text_frame
        tf_tb1.word_wrap = True
        p = tf_tb1.paragraphs[0]
        p.text = "LIVE PLATFORM WEBGL 2 INTERFACE"
        p.font.name = "Segoe UI"
        p.font.size = Pt(9)
        p.font.bold = True
        p.font.color.rgb = ACCENT_CYAN
        p2 = tf_tb1.add_paragraph()
        p2.text = "Dark-mode interface with super-oval liquid lens and real-time research query composer."
        p2.font.name = "Segoe UI"
        p2.font.size = Pt(8.5)
        p2.font.color.rgb = TEXT_MUTED

    # Middle: Rendered PDF Page
    pdf_shot_path = "scratch/sample_pdf_page1.png"
    if os.path.exists(pdf_shot_path):
        card_img2 = add_card(slide8, Inches(5.2), Inches(1.6), Inches(3.1), Inches(4.7), CARD_BG, BORDER_COLOR)
        slide8.shapes.add_picture(pdf_shot_path, Inches(5.3), Inches(1.7), width=Inches(2.9))
        tb2 = slide8.shapes.add_textbox(Inches(5.2), Inches(6.4), Inches(3.1), Inches(0.7))
        tf_tb2 = tb2.text_frame
        tf_tb2.word_wrap = True
        p = tf_tb2.paragraphs[0]
        p.text = "PUBLICATION-GRADE PDF DOSSIER"
        p.font.name = "Segoe UI"
        p.font.size = Pt(8.5)
        p.font.bold = True
        p.font.color.rgb = ACCENT_GREEN

    # Right: 4 Benchmark Metric Cards
    metrics_data = [
        ("20 / 20", "100% Test Suite Green", "All automated unit & integration test cases pass in test.py.", ACCENT_GREEN),
        ("< 400 ms", "Fast Chat Streaming", "Sub-second conversational response time on Groq LPUs.", ACCENT_CYAN),
        ("0%", "Ungrounded Citations", "Zero hallucinated references across benchmark queries.", ACCENT_GREEN),
        ("₹0.00", "Zero Infrastructure Cost", "Achieved full SaaS resilience on free-tier key pooling.", ACCENT_AMBER)
    ]

    metric_top_start = Inches(1.6)
    metric_h = Inches(1.18)
    for i, (m_val, m_title, m_desc, m_color) in enumerate(metrics_data):
        top_pos = metric_top_start + i * (metric_h + Inches(0.12))
        m_card = add_card(slide8, Inches(8.5), top_pos, Inches(4.033), metric_h, CARD_BG, BORDER_COLOR)
        tf_m = m_card.text_frame
        tf_m.word_wrap = True
        tf_m.margin_left = Inches(0.18)
        tf_m.margin_top = Inches(0.12)

        p0 = tf_m.paragraphs[0]
        p0.text = m_val
        p0.font.name = "Segoe UI"
        p0.font.size = Pt(16)
        p0.font.bold = True
        p0.font.color.rgb = m_color
        p0.space_after = Pt(2)

        p1 = tf_m.add_paragraph()
        p1.text = m_title
        p1.font.name = "Segoe UI"
        p1.font.size = Pt(10)
        p1.font.bold = True
        p1.font.color.rgb = TEXT_PRIMARY

        p2 = tf_m.add_paragraph()
        p2.text = m_desc
        p2.font.name = "Segoe UI"
        p2.font.size = Pt(8.5)
        p2.font.color.rgb = TEXT_MUTED

    add_speaker_notes(slide8,
        "Slide 8 presents empirical verification. "
        "On the left, you see our live React 19 interface running with WebGL 2 liquid glass shaders. "
        "In the center is a real publication dossier compiled by our two-pass ReportLab engine. "
        "On the right are our benchmark metrics: 20 out of 20 automated test cases passing with 100% success rate, sub-400ms chat latency, 0% ungrounded citations, and zero operational infrastructure cost."
    )

    # ==========================================
    # SLIDE 9: CONCLUSION & FUTURE ROADMAP
    # ==========================================
    slide9 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide9)
    add_header(slide9, "08 | CONCLUSION & ROADMAP", "Impact, Extensibility & Future Directions", 
               "Transforming scientific discovery through accessible, zero-hallucination agentic intelligence.")

    col_w = Inches(3.72)
    col_h = Inches(5.2)
    col_top = Inches(1.6)

    final_columns = [
        ("PROJECT IMPACT", "Societal & Academic Impact", ACCENT_CYAN, [
            ("Democratization of Intelligence", "Provides university students and independent researchers with enterprise-grade research capabilities at zero cost."),
            ("Epistemic Trustworthiness", "Solves the scientific reproducibility crisis by enforcing auditable evidence trails for every claim."),
            ("Dual-Paradigm Ergonomics", "Bridges the gap between casual conversational Q&A and rigorous academic publication dossiers.")
        ]),
        ("ROADMAP", "Future Research Extensions", ACCENT_AMBER, [
            ("Multi-Modal ArXiv Parser", "Direct OCR and tabular extraction of charts, phase diagrams, and chemical equations from PDF preprints."),
            ("Graph RAG Traversal", "Constructing dynamic citation knowledge graphs to track ideological lineages across scientific papers."),
            ("Air-Gapped Deployment", "Integration with Ollama and vLLM for high-security, classified research lab installations.")
        ]),
        ("DEFENSE SUMMARY", "Capstone Project Summary", ACCENT_GREEN, [
            ("Production-Grade Execution", "Complete working full-stack implementation with 100% green automated test suites."),
            ("Architectural Rigor", "Novel dual-route intent classifier eliminates latency bottlenecks while preserving deep reasoning."),
            ("Thank You", "Open for Questions, Evaluation Review & Live Demonstration.")
        ])
    ]

    for i, (badge, title, color, sections) in enumerate(final_columns):
        left_pos = Inches(0.8 + i * (3.72 + 0.28))
        card = add_card(slide9, left_pos, col_top, col_w, col_h, CARD_BG, BORDER_COLOR)
        tf_c = card.text_frame
        tf_c.word_wrap = True
        tf_c.margin_left = Inches(0.22)
        tf_c.margin_right = Inches(0.22)
        tf_c.margin_top = Inches(0.22)

        # Badge
        p_b = tf_c.paragraphs[0]
        p_b.text = badge
        p_b.font.name = "Segoe UI"
        p_b.font.size = Pt(9)
        p_b.font.bold = True
        p_b.font.color.rgb = color
        p_b.space_after = Pt(3)

        # Title
        p_t = tf_c.add_paragraph()
        p_t.text = title
        p_t.font.name = "Segoe UI"
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_PRIMARY
        p_t.space_after = Pt(12)

        for sec_t, sec_d in sections:
            p_st = tf_c.add_paragraph()
            p_st.text = sec_t
            p_st.font.name = "Segoe UI"
            p_st.font.size = Pt(9.5)
            p_st.font.bold = True
            p_st.font.color.rgb = color

            p_sd = tf_c.add_paragraph()
            p_sd.text = sec_d
            p_sd.font.name = "Segoe UI"
            p_sd.font.size = Pt(9)
            p_sd.font.color.rgb = TEXT_MUTED
            p_sd.space_after = Pt(8)

    add_speaker_notes(slide9,
        "In conclusion, VERAXIS AI demonstrates how role-segregated multi-agent swarms can eliminate hallucination in deep-tech research at zero infrastructure cost. "
        "Our dual-route architecture provides the speed of casual chat with the depth of a research institution. "
        "Thank you to the committee for your time. I am now open for questions and ready for the live demonstration."
    )

    output_path = "docs/VERAXIS_AI_Major_Project_Presentation.pptx"
    os.makedirs("docs", exist_ok=True)
    prs.save(output_path)
    print(f"Presentation successfully created at: {output_path}")

if __name__ == "__main__":
    create_deck()
