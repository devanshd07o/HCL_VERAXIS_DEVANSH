import asyncio
from playwright.async_api import async_playwright

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={"width": 1440, "height": 900},
            permissions=["clipboard-read", "clipboard-write"]
        )
        page = await context.new_page()

        print("Navigating to http://localhost:8000 ...")
        await page.goto("http://localhost:8000", wait_until="networkidle")

        composer = page.locator("textarea[placeholder*='Ask anything']").first
        await composer.fill("Explain graphene in simple words with its top uses")

        ask_btn = page.locator("button:has-text('Ask')").last
        await ask_btn.click()
        print("Clicked Ask...")

        # Wait for bot response to finish streaming
        await page.wait_for_selector("[data-slot='message'][data-align='start']", timeout=20000)
        # Give it a couple seconds to complete streaming
        await asyncio.sleep(4)

        # Capture dark mode chat
        await page.screenshot(path="scratch/shot_report_dark.png")
        print("📸 Captured shot_report_dark.png")

        # Toggle to light mode
        theme_toggle = page.locator("button[aria-label='Toggle light and dark appearance']").first
        if await theme_toggle.is_visible():
            await theme_toggle.click()
            await asyncio.sleep(1)
            await page.screenshot(path="scratch/shot_report_light.png")
            print("📸 Captured shot_report_light.png")

        await browser.close()
        print("Done!")

asyncio.run(run())
