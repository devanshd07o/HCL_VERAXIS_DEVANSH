import os
import sys
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

def create_bright_deck():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]

    # Color Palette Tokens (Bright Executive & Academic Editorial Theme)
    BG_CANVAS = RGBColor(248, 250, 252)        # Crisp Off-White Porcelain (#F8FAFC)
    SURFACE_WHITE = RGBColor(255, 255, 255)    # Pure White Card (#FFFFFF)
    SURFACE_TINT = RGBColor(241, 245, 249)     # Soft Slate Tint (#F1F5F9)
    SURFACE_ACCENT_LIGHT = RGBColor(238, 242, 255) # Light Indigo Tint (#EEF2FF)
    
    BORDER_LIGHT = RGBColor(226, 232, 240)     # Subtle 1px Border (#E2E8F0)
    BORDER_STRONG = RGBColor(203, 213, 225)    # Defined Border (#CBD5E1)
    
    TEXT_NAVY = RGBColor(15, 23, 42)           # Deep Rich Charcoal Navy (#0F172A)
    TEXT_SECONDARY = RGBColor(71, 85, 105)     # Slate Secondary (#475569)
    TEXT_MUTED = RGBColor(148, 163, 184)       # Cool Slate Dim (#94A3B8)
    
    PRIMARY_BLUE = RGBColor(29, 78, 216)       # Royal Blue Accent (#1D4ED8)
    ACCENT_TEAL = RGBColor(13, 148, 136)       # Deep Emerald Teal (#0D9488)
    ACCENT_AMBER = RGBColor(217, 119, 6)       # Rich Warm Ochre (#D97706)
    ACCENT_ROSE = RGBColor(190, 24, 93)        # Deep Rose / Burgundy (#BE185D)

    FONT_EDITORIAL = "Georgia"
    FONT_BODY = "Calibri"
    FONT_CODE = "Consolas"

    def set_slide_background(slide):
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
        bg.fill.solid()
        bg.fill.fore_color.rgb = BG_CANVAS
        bg.line.fill.background()
        return bg

    def add_editorial_header(slide, tag_text, title_text, subtitle_text=""):
        # Header Box with clean divider line
        header_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.733), Inches(1.15))
        tf = header_box.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0
        
        # Tag / Kicker
        p_tag = tf.paragraphs[0]
        p_tag.text = tag_text.upper()
        p_tag.font.name = FONT_BODY
        p_tag.font.size = Pt(9.5)
        p_tag.font.bold = True
        p_tag.font.color.rgb = PRIMARY_BLUE
        p_tag.space_after = Pt(2)

        # Main Title (Georgia Editorial)
        p_title = tf.add_paragraph()
        p_title.text = title_text
        p_title.font.name = FONT_EDITORIAL
        p_title.font.size = Pt(22)
        p_title.font.bold = True
        p_title.font.color.rgb = TEXT_NAVY
        p_title.space_after = Pt(3)

        # Subtitle
        if subtitle_text:
            p_sub = tf.add_paragraph()
            p_sub.text = subtitle_text
            p_sub.font.name = FONT_BODY
            p_sub.font.size = Pt(11)
            p_sub.font.color.rgb = TEXT_SECONDARY

        # Subtle 1px bottom divider line below header
        line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.5), Inches(11.733), Inches(0.015))
        line.fill.solid()
        line.fill.fore_color.rgb = BORDER_LIGHT
        line.line.fill.background()

    def add_clean_card(slide, left, top, width, height, bg=SURFACE_WHITE, border=BORDER_LIGHT):
        shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        shape.fill.solid()
        shape.fill.fore_color.rgb = bg
        shape.line.color.rgb = border
        shape.line.width = Pt(1)
        return shape

    def add_speaker_notes(slide, text):
        notes_slide = slide.notes_slide
        tf = notes_slide.notes_text_frame
        tf.text = text

    # ==========================================
    # SLIDE 1: COVER / EDITORIAL RESEARCH DOSSIER
    # ==========================================
    slide1 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide1)

    # Left Section: Editorial Typography & Project Context
    left_card = add_clean_card(slide1, Inches(0.8), Inches(0.8), Inches(7.6), Inches(5.9), SURFACE_WHITE, BORDER_LIGHT)
    tf_l = left_card.text_frame
    tf_l.word_wrap = True
    tf_l.margin_left = Inches(0.4)
    tf_l.margin_right = Inches(0.4)
    tf_l.margin_top = Inches(0.4)

    # Top Capstone Tag
    p_kicker = tf_l.paragraphs[0]
    p_kicker.text = "FINAL YEAR B.TECH CAPSTONE DISSERTATION • 2026"
    p_kicker.font.name = FONT_BODY
    p_kicker.font.size = Pt(10)
    p_kicker.font.bold = True
    p_kicker.font.color.rgb = PRIMARY_BLUE
    p_kicker.space_after = Pt(8)

    # Hero Title in Georgia
    p_hero = tf_l.add_paragraph()
    p_hero.text = "VERAXIS AI"
    p_hero.font.name = FONT_EDITORIAL
    p_hero.font.size = Pt(44)
    p_hero.font.bold = True
    p_hero.font.color.rgb = TEXT_NAVY
    p_hero.space_after = Pt(6)

    # Subtitle
    p_sub = tf_l.add_paragraph()
    p_sub.text = "Autonomous Multi-Agent Scientific Research & Forensic Verification Platform"
    p_sub.font.name = FONT_BODY
    p_sub.font.size = Pt(16)
    p_sub.font.bold = True
    p_sub.font.color.rgb = PRIMARY_BLUE
    p_sub.space_after = Pt(12)

    # Description
    p_desc = tf_l.add_paragraph()
    p_desc.text = (
        "An enterprise-grade scientific intelligence engine formulated to eliminate hallucination in deep-tech "
        "literature reviews. Integrates dual-route intent classification, adversarial 3-tier multi-agent fact auditing, "
        "and automated compilation of publication-grade McKinsey/Gartner vector PDF dossiers at ₹0 operational cost."
    )
    p_desc.font.name = FONT_BODY
    p_desc.font.size = Pt(11)
    p_desc.font.color.rgb = TEXT_SECONDARY
    p_desc.space_after = Pt(20)

    # Metadata Strip inside card
    p_meta1 = tf_l.add_paragraph()
    p_meta1.text = "ACADEMIC & EVALUATION METADATA"
    p_meta1.font.name = FONT_BODY
    p_meta1.font.size = Pt(9)
    p_meta1.font.bold = True
    p_meta1.font.color.rgb = TEXT_MUTED
    p_meta1.space_after = Pt(3)

    p_meta2 = tf_l.add_paragraph()
    p_meta2.text = (
        "Department: Computer Science & Engineering (CSE) / IT  •  Host Repo: MULTIINTELIGENCE\n"
        "Evaluated by: HCL Major Capstone Project Committee 2026  •  Test Suite: 20/20 Passed (100%)"
    )
    p_meta2.font.name = FONT_BODY
    p_meta2.font.size = Pt(9.5)
    p_meta2.font.color.rgb = TEXT_SECONDARY

    # Right Section: Brand & 3 High-Impact Key Deliverable Tiles
    right_card = add_clean_card(slide1, Inches(8.7), Inches(0.8), Inches(3.833), Inches(5.9), SURFACE_TINT, BORDER_LIGHT)
    
    # Brand Logo Image
    logo_path = "assets/veraxis_symbol_light.png"
    if os.path.exists(logo_path):
        slide1.shapes.add_picture(logo_path, Inches(9.8), Inches(1.15), width=Inches(1.6))

    # 3 Pill Stat Highlights in right pane
    tiles = [
        ("₹0.00 BUDGET", "Zero Infrastructure Cost", "Round-robin 41-key rotation on Groq LPUs with auto-failover."),
        ("< 400ms LATENCY", "Dual-Route Intent Dispatch", "Sub-100ms classifier separates casual chat from research swarms."),
        ("0% HALLUCINATION", "Adversarial Forensic Audit", "Mathematical 0–100% confidence matrix verifies primary sources.")
    ]

    for i, (stat, title, desc) in enumerate(tiles):
        top_pos = Inches(2.9 + i * 1.25)
        tile_card = add_clean_card(slide1, Inches(8.95), top_pos, Inches(3.33), Inches(1.1), SURFACE_WHITE, BORDER_LIGHT)
        tf_t = tile_card.text_frame
        tf_t.word_wrap = True
        tf_t.margin_left = tf_t.margin_right = Inches(0.18)
        tf_t.margin_top = Inches(0.12)

        p0 = tf_t.paragraphs[0]
        p0.text = stat
        p0.font.name = FONT_BODY
        p0.font.size = Pt(11)
        p0.font.bold = True
        p0.font.color.rgb = PRIMARY_BLUE
        p0.space_after = Pt(1)

        p1 = tf_t.add_paragraph()
        p1.text = title
        p1.font.name = FONT_BODY
        p1.font.size = Pt(9.5)
        p1.font.bold = True
        p1.font.color.rgb = TEXT_NAVY

        p2 = tf_t.add_paragraph()
        p2.text = desc
        p2.font.name = FONT_BODY
        p2.font.size = Pt(8.5)
        p2.font.color.rgb = TEXT_SECONDARY

    add_speaker_notes(slide1,
        "Good morning respected members of the evaluation committee. Today I present VERAXIS AI, our Major Capstone Project. "
        "VERAXIS is an autonomous scientific intelligence and forensic verification engine designed to solve the critical "
        "hallucination problem in academic literature review at zero operational infrastructure cost."
    )

    # ==========================================
    # SLIDE 2: THE SCIENTIFIC CRISIS (PROBLEM FORMULATION)
    # ==========================================
    slide2 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide2)
    add_editorial_header(slide2, "01 | PROBLEM STATEMENT", "The Epistemic Crisis in Scientific Literature Discovery",
                         "Why foundational LLMs and monolithic agent architectures fail in rigorous research environments.")

    # Left Context Column (Executive Editorial Summary)
    ctx_card = add_clean_card(slide2, Inches(0.8), Inches(1.75), Inches(4.3), Inches(5.1), SURFACE_WHITE, BORDER_LIGHT)
    tf_ctx = ctx_card.text_frame
    tf_ctx.word_wrap = True
    tf_ctx.margin_left = tf_ctx.margin_right = Inches(0.3)
    tf_ctx.margin_top = Inches(0.3)

    p = tf_ctx.paragraphs[0]
    p.text = "EXECUTIVE DIAGNOSIS"
    p.font.name = FONT_BODY
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p.space_after = Pt(8)

    p_t = tf_ctx.add_paragraph()
    p_t.text = "The Double Failure of Modern AI in Research"
    p_t.font.name = FONT_EDITORIAL
    p_t.font.size = Pt(18)
    p_t.font.bold = True
    p_t.font.color.rgb = TEXT_NAVY
    p_t.space_after = Pt(12)

    p_body = tf_ctx.add_paragraph()
    p_body.text = (
        "Researchers face over 3 million peer-reviewed papers published annually. When using generic LLMs (ChatGPT, Claude), "
        "they confront unacceptable hallucination rates. Conversely, when attempting multi-agent frameworks (AutoGen, CrewAI), "
        "they hit crippling latency bottlenecks where trivial greetings take 45+ seconds to resolve.\n\n"
        "Furthermore, specialized commercial intelligence tools demand unsustainable subscription fees ($20–$50/seat/month), "
        "locking academic students and independent scholars behind paywalls."
    )
    p_body.font.name = FONT_BODY
    p_body.font.size = Pt(10.5)
    p_body.font.color.rgb = TEXT_SECONDARY
    p_body.space_after = Pt(14)

    # Right Side: 3 Horizontal Problem Callout Cards with Huge Serif Numbers
    prob_cards_data = [
        ("23% – 38%", ACCENT_ROSE, "Epistemic Confabulation & Fake Citations",
         "LLMs invent syntactically plausible DOIs and misattribute empirical metrics (e.g. drug trial efficacy, battery capacity) across completely unrelated studies."),
        ("45s DELAY", ACCENT_AMBER, "The Latency-vs-Depth Dilemma",
         "Monolithic agent systems trigger heavy multi-agent swarms even for simple conversational queries, exhausting token limits and destroying real-time usability."),
        ("$600 / YEAR", PRIMARY_BLUE, "Prohibitive Commercial Paywall Moats",
         "Platforms like Perplexity Pro, Elicit, and Consensus charge steep recurrent fees, creating an economic barrier for students and institutions with zero infrastructure budget.")
    ]

    for i, (stat, color, title, desc) in enumerate(prob_cards_data):
        top_pos = Inches(1.75 + i * 1.73)
        p_card = add_clean_card(slide2, Inches(5.4), top_pos, Inches(7.133), Inches(1.55), SURFACE_WHITE, BORDER_LIGHT)
        tf_pc = p_card.text_frame
        tf_pc.word_wrap = True
        tf_pc.margin_left = Inches(0.25)
        tf_pc.margin_top = Inches(0.18)

        # Huge Stat
        p_s = tf_pc.paragraphs[0]
        p_s.text = stat
        p_s.font.name = FONT_EDITORIAL
        p_s.font.size = Pt(22)
        p_s.font.bold = True
        p_s.font.color.rgb = color
        p_s.space_after = Pt(2)

        # Title
        p_title = tf_pc.add_paragraph()
        p_title.text = title
        p_title.font.name = FONT_BODY
        p_title.font.size = Pt(11)
        p_title.font.bold = True
        p_title.font.color.rgb = TEXT_NAVY
        p_title.space_after = Pt(2)

        # Description
        p_d = tf_pc.add_paragraph()
        p_d.text = desc
        p_d.font.name = FONT_BODY
        p_d.font.size = Pt(9.5)
        p_d.font.color.rgb = TEXT_SECONDARY

    add_speaker_notes(slide2,
        "This slide frames the core problem statement. "
        "Standard LLMs produce hallucinations up to 38% in scientific fields. "
        "Meanwhile, agentic systems suffer from a latency penalty where even a simple 'hello' triggers a 45-second agent loop. "
        "Finally, existing solutions cost $50/month. VERAXIS addresses all three challenges directly."
    )

    # ==========================================
    # SLIDE 3: HIGH-THROUGHPUT DUAL-ENGINE ARCHITECTURE
    # ==========================================
    slide3 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide3)
    add_editorial_header(slide3, "02 | SYSTEM ARCHITECTURE", "High-Throughput Dual-Engine Architecture",
                         "Sub-100ms intent classification prevents agent overkill while guaranteeing exhaustive research depth.")

    # Main Architecture Flow Container
    main_flow = add_clean_card(slide3, Inches(0.8), Inches(1.75), Inches(11.733), Inches(4.3), SURFACE_WHITE, BORDER_LIGHT)
    
    # 1. Ingestion Box (Left)
    n_in = add_clean_card(slide3, Inches(1.1), Inches(2.9), Inches(2.3), Inches(1.8), SURFACE_TINT, BORDER_STRONG)
    tf_in = n_in.text_frame
    tf_in.word_wrap = True
    tf_in.margin_left = tf_in.margin_right = Inches(0.12)
    tf_in.margin_top = Inches(0.15)
    p = tf_in.paragraphs[0]
    p.text = "USER QUERY INGESTION"
    p.font.name = FONT_BODY
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p.alignment = PP_ALIGN.CENTER
    p2 = tf_in.add_paragraph()
    p2.text = "React 19 Interface\nWebGL 2 Liquid Glass\nNatural Language Prompt\nDesktop / Mobile PWA"
    p2.font.name = FONT_BODY
    p2.font.size = Pt(9)
    p2.font.color.rgb = TEXT_SECONDARY
    p2.alignment = PP_ALIGN.CENTER

    # Arrow 1 -> Router
    arr1 = slide3.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(3.45), Inches(3.6), Inches(0.5), Inches(0.25))
    arr1.fill.solid()
    arr1.fill.fore_color.rgb = BORDER_STRONG
    arr1.line.fill.background()

    # 2. Intent Classifier Box (Center-Left)
    n_cls = add_clean_card(slide3, Inches(4.0), Inches(2.5), Inches(2.5), Inches(2.6), SURFACE_TINT, PRIMARY_BLUE)
    tf_cls = n_cls.text_frame
    tf_cls.word_wrap = True
    tf_cls.margin_left = tf_cls.margin_right = Inches(0.15)
    tf_cls.margin_top = Inches(0.15)
    p = tf_cls.paragraphs[0]
    p.text = "INTENT CLASSIFIER"
    p.font.name = FONT_BODY
    p.font.size = Pt(10)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p.alignment = PP_ALIGN.CENTER
    p2 = tf_cls.add_paragraph()
    p2.text = "router.py Engine\nLatency < 100ms\nEvaluates: Token Length, Academic Keywords & Prompt Rigor\nDual Decision Boundary"
    p2.font.name = FONT_BODY
    p2.font.size = Pt(9)
    p2.font.color.rgb = TEXT_NAVY
    p2.alignment = PP_ALIGN.CENTER

    # Top Arrow -> Fast Chat
    arr_top = slide3.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(6.55), Inches(2.5), Inches(0.55), Inches(0.22))
    arr_top.fill.solid()
    arr_top.fill.fore_color.rgb = PRIMARY_BLUE
    arr_top.line.fill.background()

    # Bottom Arrow -> Swarm
    arr_bot = slide3.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(6.55), Inches(4.5), Inches(0.55), Inches(0.22))
    arr_bot.fill.solid()
    arr_bot.fill.fore_color.rgb = ACCENT_TEAL
    arr_bot.line.fill.background()

    # 3A. Fast Chat Pipeline Box (Top Right)
    n_fast = add_clean_card(slide3, Inches(7.15), Inches(2.0), Inches(5.1), Inches(1.5), SURFACE_ACCENT_LIGHT, PRIMARY_BLUE)
    tf_f = n_fast.text_frame
    tf_f.word_wrap = True
    tf_f.margin_left = tf_f.margin_right = Inches(0.2)
    tf_f.margin_top = Inches(0.12)
    p = tf_f.paragraphs[0]
    p.text = "PIPELINE A: GENERAL_CHAT  (<400ms Ultra-Fast Stream)"
    p.font.name = FONT_BODY
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p2 = tf_f.add_paragraph()
    p2.text = "• Bypasses agent overhead completely for greetings and direct factual Q&A.\n• Groq LPU hardware acceleration running Llama-3.1-8B-Instant.\n• Instant token-by-token streaming back to client UI."
    p2.font.name = FONT_BODY
    p2.font.size = Pt(8.8)
    p2.font.color.rgb = TEXT_NAVY

    # 3B. Multi-Agent Deep Research Swarm (Bottom Right)
    n_deep = add_clean_card(slide3, Inches(7.15), Inches(3.8), Inches(5.1), Inches(2.0), SURFACE_TINT, ACCENT_TEAL)
    tf_d = n_deep.text_frame
    tf_d.word_wrap = True
    tf_d.margin_left = tf_d.margin_right = Inches(0.2)
    tf_d.margin_top = Inches(0.12)
    p = tf_d.paragraphs[0]
    p.text = "PIPELINE B: DEEP_RESEARCH  (Autonomous 3-Tier Swarm)"
    p.font.name = FONT_BODY
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = ACCENT_TEAL
    p2 = tf_d.add_paragraph()
    p2.text = (
        "• Tier 1: Lead Analyst retrieves ArXiv preprints, DuckDuckGo & Wikipedia.\n"
        "• Tier 2: Forensic Fact-Checker cross-verifies & computes confidence matrix.\n"
        "• Tier 3: Executive Dossier Director structures publication synthesis.\n"
        "• ReportLab 4.x compiles two-pass publication-grade vector PDF."
    )
    p2.font.name = FONT_BODY
    p2.font.size = Pt(8.8)
    p2.font.color.rgb = TEXT_NAVY

    # Bottom Callout Strip
    bot_callout = add_clean_card(slide3, Inches(0.8), Inches(6.15), Inches(11.733), Inches(0.8), SURFACE_WHITE, BORDER_STRONG)
    tf_b = bot_callout.text_frame
    tf_b.word_wrap = True
    tf_b.margin_left = Inches(0.25)
    tf_b.margin_top = Inches(0.1)
    p = tf_b.paragraphs[0]
    p.text = "ARCHITECTURAL BREAKTHROUGH: THE DUAL-ROUTE PARADIGM"
    p.font.name = FONT_BODY
    p.font.size = Pt(9)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p2 = tf_b.add_paragraph()
    p2.text = "Eliminates the trade-off between conversational speed and research rigor. Zero latency penalty for simple questions, while deep scientific prompts receive multi-source verification."
    p2.font.name = FONT_BODY
    p2.font.size = Pt(9.5)
    p2.font.color.rgb = TEXT_SECONDARY

    add_speaker_notes(slide3,
        "Here you see the dual-engine architecture. "
        "When a user enters a query, our sub-100 millisecond classifier analyzes token density, academic keywords, and prompt intent. "
        "Casual questions route to Pipeline A, streaming in under 400 milliseconds via Groq LPUs. "
        "Analytical questions route to Pipeline B, initiating our 3-tier CrewAI swarm and compiling a vector PDF dossier."
    )

    # ==========================================
    # SLIDE 4: 3-TIER AGENTIC HIERARCHY
    # ==========================================
    slide4 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide4)
    add_editorial_header(slide4, "03 | MULTI-AGENT SWARM", "Sequential 3-Tier Multi-Agent Research Hierarchy",
                         "Strict separation of concerns eliminates single-agent confirmation bias through adversarial fact verification.")

    agent_w = Inches(3.72)
    agent_h = Inches(5.2)
    agent_top = Inches(1.75)

    agents_data = [
        ("STAGE 01", PRIMARY_BLUE, "Lead Research Analyst", "Discovery & Retrieval Phase", [
            ("Role & Mandate", "Exhaustive literature collection across preprints, live web indexes, and foundational domain ontology."),
            ("Integrated Tools", "ArXiv REST API (peer-reviewed preprints), DuckDuckGo Search (breaking developments), Wikipedia API."),
            ("Ingestion Logic", "Extracts verbatim abstracts, author attributions, publication dates, and experimental numerical assertions."),
            ("Phase Output", "Unfiltered empirical corpus with primary source citations and metadata.")
        ]),
        ("STAGE 02", ACCENT_TEAL, "Forensic Truth Auditor", "Adversarial Verification Gate", [
            ("Role & Mandate", "Cross-examines all findings against retrieved source literature with zero tolerance for confabulation."),
            ("Mathematical Model", "Calculates a 0–100% Verification Confidence Matrix based on weighted corroboration and source reliability."),
            ("Classification Rules", "Tags claims as VERIFIED (corroborated), CONTESTED (conflicting data), or UNVERIFIED (excised)."),
            ("Phase Output", "Audited assertion registry guaranteeing 0% ungrounded citations.")
        ]),
        ("STAGE 03", ACCENT_AMBER, "Executive Dossier Director", "Strategic Synthesis Phase", [
            ("Role & Mandate", "Synthesizes audited claims into high-impact executive deliverables following McKinsey/Gartner standards."),
            ("Formatting Standard", "Produces Executive Summaries, Quantitative KPI Matrix cards, and hyperlinked academic bibliographies."),
            ("Payload Packaging", "Streams structured Markdown payload to the client UI while feeding the ReportLab 4.x PDF compiler."),
            ("Phase Output", "Publication-ready research dossier available in UI and downloadable vector PDF.")
        ])
    ]

    for i, (stage, color, title, subtitle, sections) in enumerate(agents_data):
        left_pos = Inches(0.8 + i * (3.72 + 0.28))
        card = add_clean_card(slide4, left_pos, agent_top, agent_w, agent_h, SURFACE_WHITE, BORDER_LIGHT)
        tf_a = card.text_frame
        tf_a.word_wrap = True
        tf_a.margin_left = tf_a.margin_right = Inches(0.22)
        tf_a.margin_top = Inches(0.2)

        # Stage Pill
        p_s = tf_a.paragraphs[0]
        p_s.text = stage
        p_s.font.name = FONT_BODY
        p_s.font.size = Pt(9)
        p_s.font.bold = True
        p_s.font.color.rgb = color
        p_s.space_after = Pt(2)

        # Title
        p_t = tf_a.add_paragraph()
        p_t.text = title
        p_t.font.name = FONT_EDITORIAL
        p_t.font.size = Pt(14)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_NAVY
        p_t.space_after = Pt(2)

        # Subtitle
        p_sub = tf_a.add_paragraph()
        p_sub.text = subtitle
        p_sub.font.name = FONT_BODY
        p_sub.font.size = Pt(9)
        p_sub.font.color.rgb = TEXT_MUTED
        p_sub.space_after = Pt(10)

        # Sections
        for sec_name, sec_text in sections:
            p_sn = tf_a.add_paragraph()
            p_sn.text = sec_name.upper()
            p_sn.font.name = FONT_BODY
            p_sn.font.size = Pt(8.5)
            p_sn.font.bold = True
            p_sn.font.color.rgb = color

            p_st = tf_a.add_paragraph()
            p_st.text = sec_text
            p_st.font.name = FONT_BODY
            p_st.font.size = Pt(9)
            p_st.font.color.rgb = TEXT_SECONDARY
            p_st.space_after = Pt(7)

    add_speaker_notes(slide4,
        "Slide 4 breaks down our 3-tier multi-agent hierarchy. "
        "Standard multi-agent systems fail because agents agree with each other's hallucinations. "
        "In VERAXIS, Agent 2 is explicitly adversarial. It audits every statement produced by Agent 1 against raw ArXiv text, "
        "calculating a mathematical confidence score. If an assertion cannot be verified, it is completely discarded before reaching Agent 3."
    )

    # ==========================================
    # SLIDE 5: TECHNICAL INNOVATIONS & RESILIENCE
    # ==========================================
    slide5 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide5)
    add_editorial_header(slide5, "04 | TECHNICAL INNOVATIONS", "Zero-Cost Resilience & Publication Vector Engine",
                         "Solving free-tier rate limits and compiling desktop-grade vector documentation.")

    inno_w = Inches(3.72)
    inno_h = Inches(5.2)
    inno_top = Inches(1.75)

    innovations_data = [
        ("INNOVATION 01", PRIMARY_BLUE, "KeyManager 41-Key Failover Engine", [
            ("Zero Cloud Cost", "Operates enterprise-grade LPU inference without paid subscriptions by managing a pool of 41+ Groq API keys."),
            ("Round-Robin Balancing", "Distributes prompt volume dynamically to stay strictly within free-tier Rate-Per-Minute (RPM) thresholds."),
            ("Silent 429 Interception", "Automatically intercepts HTTP 429 (Rate Limit Exceeded) errors, rotates to the next healthy key, and completes long runs without user intervention.")
        ]),
        ("INNOVATION 02", ACCENT_TEAL, "Two-Pass Vector PDF Compiler", [
            ("Custom NumberedCanvas", "Standard PDF libraries suffer from awkward page breaks. Our two-pass canvas counts total pages in Pass 1, then stamps dynamic 'Page X of Y' headers in Pass 2."),
            ("McKinsey / Gartner Standard", "Directly formats Executive Summaries, KPI Metric Cards, comparison matrices, and hyperlinked academic citations."),
            ("Sub-2.5s Generation", "Renders vector-sharp, publication-ready PDFs ready for university submission and executive briefings.")
        ]),
        ("INNOVATION 03", ACCENT_AMBER, "WebGL 2 Liquid Glass Shaders", [
            ("Super-Oval Geometry", "Custom GLSL fragment shader rendering continuous super-oval contours (p = 2.5) with zero boxy hard corners."),
            ("Snell's Law Refraction", "Real physical optics simulation with refractive index n = 1.52, surface tension capillary waves, and rainbow dispersion."),
            ("Stable 60 FPS", "Runs directly on client GPU hardware, preventing browser DOM recalculation and layout thrashing.")
        ])
    ]

    for i, (tag, color, title, points) in enumerate(innovations_data):
        left_pos = Inches(0.8 + i * (3.72 + 0.28))
        card = add_clean_card(slide5, left_pos, inno_top, inno_w, inno_h, SURFACE_WHITE, BORDER_LIGHT)
        tf_i = card.text_frame
        tf_i.word_wrap = True
        tf_i.margin_left = tf_i.margin_right = Inches(0.22)
        tf_i.margin_top = Inches(0.2)

        p_tag = tf_i.paragraphs[0]
        p_tag.text = tag
        p_tag.font.name = FONT_BODY
        p_tag.font.size = Pt(9)
        p_tag.font.bold = True
        p_tag.font.color.rgb = color
        p_tag.space_after = Pt(2)

        p_t = tf_i.add_paragraph()
        p_t.text = title
        p_t.font.name = FONT_EDITORIAL
        p_t.font.size = Pt(13.5)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_NAVY
        p_t.space_after = Pt(10)

        for pt_head, pt_body in points:
            p_ph = tf_i.add_paragraph()
            p_ph.text = pt_head
            p_ph.font.name = FONT_BODY
            p_ph.font.size = Pt(9.5)
            p_ph.font.bold = True
            p_ph.font.color.rgb = color

            p_pb = tf_i.add_paragraph()
            p_pb.text = pt_body
            p_pb.font.name = FONT_BODY
            p_pb.font.size = Pt(9)
            p_pb.font.color.rgb = TEXT_SECONDARY
            p_pb.space_after = Pt(8)

    add_speaker_notes(slide5,
        "Here are our three core engineering innovations. "
        "First, our KeyManager: To achieve zero infrastructure cost, we built a round-robin rotation system across 41 Groq API keys with automated 429 error failover. "
        "Second, our two-pass ReportLab vector PDF compiler produces publication-grade dossiers with exact pagination in under 2.5 seconds. "
        "Third, our WebGL 2 Liquid Glass shader renders optical refraction and super-oval physics at 60 FPS."
    )

    # ==========================================
    # SLIDE 6: MATHEMATICAL FOUNDATIONS & ALGORITHMS
    # ==========================================
    slide6 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide6)
    add_editorial_header(slide6, "05 | MATHEMATICAL FOUNDATIONS", "Algorithmic Models for Intent & Verification",
                         "Formal deterministic formulations driving sub-second query dispatch and zero-hallucination audits.")

    # Left Column: Algorithm 1 (Modular 3-Tier Card Stack)
    c_l_top = add_clean_card(slide6, Inches(0.8), Inches(1.75), Inches(5.7), Inches(1.55), SURFACE_WHITE, BORDER_LIGHT)
    tf_lt = c_l_top.text_frame
    tf_lt.word_wrap = True
    tf_lt.margin_left = tf_lt.margin_right = Inches(0.24)
    tf_lt.margin_top = Inches(0.18)

    p = tf_lt.paragraphs[0]
    p.text = "ALGORITHM 1: DUAL-ROUTE DISPATCH DISCRIMINATOR"
    p.font.name = FONT_BODY
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p.space_after = Pt(3)

    p_t1 = tf_lt.add_paragraph()
    p_t1.text = "Sub-100ms Heuristic Query Segregation"
    p_t1.font.name = FONT_EDITORIAL
    p_t1.font.size = Pt(13)
    p_t1.font.bold = True
    p_t1.font.color.rgb = TEXT_NAVY
    p_t1.space_after = Pt(4)

    p_m1 = tf_lt.add_paragraph()
    p_m1.text = "Let Q be the input query. We compute feature vector F(Q) = ⟨L(Q), K(Q), S(Q)⟩ measuring token length, academic keyword density, and inquiry complexity:"
    p_m1.font.name = FONT_BODY
    p_m1.font.size = Pt(9.2)
    p_m1.font.color.rgb = TEXT_SECONDARY

    # Formula Box 1
    f_box1 = add_clean_card(slide6, Inches(0.8), Inches(3.4), Inches(5.7), Inches(1.1), SURFACE_TINT, BORDER_STRONG)
    tf_fb1 = f_box1.text_frame
    tf_fb1.word_wrap = True
    tf_fb1.margin_left = Inches(0.2)
    tf_fb1.margin_top = Inches(0.12)
    p_eq1 = tf_fb1.paragraphs[0]
    p_eq1.text = "Route(Q) = DEEP_RESEARCH  if  Score(F(Q)) ≥ τ  ∨  ExplicitMode == True\nRoute(Q) = GENERAL_CHAT   otherwise   (Decision Threshold τ = 0.72)"
    p_eq1.font.name = FONT_CODE
    p_eq1.font.size = Pt(9.2)
    p_eq1.font.bold = True
    p_eq1.font.color.rgb = PRIMARY_BLUE

    # Invariants Box 1
    c_l_bot = add_clean_card(slide6, Inches(0.8), Inches(4.6), Inches(5.7), Inches(2.35), SURFACE_WHITE, BORDER_LIGHT)
    tf_lb = c_l_bot.text_frame
    tf_lb.word_wrap = True
    tf_lb.margin_left = tf_lb.margin_right = Inches(0.24)
    tf_lb.margin_top = Inches(0.18)

    p = tf_lb.paragraphs[0]
    p.text = "OPERATIONAL INVARIANTS & COMPLEXITY"
    p.font.name = FONT_BODY
    p.font.size = Pt(9)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p.space_after = Pt(4)

    invariants_list = [
        ("O(1) Time Complexity", "Sub-100ms lexical scan evaluates token patterns before triggering any LLM calls."),
        ("Zero Latency Penalty", "Bypasses agent swarm completely for greetings and direct Q&A (latency < 400ms)."),
        ("Selective Swarm Allocation", "Full 3-tier multi-agent crew is engaged exclusively when analytical depth is required.")
    ]
    for h, b in invariants_list:
        p_h = tf_lb.add_paragraph()
        p_h.text = "• " + h + ": "
        p_h.font.name = FONT_BODY
        p_h.font.size = Pt(9.2)
        p_h.font.bold = True
        p_h.font.color.rgb = TEXT_NAVY
        p_b = tf_lb.add_paragraph()
        p_b.text = "   " + b
        p_b.font.name = FONT_BODY
        p_b.font.size = Pt(8.8)
        p_b.font.color.rgb = TEXT_SECONDARY
        p_b.space_after = Pt(2)

    # Right Column: Algorithm 2 (Modular 3-Tier Card Stack)
    c_r_top = add_clean_card(slide6, Inches(6.8), Inches(1.75), Inches(5.7), Inches(1.55), SURFACE_WHITE, BORDER_LIGHT)
    tf_rt = c_r_top.text_frame
    tf_rt.word_wrap = True
    tf_rt.margin_left = tf_rt.margin_right = Inches(0.24)
    tf_rt.margin_top = Inches(0.18)

    p = tf_rt.paragraphs[0]
    p.text = "ALGORITHM 2: FORENSIC CONFIDENCE MATRIX"
    p.font.name = FONT_BODY
    p.font.size = Pt(9.5)
    p.font.bold = True
    p.font.color.rgb = ACCENT_TEAL
    p.space_after = Pt(3)

    p_t2 = tf_rt.add_paragraph()
    p_t2.text = "Adversarial Grounding & Confidence Evaluation"
    p_t2.font.name = FONT_EDITORIAL
    p_t2.font.size = Pt(13)
    p_t2.font.bold = True
    p_t2.font.color.rgb = TEXT_NAVY
    p_t2.space_after = Pt(4)

    p_m2 = tf_rt.add_paragraph()
    p_m2.text = "For every empirical claim c_i in corpus C and retrieved academic evidence documents D, verification score S(c_i) is evaluated as:"
    p_m2.font.name = FONT_BODY
    p_m2.font.size = Pt(9.2)
    p_m2.font.color.rgb = TEXT_SECONDARY

    # Formula Box 2
    f_box2 = add_clean_card(slide6, Inches(6.8), Inches(3.4), Inches(5.7), Inches(1.1), SURFACE_TINT, BORDER_STRONG)
    tf_fb2 = f_box2.text_frame
    tf_fb2.word_wrap = True
    tf_fb2.margin_left = Inches(0.2)
    tf_fb2.margin_top = Inches(0.12)
    p_eq2 = tf_fb2.paragraphs[0]
    p_eq2.text = "S(c_i) = α · Corroborate(c_i, D) + β · SourceWeight(S) - γ · Conflict(D)\nComposite Confidence = (1 / |C|) · ∑ S(c_i) × 100%"
    p_eq2.font.name = FONT_CODE
    p_eq2.font.size = Pt(9.2)
    p_eq2.font.bold = True
    p_eq2.font.color.rgb = ACCENT_TEAL

    # Invariants Box 2
    c_r_bot = add_clean_card(slide6, Inches(6.8), Inches(4.6), Inches(5.7), Inches(2.35), SURFACE_WHITE, BORDER_LIGHT)
    tf_rb = c_r_bot.text_frame
    tf_rb.word_wrap = True
    tf_rb.margin_left = tf_rb.margin_right = Inches(0.24)
    tf_rb.margin_top = Inches(0.18)

    p = tf_rb.paragraphs[0]
    p.text = "STRICT VERIFICATION THRESHOLDS"
    p.font.name = FONT_BODY
    p.font.size = Pt(9)
    p.font.bold = True
    p.font.color.rgb = ACCENT_TEAL
    p.space_after = Pt(4)

    thresholds_list = [
        ("Score ≥ 0.85: VERIFIED", "Cross-corroborated by peer-reviewed ArXiv papers; accepted into final dossier."),
        ("0.50 ≤ Score < 0.85: CONTESTED", "Conflicting empirical data across sources; explicitly highlighted in report."),
        ("Score < 0.50: UNVERIFIED", "Ungrounded assertion excised completely to guarantee 0% hallucination.")
    ]
    for h, b in thresholds_list:
        p_h = tf_rb.add_paragraph()
        p_h.text = "• " + h + ": "
        p_h.font.name = FONT_BODY
        p_h.font.size = Pt(9.2)
        p_h.font.bold = True
        p_h.font.color.rgb = TEXT_NAVY
        p_b = tf_rb.add_paragraph()
        p_b.text = "   " + b
        p_b.font.name = FONT_BODY
        p_b.font.size = Pt(8.8)
        p_b.font.color.rgb = TEXT_SECONDARY
        p_b.space_after = Pt(2)

    add_speaker_notes(slide6,
        "Slide 6 provides our academic and mathematical rigor. "
        "We formalized two deterministic algorithms: Algorithm 1 evaluates incoming prompts in under 100 milliseconds to choose the correct route. "
        "Algorithm 2 models our Forensic Truth Auditor. It scores each assertion using weighted corroboration and source reliability metrics. "
        "Any assertion scoring below 0.50 is immediately excised, providing our 0% ungrounded citations guarantee."
    )

    # ==========================================
    # SLIDE 7: FULL-STACK TECHNOLOGY MATRIX
    # ==========================================
    slide7 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide7)
    add_editorial_header(slide7, "06 | TECHNOLOGY STACK", "Enterprise-Grade Full-Stack Architecture",
                         "Cohesive, modern software stack engineered for maximum throughput, modularity, and zero licensing cost.")

    stack_w = Inches(2.76)
    stack_h = Inches(5.2)
    stack_top = Inches(1.75)

    stack_layers = [
        ("LAYER 01", PRIMARY_BLUE, "Frontend & Graphics", [
            ("React 19", "Concurrent rendering & state management"),
            ("Tailwind CSS v4", "Modern CSS variable design tokens"),
            ("WebGL 2 / GLSL", "Custom liquid glass optical shaders"),
            ("Vite 6 Bundler", "Sub-second HMR & optimized production"),
            ("PWA Architecture", "Offline caching & mobile installability")
        ]),
        ("LAYER 02", ACCENT_TEAL, "Backend & API Engine", [
            ("Python 3.11/3.12", "Modern asynchronous execution runtime"),
            ("FastAPI 0.110", "High-throughput ASGI endpoints"),
            ("CrewAI 1.15", "Role-segregated agent coordination"),
            ("Uvicorn Server", "High-performance async server loop"),
            ("Pydantic v2", "Strict type validation & data schemas")
        ]),
        ("LAYER 03", ACCENT_AMBER, "AI & Inference Layer", [
            ("Groq LPU Hardware", "Ultra-low-latency tensor inference"),
            ("Llama-3.3-70B", "Deep scientific research & auditing"),
            ("Llama-3.1-8B", "Sub-400ms general conversational model"),
            ("KeyManager", "Round-robin 41-key failover pool"),
            ("Demo Cache", "Offline failsafe evaluation cache")
        ]),
        ("LAYER 04", PRIMARY_BLUE, "Retrieval & Documents", [
            ("ArXiv REST API", "Peer-reviewed preprint discovery"),
            ("DuckDuckGo Search", "Live web index & breaking discoveries"),
            ("Wikipedia REST", "Domain taxonomy & ontologies"),
            ("ReportLab 4.x", "Two-pass vector PDF document compiler"),
            ("Pytest & PyMuPDF", "Automated validation & test harness")
        ])
    ]

    for i, (stage, color, title, items) in enumerate(stack_layers):
        left_pos = Inches(0.8 + i * (2.76 + 0.23))
        card = add_clean_card(slide7, left_pos, stack_top, stack_w, stack_h, SURFACE_WHITE, BORDER_LIGHT)
        tf_s = card.text_frame
        tf_s.word_wrap = True
        tf_s.margin_left = tf_s.margin_right = Inches(0.18)
        tf_s.margin_top = Inches(0.2)

        p_s = tf_s.paragraphs[0]
        p_s.text = stage
        p_s.font.name = FONT_BODY
        p_s.font.size = Pt(8.5)
        p_s.font.bold = True
        p_s.font.color.rgb = color
        p_s.space_after = Pt(2)

        p_t = tf_s.add_paragraph()
        p_t.text = title
        p_t.font.name = FONT_EDITORIAL
        p_t.font.size = Pt(13)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_NAVY
        p_t.space_after = Pt(10)

        for name, desc in items:
            p_n = tf_s.add_paragraph()
            p_n.text = name
            p_n.font.name = FONT_BODY
            p_n.font.size = Pt(9.5)
            p_n.font.bold = True
            p_n.font.color.rgb = color

            p_d = tf_s.add_paragraph()
            p_d.text = desc
            p_d.font.name = FONT_BODY
            p_d.font.size = Pt(8.5)
            p_d.font.color.rgb = TEXT_SECONDARY
            p_d.space_after = Pt(6)

    add_speaker_notes(slide7,
        "Slide 7 shows our full-stack technology matrix. Every layer is built on open standards with zero licensing cost. "
        "Frontend utilizes React 19 and raw WebGL 2 shaders. "
        "Backend uses FastAPI with CrewAI. "
        "Inference is powered by Groq LPUs running Llama-3.3-70B for research and 8B-Instant for quick chat. "
        "Document compilation is performed by ReportLab 4.x."
    )

    # ==========================================
    # SLIDE 8: EMPIRICAL BENCHMARKING & LIVE ARTIFACTS
    # ==========================================
    slide8 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide8)
    add_editorial_header(slide8, "07 | BENCHMARKING & EVIDENCE", "Empirical Validation & Live Platform Artifacts",
                         "Rigorous verification through automated test suites, sub-second latency benchmarks, and publication dossiers.")

    # Left: Light Mode UI Screenshot
    ui_shot_path = "scratch/shot_topbar_light.png"
    if not os.path.exists(ui_shot_path):
        ui_shot_path = "scratch/shot_full_decluttered.png"
        
    card_ui = add_clean_card(slide8, Inches(0.8), Inches(1.75), Inches(4.3), Inches(4.0), SURFACE_WHITE, BORDER_LIGHT)
    if os.path.exists(ui_shot_path):
        slide8.shapes.add_picture(ui_shot_path, Inches(0.9), Inches(1.85), width=Inches(4.1))
        
    tb_ui = slide8.shapes.add_textbox(Inches(0.8), Inches(5.85), Inches(4.3), Inches(0.9))
    tf_ui = tb_ui.text_frame
    tf_ui.word_wrap = True
    p = tf_ui.paragraphs[0]
    p.text = "LIVE PLATFORM LIGHT THEME INTERFACE"
    p.font.name = FONT_BODY
    p.font.size = Pt(9)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_BLUE
    p2 = tf_ui.add_paragraph()
    p2.text = "React 19 + Tailwind CSS v4 clean interface with liquid lens search composer and theme toggle."
    p2.font.name = FONT_BODY
    p2.font.size = Pt(8.5)
    p2.font.color.rgb = TEXT_SECONDARY

    # Middle: Rendered Publication PDF Page
    pdf_shot_path = "scratch/sample_pdf_page1.png"
    card_pdf = add_clean_card(slide8, Inches(5.3), Inches(1.75), Inches(3.2), Inches(5.0), SURFACE_WHITE, BORDER_LIGHT)
    if os.path.exists(pdf_shot_path):
        slide8.shapes.add_picture(pdf_shot_path, Inches(5.4), Inches(1.85), width=Inches(3.0))

    tb_pdf = slide8.shapes.add_textbox(Inches(5.3), Inches(6.55), Inches(3.2), Inches(0.5))
    tf_pdf = tb_pdf.text_frame
    tf_pdf.word_wrap = True
    p = tf_pdf.paragraphs[0]
    p.text = "PUBLICATION-GRADE VECTOR DOSSIER"
    p.font.name = FONT_BODY
    p.font.size = Pt(8.5)
    p.font.bold = True
    p.font.color.rgb = ACCENT_TEAL

    # Right: 4 Benchmark Metric Cards
    metrics_bright = [
        ("20 / 20", "100% Test Suite Green", "Automated unit, router, and integration tests passed in test.py.", ACCENT_TEAL),
        ("< 400 ms", "Fast Chat Response", "Sub-second conversational latency on Groq LPUs.", PRIMARY_BLUE),
        ("0%", "Ungrounded Citations", "Zero hallucinated references across benchmark queries.", ACCENT_TEAL),
        ("₹0.00", "Zero Infrastructure Cost", "100% free-tier resilience via KeyManager rotation.", ACCENT_AMBER)
    ]

    metric_top_start = Inches(1.75)
    metric_h = Inches(1.15)
    for i, (m_val, m_title, m_desc, m_color) in enumerate(metrics_bright):
        top_pos = metric_top_start + i * (metric_h + Inches(0.12))
        m_card = add_clean_card(slide8, Inches(8.7), top_pos, Inches(3.833), metric_h, SURFACE_WHITE, BORDER_LIGHT)
        tf_m = m_card.text_frame
        tf_m.word_wrap = True
        tf_m.margin_left = Inches(0.18)
        tf_m.margin_top = Inches(0.12)

        p0 = tf_m.paragraphs[0]
        p0.text = m_val
        p0.font.name = FONT_EDITORIAL
        p0.font.size = Pt(16)
        p0.font.bold = True
        p0.font.color.rgb = m_color
        p0.space_after = Pt(1)

        p1 = tf_m.add_paragraph()
        p1.text = m_title
        p1.font.name = FONT_BODY
        p1.font.size = Pt(9.5)
        p1.font.bold = True
        p1.font.color.rgb = TEXT_NAVY

        p2 = tf_m.add_paragraph()
        p2.text = m_desc
        p2.font.name = FONT_BODY
        p2.font.size = Pt(8.5)
        p2.font.color.rgb = TEXT_SECONDARY

    add_speaker_notes(slide8,
        "Slide 8 presents empirical validation. "
        "On the left, you see our live React 19 interface in light mode. "
        "In the center is a real publication dossier compiled by our two-pass ReportLab engine. "
        "On the right are our benchmark metrics: 20 out of 20 test cases passing with 100% success rate, sub-400ms chat latency, 0% ungrounded citations, and zero operational infrastructure cost."
    )

    # ==========================================
    # SLIDE 9: CONCLUSION & FUTURE ROADMAP
    # ==========================================
    slide9 = prs.slides.add_slide(blank_layout)
    set_slide_background(slide9)
    add_editorial_header(slide9, "08 | CONCLUSION & ROADMAP", "Impact, Extensibility & Future Directions",
                         "Transforming scientific discovery through accessible, zero-hallucination agentic intelligence.")

    col_w = Inches(3.72)
    col_h = Inches(5.2)
    col_top = Inches(1.75)

    conclusion_cols = [
        ("PROJECT IMPACT", PRIMARY_BLUE, "Academic & Societal Value", [
            ("Democratization of Intelligence", "Provides university students and independent researchers with enterprise-grade research capabilities at zero cost."),
            ("Epistemic Trustworthiness", "Solves the scientific reproducibility crisis by enforcing auditable evidence trails for every claim."),
            ("Dual-Paradigm Ergonomics", "Bridges the gap between casual conversational Q&A and rigorous academic publication dossiers.")
        ]),
        ("ROADMAP", ACCENT_AMBER, "Future Research Extensions", [
            ("Multi-Modal ArXiv Parser", "Direct OCR and tabular extraction of charts, phase diagrams, and chemical equations from PDF preprints."),
            ("Graph RAG Traversal", "Constructing dynamic citation knowledge graphs to track ideological lineages across scientific papers."),
            ("Air-Gapped Deployment", "Integration with Ollama and vLLM for high-security, classified research lab installations.")
        ]),
        ("DEFENSE SUMMARY", ACCENT_TEAL, "Evaluation Summary & Viva", [
            ("Production-Grade Execution", "Complete working full-stack implementation with 100% green automated test suites."),
            ("Architectural Rigor", "Novel dual-route intent classifier eliminates latency bottlenecks while preserving deep reasoning."),
            ("Q & A Session", "Open for Questions, Evaluation Review & Live Demonstration.")
        ])
    ]

    for i, (tag, color, title, sections) in enumerate(conclusion_cols):
        left_pos = Inches(0.8 + i * (3.72 + 0.28))
        card = add_clean_card(slide9, left_pos, col_top, col_w, col_h, SURFACE_WHITE, BORDER_LIGHT)
        tf_c = card.text_frame
        tf_c.word_wrap = True
        tf_c.margin_left = tf_c.margin_right = Inches(0.22)
        tf_c.margin_top = Inches(0.2)

        p_tag = tf_c.paragraphs[0]
        p_tag.text = tag
        p_tag.font.name = FONT_BODY
        p_tag.font.size = Pt(9)
        p_tag.font.bold = True
        p_tag.font.color.rgb = color
        p_tag.space_after = Pt(2)

        p_t = tf_c.add_paragraph()
        p_t.text = title
        p_t.font.name = FONT_EDITORIAL
        p_t.font.size = Pt(13.5)
        p_t.font.bold = True
        p_t.font.color.rgb = TEXT_NAVY
        p_t.space_after = Pt(12)

        for sec_t, sec_d in sections:
            p_st = tf_c.add_paragraph()
            p_st.text = sec_t
            p_st.font.name = FONT_BODY
            p_st.font.size = Pt(9.5)
            p_st.font.bold = True
            p_st.font.color.rgb = color

            p_sd = tf_c.add_paragraph()
            p_sd.text = sec_d
            p_sd.font.name = FONT_BODY
            p_sd.font.size = Pt(9)
            p_sd.font.color.rgb = TEXT_SECONDARY
            p_sd.space_after = Pt(8)

    add_speaker_notes(slide9,
        "In conclusion, VERAXIS AI demonstrates how role-segregated multi-agent swarms can eliminate hallucination in deep-tech research at zero infrastructure cost. "
        "Our dual-route architecture provides the speed of casual chat with the depth of a research institution. "
        "Thank you to the committee for your time. I am now open for questions and ready for the live demonstration."
    )

    output_path = "docs/VERAXIS_AI_Major_Project_Presentation_Bright.pptx"
    os.makedirs("docs", exist_ok=True)
    prs.save(output_path)
    print(f"Bright Theme Presentation successfully created at: {output_path}")

if __name__ == "__main__":
    create_bright_deck()
