import asyncio
from playwright.async_api import async_playwright

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={"width": 1440, "height": 900},
            permissions=["clipboard-read", "clipboard-write"]
        )
        page = await context.new_page()

        print("1. Navigating to http://localhost:8000 ...")
        await page.goto("http://localhost:8000", wait_until="networkidle")

        # 1. Verify TopBar Navigation
        topbar_nav = page.locator("nav[aria-label='Main navigation']")
        assert await topbar_nav.count() >= 1, "TopBar navigation segment not found"
        print("✅ TopBar segmented navigation exists")

        # Check navigation buttons
        ask_btn = topbar_nav.locator("button:has-text('Ask')").first
        saved_btn = topbar_nav.locator("button:has-text('Saved')").first
        keys_btn = topbar_nav.locator("button:has-text('Keys')").first
        assert await ask_btn.is_visible()
        assert await saved_btn.is_visible()
        assert await keys_btn.is_visible()
        print("✅ Navigation items [Ask, Saved, Keys] all visible and compact")

        # Screenshot TopBar in Dark Mode
        await page.screenshot(path="scratch/shot_topbar_dark.png")
        print("📸 Captured shot_topbar_dark.png")

        # Switch to Light Mode and verify
        theme_toggle = page.locator("button[aria-label='Toggle light and dark appearance']").first
        if await theme_toggle.is_visible():
            await theme_toggle.click()
            await asyncio.sleep(0.5)
            await page.screenshot(path="scratch/shot_topbar_light.png")
            print("📸 Captured shot_topbar_light.png (verified light mode)")
            # Switch back to dark mode
            await theme_toggle.click()
            await asyncio.sleep(0.5)

        # 2. Verify Prompt Composer & Formatting Bar
        composer = page.locator("textarea[placeholder*='Ask anything']").first
        assert await composer.is_visible(), "Composer textarea not found"
        
        # Verify formatting toolbar buttons
        b_btn = page.locator("button[title*='Bold']").first
        i_btn = page.locator("button[title*='Italic']").first
        h_btn = page.locator("button[title*='Heading']").first
        code_btn = page.locator("button[title*='Code']").first
        list_btn = page.locator("button[title*='Bullet List']").first
        quote_btn = page.locator("button[title*='Quote']").first
        
        assert await b_btn.is_visible(), "Bold button not visible"
        assert await i_btn.is_visible(), "Italic button not visible"
        assert await h_btn.is_visible(), "Heading button not visible"
        assert await code_btn.is_visible(), "Code button not visible"
        assert await list_btn.is_visible(), "List button not visible"
        assert await quote_btn.is_visible(), "Quote button not visible"
        print("✅ Formatting toolbar [B, I, H, </>, •, \"] all visible and active")

        # Test clicking Bold button
        await b_btn.click()
        val = await composer.input_value()
        assert "**bold text**" in val, f"Expected **bold text** in textarea, got '{val}'"
        print("✅ Bold formatting successfully inserted into textarea")

        # Test Clear button
        clear_btn = page.locator("button[title='Clear prompt']").first
        if await clear_btn.is_visible():
            await clear_btn.click()
            val2 = await composer.input_value()
            assert val2 == "", "Clear button failed"
            print("✅ Clear button works")

        # Screenshot Composer
        await page.screenshot(path="scratch/shot_composer_fixed.png")
        print("📸 Captured shot_composer_fixed.png")

        # 3. Test Research Query Execution & Check Report Elements
        print("Submitting research query...")
        await composer.fill("Solid-State Batteries 2028 Ceramic Electrolytes Benchmarks")
        
        # Turn off deep mode for fast test if needed, or run standard
        ask_submit = page.locator("button:has-text('Ask')").last
        await ask_submit.click()
        print("Clicked Ask button, waiting for response...")

        # Wait for either response article or bubble
        await page.wait_for_selector("article, [data-slot='bubble']", timeout=30000)
        await asyncio.sleep(3)

        # Check User Bubble: ensure it's NOT huge gold default variant
        user_bubble = page.locator("[data-slot='bubble'][data-align='end']").first
        if await user_bubble.is_visible():
            variant = await user_bubble.get_attribute("data-variant")
            assert variant == "secondary", f"User bubble should be secondary, got {variant}"
            print("✅ User bubble is refined secondary variant (not solid mustard)")

        # Wait for article to populate
        article = page.locator("article").first
        if await article.is_visible():
            # Check that 5 # Section pills are NOT present
            hash_nav = article.locator("nav[aria-label='Report sections']")
            assert await hash_nav.count() == 0, "5 # Section jump pills should be removed for decluttering"
            print("✅ Cluttering # Section pills are eliminated")

            # Check action buttons (Copy, Plain Text, etc.)
            copy_btn = article.locator("button:has-text('Copy')").first
            plain_btn = article.locator("button:has-text('Plain Text')").first
            assert await copy_btn.is_visible()
            assert await plain_btn.is_visible()
            print("✅ Compact action buttons [Copy, Plain Text] visible")

        # Check Inspector if visible
        inspector = page.locator("aside").first
        if await inspector.is_visible():
            # Verify Memory Used is eliminated
            mem_meter = inspector.locator("text='Memory Used'")
            assert await mem_meter.count() == 0, "Memory Used meter should be removed"
            print("✅ Useless 'Memory Used' meter eliminated from Inspector")

        await page.screenshot(path="scratch/shot_full_decluttered.png")
        print("📸 Captured shot_full_decluttered.png")

        await browser.close()
        print("🎉 ALL DECLUTTER & FIX VERIFICATIONS COMPLETED SUCCESSFULLY!")

asyncio.run(run())
