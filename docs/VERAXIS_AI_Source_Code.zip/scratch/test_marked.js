const { marked } = require("./frontend/node_modules/marked");

const text = `
[Wikipedia: Solid state](https://en.wikipedia.org/wiki/Solid_state)
[Paper: PEO/garnet composite electrolytes for solid-state lithium batteries: From "ceramic-in-polymer" to "polymer-in-ceramic" (1434 citations)]
(https://doi.org/10.1016/j.nanoen.2017.12.037)
`;

console.log("DEFAULT MARKED:");
console.log(marked.parse(text));
